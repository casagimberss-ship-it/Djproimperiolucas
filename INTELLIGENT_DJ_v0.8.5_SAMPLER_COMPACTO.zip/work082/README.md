# INTELLIGENT DJ by Dj Lucas Quintana

Proyecto Android — versión 0.8.2. Mínimo Android 8.1 (API 27).

## Incluido en esta base
- Proyecto Gradle Kotlin DSL con Android Gradle Plugin 8.7.3 y Kotlin 2.0.21.
- Interfaz Jetpack Compose con reproductor inicial, cuatro pads visuales, panel de grabación y biblioteca.
- Selector de carpeta mediante Storage Access Framework y listado de archivos de audio compatibles.
- Interfaz con un solo deck visible.
- Dos reproductores ExoPlayer internos y ocultos: deck activo y deck de preparación.
- Transición Smart de 6 segundos con crossfade de volumen y preparación anticipada de la siguiente pista.
- Automix opcional: vigila el final de la pista y dispara la transición en el outro estimado; usa los últimos 20 segundos como fallback conservador.
- Beatgrid experimental: BPM, intervalo y offset estimados desde ataques del audio; duración de frase aproximada de 8 compases.
- Detección heurística de intro/outro a partir de cambios sostenidos de energía, más un indicador orientativo de confianza.
- Ajuste fino de velocidad del deck entrante (±6 %) para aproximación de beatmatching cuando hay BPM estimado; no altera el BPM guardado.
- Fallback a cambio directo cuando la reproducción está pausada o detenida.
- Analizador local experimental de audio PCM de archivo completo: decodifica hasta BUFFER_FLAG_END_OF_STREAM, sin recorte temporal fijo. Calcula energía en bloques de 5 s, BPM en ventanas sucesivas de 30 s y tonalidad/Camelot usando ventanas distribuidas desde el comienzo hasta el final.
- Escaneo recursivo de subcarpetas de audio.
- Primer motor SmartMix determinista: selección sin repetición dentro del ciclo, compatibilidad Camelot, distancia BPM adaptativa y progresión de energía cuando esos metadatos estén disponibles.
- Configuración inicial aprobada: Smart automático, BPM adaptativo y energía progresiva.
- Módulo C++ inicial y CMake con puente JNI de ganancia master.
- GitHub Actions para compilar `app-debug.apk` y publicarlo como artifact.

## Compilar localmente
Requisitos: Android Studio reciente, JDK 17, Android SDK Platform 35, Build Tools y CMake 3.22.1.

```bash
gradle :app:assembleDebug
```

El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar en GitHub
El workflow configura Gradle 8.9 mediante `gradle/actions/setup-gradle@v4` y ejecuta `gradle :app:assembleDebug`; por eso **no exige `gradlew` ni `gradle-wrapper.jar`**. Esto evita el error `gradlew is missing` del workflow anterior.

1. Crear un repositorio vacío y subir todo el contenido de esta carpeta.
2. Abrir **Actions** y ejecutar **Android APK Build** (o hacer push a `main`).
3. Descargar el artifact `intelligent-dj-debug-apk` del workflow terminado.

## Arquitectura
- UI: Kotlin + Jetpack Compose, siempre con un único deck visible.
- Playback: dos instancias internas de ExoPlayer para preparar la siguiente pista y realizar crossfade; el segundo deck nunca se muestra como control independiente.
- Biblioteca: SAF para acceso a archivos y Room 2.6.1 para persistir catálogo y análisis completos.
- Reproducción inicial: Media3/ExoPlayer para validar biblioteca y flujo de reproducción.
- Evolución futura del motor: salida PCM única con dos decks internos, samplers y master; migración a Oboe para baja latencia. No abrir un stream por deck.
- Análisis: BPM, beatgrid, key/Camelot, energía, loudness e intro/outro, persistidos localmente.
- Automix Smart: puntaje de compatibilidad armónica, BPM, energía y estructura; seleccionar desde toda la biblioteca evitando repeticiones.
- Grabación v0.8: AudioPlaybackCapture filtrado al UID propio + codificación MP3 CBR 320 kbps; no usa el micrófono. La migración al bus PCM propio queda pendiente para garantizar una captura master idéntica a la salida.

## Estado honesto de esta versión

La app permite elegir una carpeta, recorrer subcarpetas, enumerar/reproducir pistas y analizar los archivos en segundo plano. La interfaz muestra un solo deck. Dos ExoPlayer ocultos permiten preparar la siguiente pista y cruzar volúmenes durante seis segundos; la velocidad del entrante se ajusta de forma conservadora usando BPM estimado. El analizador decodifica el flujo completo de audio local mediante MediaCodec hasta el final del archivo. Room guarda biblioteca, metadatos y líneas temporales; reutiliza análisis cuando URI, tamaño, fecha y cobertura siguen vigentes. BPM, tonalidad, beatgrid, frases e intro/outro siguen siendo estimaciones heurísticas. Los cuatro pads permiten asignar audio, disparar, repetir y detener samples. La grabación MP3 320 usa AudioPlaybackCapture de Android 10+ con permiso del usuario y filtro por UID de la app. Es una primera implementación y debe probarse en dispositivos reales: la captura puede depender del fabricante, de la política de audio y de que el sistema entregue el mix esperado. Todavía no existe un bus PCM único propio que garantice una captura master perfectamente sincronizada con el crossfade y los pads. El crossfade actual es una transición inicial de volumen, no un mezclador profesional ni una sincronización de beats/frases garantizada. El C++ actual es solo un esqueleto JNI, no un mezclador profesional. Probar el APK en dispositivos reales y comparar resultados con pistas conocidas antes de usarlo en sonido profesional.
## v0.8.2 — Grabación de set y sampler

- Cuatro pads funcionales con asignación de archivos de audio mediante SAF; permisos de lectura persistentes y nombres guardados localmente.
- Disparo one-shot, modo loop y botón Stop independiente para cada pad. Los pads usan reproductores internos ocultos y no agregan decks visibles.
- Grabación MP3 estéreo CBR 320 kbps con encoder LAME, guardado mediante selector de documento del usuario.
- Captura de reproducción interna Android `AudioPlaybackCapture` con `MediaProjection`; filtra por UID de INTELLIGENT DJ para no grabar audio de otras aplicaciones.
- Servicio en primer plano con notificación persistente y acción para detener la grabación.
- Requiere Android 10 (API 29) o superior, permiso RECORD_AUDIO y aprobación explícita de captura del sistema. En Android 8.1/9 la grabación se deshabilita; los pads siguen disponibles.
- La captura está condicionada a las políticas de audio del dispositivo y a que los reproductores emitan `USAGE_MEDIA`/`USAGE_GAME` y permitan captura. Debe probarse en hardware real antes de usarla en actuaciones.

## Próximas etapas
1. Validar grabación, continuidad de audio y sincronía del set en dispositivos Android reales.
2. Convertir el playback a un bus PCM propio para garantizar captura del master, crossfade, EQ y sampler en una sola mezcla con latencia controlada.
3. Añadir controles de volumen, pitch, cuantización y carga rápida para cada pad.
4. Añadir historial de sets grabados, metadatos ID3 y recuperación segura ante interrupciones.

## Licencias
Revisar licencias de cualquier biblioteca/codec incorporado antes de distribuir una versión comercial. Esta base no incorpora Essentia ni LAME.

## v0.7.0 — Base de datos Room

- Room 2.6.1 con KSP para generar el código de persistencia.
- Tabla `tracks`, identificada por la URI persistente SAF de cada archivo.
- Guarda nombre, tamaño, fecha de modificación, duración, cobertura analizada, BPM, Camelot, energía, beat offset/interval, longitud de frase, intro/outro, confianza y líneas temporales completas de energía y BPM.
- Al abrir la app, recupera la biblioteca y sus análisis desde Room.
- Al volver a escanear una carpeta, reutiliza el análisis guardado si URI, tamaño y fecha de modificación coinciden y la cobertura del análisis llegó al final de la pista.
- Si el archivo cambió o el análisis quedó incompleto, vuelve a analizarlo y actualiza el registro.
- Base local: `intelligent_dj_library.db`; no se suben pistas ni análisis a servidores.

La primera apertura después de actualizar crea la base automáticamente. Los análisis existentes que no estén en Room se generan una vez al escanear la carpeta.


## Avisos de v0.8.2

La codificación usa TAndroidLame 1.1, wrapper Android de LAME distribuido bajo GPL-3.0-or-later. Antes de distribuir comercialmente la app, revisar el cumplimiento de GPL-3.0 y las obligaciones de distribución del código fuente/licencias; se puede sustituir por un encoder con licencia compatible si el proyecto necesita mantener una licencia propietaria. Referencia: https://github.com/naman14/TAndroidLame.

La grabación de esta versión usa la API Android AudioPlaybackCapture y filtra el UID propio. No es todavía un tap PCM integrado directamente al motor de mezcla. Android documenta que la captura requiere MediaProjection aprobada por el usuario, RECORD_AUDIO, uso de audio permitido y política de captura habilitada. La API existe desde Android 10. Si un fabricante restringe la captura o el audio no sale con atributos compatibles, la grabación puede resultar silenciosa o fallar. En ese caso no debe considerarse una grabación maestra fiable hasta migrar al bus PCM propio.


## INTELLIGENT DJ v0.8.4 — Sampler UI
- Four sampler pads are displayed in a single horizontal row.
- On narrow screens, the row can be scrolled horizontally to keep all four pads side by side.
- Each pad has an individual load action, trigger, One Shot/Loop mode, and volume control.
- Pad URI, display name, playback mode, and volume are persisted in SharedPreferences.
- Existing sampler ExoPlayer instances remain independent; the main deck and recording service are unchanged.
