package com.djlucasquintana.intelligentdj

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Persisted analysis for one audio document. URI is the stable SAF document identifier. */
@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val uri: String,
    val name: String,
    val sizeBytes: Long,
    val modifiedAt: Long,
    val durationSeconds: Double?,
    val analyzedDurationSeconds: Double?,
    val bpm: Double?,
    val camelot: String?,
    val energy: Double?,
    val beatOffsetSeconds: Double?,
    val beatIntervalSeconds: Double?,
    val phraseLengthSeconds: Double?,
    val introEndSeconds: Double?,
    val outroStartSeconds: Double?,
    val analysisConfidence: Double?,
    val energyTimeline: String,
    val bpmTimeline: String,
    val analyzedAt: Long,
)

@Dao
interface TrackDao {
    @Query("SELECT * FROM tracks WHERE uri = :uri LIMIT 1")
    suspend fun findByUri(uri: String): TrackEntity?

    @Query("SELECT * FROM tracks ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<TrackEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(track: TrackEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(tracks: List<TrackEntity>)

    @Query("DELETE FROM tracks WHERE uri = :uri")
    suspend fun deleteByUri(uri: String)

    @Query("SELECT COUNT(*) FROM tracks")
    suspend fun count(): Int
}

@Database(entities = [TrackEntity::class], version = 1, exportSchema = false)
abstract class DjDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao

    companion object {
        @Volatile private var INSTANCE: DjDatabase? = null
        fun get(context: Context): DjDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                DjDatabase::class.java,
                "intelligent_dj_library.db"
            ).build().also { INSTANCE = it }
        }
    }
}

/** Converts analyzer output into a Room row without losing the complete timelines. */
fun TrackEntity.toAnalysis(): TrackAnalysis = TrackAnalysis(
    bpm = bpm,
    camelot = camelot,
    energy = energy,
    beatOffsetSeconds = beatOffsetSeconds,
    beatIntervalSeconds = beatIntervalSeconds,
    phraseLengthSeconds = phraseLengthSeconds,
    introEndSeconds = introEndSeconds,
    outroStartSeconds = outroStartSeconds,
    analysisConfidence = analysisConfidence,
    durationSeconds = durationSeconds,
    analyzedDurationSeconds = analyzedDurationSeconds,
    energyTimeline = decodeDoubles(energyTimeline),
    bpmTimeline = decodeDoubles(bpmTimeline)
)

fun Track.toEntity(): TrackEntity = TrackEntity(
    uri = uri.toString(), name = name, sizeBytes = sizeBytes, modifiedAt = modifiedAt,
    durationSeconds = analysis.durationSeconds,
    analyzedDurationSeconds = analysis.analyzedDurationSeconds,
    bpm = analysis.bpm, camelot = analysis.camelot, energy = analysis.energy,
    beatOffsetSeconds = analysis.beatOffsetSeconds,
    beatIntervalSeconds = analysis.beatIntervalSeconds,
    phraseLengthSeconds = analysis.phraseLengthSeconds,
    introEndSeconds = analysis.introEndSeconds,
    outroStartSeconds = analysis.outroStartSeconds,
    analysisConfidence = analysis.analysisConfidence,
    energyTimeline = encodeDoubles(analysis.energyTimeline),
    bpmTimeline = encodeDoubles(analysis.bpmTimeline),
    analyzedAt = System.currentTimeMillis()
)

private fun encodeDoubles(values: List<Double>): String = values.joinToString(",") {
    if (it.isFinite()) it.toString() else "NaN"
}

private fun decodeDoubles(value: String): List<Double> = if (value.isBlank()) emptyList() else
    value.split(',').mapNotNull { token -> token.toDoubleOrNull() }

/** Cache validity depends on the SAF document's size and modification timestamp. */
suspend fun TrackDao.getCachedAnalysis(track: Track): TrackAnalysis? = withContext(Dispatchers.IO) {
    val row = findByUri(track.uri.toString()) ?: return@withContext null
    if (row.sizeBytes != track.sizeBytes || row.modifiedAt != track.modifiedAt ||
        row.analyzedDurationSeconds == null || row.durationSeconds == null ||
        row.analyzedDurationSeconds + 1.0 < row.durationSeconds) return@withContext null
    row.toAnalysis()
}
