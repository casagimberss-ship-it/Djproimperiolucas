package com.djlucasquintana.intelligentdj

import kotlin.math.abs

/** Metadata produced by the future audio-analysis stage. Null means not analysed yet. */
data class TrackAnalysis(
    val bpm: Double? = null,
    /** Camelot notation, e.g. "8A" or "2B". */
    val camelot: String? = null,
    /** Normalized energy from 0.0 (calm) to 1.0 (intense). */
    val energy: Double? = null,
    /** Estimated first beat position in seconds from the start of the file. */
    val beatOffsetSeconds: Double? = null,
    /** Estimated duration between beats. */
    val beatIntervalSeconds: Double? = null,
    /** Approximate 8-bar phrase duration. */
    val phraseLengthSeconds: Double? = null,
    /** Estimated end of intro / start of main section. */
    val introEndSeconds: Double? = null,
    /** Estimated start of outro, suitable as an automatic transition cue. */
    val outroStartSeconds: Double? = null,
    /** Heuristic confidence from 0.0 to 1.0, not a guaranteed correctness probability. */
    val analysisConfidence: Double? = null,
    /** Full media duration reported by the decoded stream, in seconds. */
    val durationSeconds: Double? = null,
    /** Duration actually decoded and analyzed; equals durationSeconds on a complete pass. */
    val analyzedDurationSeconds: Double? = null,
    /** RMS energy for consecutive five-second buckets across the entire track. */
    val energyTimeline: List<Double> = emptyList(),
    /** Estimated BPM for consecutive thirty-second windows; NaN means no reliable estimate. */
    val bpmTimeline: List<Double> = emptyList(),
)

data class SmartMixSettings(
    val adaptiveBpm: Boolean = true,
    val progressiveEnergy: Boolean = true,
    val preferHarmonicMixing: Boolean = true,
)

/** Deterministic candidate ranking for Smart Automix. It never repeats a track until a cycle ends. */
object SmartMixEngine {
    fun selectNext(
        analyses: List<TrackAnalysis>,
        currentIndex: Int,
        playedIndices: Set<Int>,
        settings: SmartMixSettings = SmartMixSettings(),
    ): Int? {
        if (analyses.size < 2) return null

        val validCurrent = currentIndex in analyses.indices
        val current = if (validCurrent) analyses[currentIndex] else null
        var candidates = analyses.indices.filter { it != currentIndex && it !in playedIndices }
        if (candidates.isEmpty()) {
            // Start a fresh cycle, still excluding the currently playing track.
            candidates = analyses.indices.filter { it != currentIndex }
        }
        if (candidates.isEmpty()) return null

        // With no analysis yet, preserve a predictable playlist-like fallback.
        val hasAnyMetadata = analyses.any { it.bpm != null || it.camelot != null || it.energy != null }
        if (!hasAnyMetadata) return candidates.minByOrNull { (it - currentIndex - 1 + analyses.size) % analyses.size }

        val targetEnergy = current?.energy?.let {
            if (settings.progressiveEnergy) (it + 0.08).coerceAtMost(1.0) else it
        }

        return candidates.maxWithOrNull(
            compareBy<Int> { index ->
                val next = analyses[index]
                var score = 0.0
                val bpmA = current?.bpm
                val bpmB = next.bpm
                if (bpmA != null && bpmB != null) {
                    val delta = bpmDistance(bpmA, bpmB)
                    score += if (settings.adaptiveBpm) (1.0 - (delta / 18.0).coerceAtMost(1.0)) * 30.0
                    else if (delta <= 3.0) 30.0 else -30.0
                }
                if (settings.preferHarmonicMixing && current?.camelot != null && next.camelot != null) {
                    score += camelotScore(current.camelot, next.camelot)
                }
                if (targetEnergy != null && next.energy != null) {
                    val difference = next.energy - targetEnergy
                    score += if (settings.progressiveEnergy) {
                        // Reward a gentle rise; penalize a large drop or an abrupt jump.
                        25.0 - abs(difference - 0.04) * 45.0 - if (difference < -0.05) 12.0 else 0.0
                    } else 20.0 - abs(difference) * 35.0
                }
                score
            }.thenBy { -((it - currentIndex - 1 + analyses.size) % analyses.size) }
        )
    }

    private fun bpmDistance(a: Double, b: Double): Double {
        if (a <= 0.0 || b <= 0.0) return 1_000.0
        val ratios = listOf(0.5, 1.0, 2.0)
        return ratios.minOf { ratio -> abs(a - b * ratio) }
    }

    private fun camelotScore(a: String, b: String): Double {
        val first = parseCamelot(a) ?: return 0.0
        val second = parseCamelot(b) ?: return 0.0
        val (numberA, letterA) = first
        val (numberB, letterB) = second
        return when {
            numberA == numberB && letterA == letterB -> 40.0
            numberA == numberB && letterA != letterB -> 32.0
            letterA == letterB && (numberA - numberB).mod(12) in setOf(1, 11) -> 30.0
            else -> -abs(numberA - numberB).coerceAtMost(6) * 2.0
        }
    }

    private fun parseCamelot(value: String): Pair<Int, Char>? {
        val normalized = value.trim().uppercase()
        if (normalized.length !in 2..3) return null
        val letter = normalized.last()
        val number = normalized.dropLast(1).toIntOrNull() ?: return null
        if (number !in 1..12 || letter !in setOf('A', 'B')) return null
        return number to letter
    }
}
