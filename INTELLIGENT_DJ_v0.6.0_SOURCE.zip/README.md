# INTELLIGENT DJ by Dj Lucas Quintana

Proyecto Android — versión 0.6.0. Mínimo Android 8.1 (API 27).

## Incluido en esta base
- Proyecto Gradle Kotlin DSL con Android Gradle Plugin 8.7.3 y Kotlin 2.0.21.
- Interfaz Jetpack Compose con reproductor inicial, cuatro pads visuales, panel de grabación y biblioteca.
- Selector de carpeta mediante Storage Access Framework y listado de archivos de audio compatibles.
- Interfaz con un solo deck visible.
- Dos reproductores ExoPlayer internos y ocultos: deck activo y deck de preparación.
- Transición Smart de 6 segundos con crossfade de volumen y preparación anticipada de la siguiente pista.
- Automix opcional: vigila el final de la pista y dispara la transición en el outro estimado; usa los últimos 20 segundos como fallback conservador.
- Beatgrid experimental: BPM, intervalo y offset estimados desde ataques del audio; duración de frase aproximada de 8 compases.
- Detección heurística de intro/outro a partir de cambios sostenidos de energía, más un indicador orientativo de confianza.
- Ajuste fino de velocidad del deck entrante (±6 %) para aproximación de beatmatching cuando hay BPM estimado; no altera el BPM guardado.
- Fallback a cambio directo cuando la reproducción está pausada o detenida.
- Analizador local experimental de audio PCM de archivo completo: decodifica hasta BUFFER_FLAG_END_OF_STREAM, sin recorte temporal fijo. Calcula energía en bloques de 5 s, BPM en ventanas sucesivas de 30 s y tonalidad/Camelot usando ventanas distribuidas desde el comienzo hasta el final.
- Escaneo recursivo de subcarpetas de audio.
- Primer motor SmartMix determinista: selección sin repetición dentro del ciclo, compatibilidad Camelot, distancia BPM adaptativa y progresión de energía cuando esos metadatos estén disponibles.
- Configuración inicial aprobada: Smart automático, BPM adaptativo y energía progresiva.
- Módulo C++ inicial y CMake con puente JNI de ganancia master.
- GitHub Actions para compilar `app-debug.apk` y publicarlo como artifact.

## Compilar localmente
Requisitos: Android Studio reciente, JDK 17, Android SDK Platform 35, Build Tools y CMake 3.22.1.

```bash
gradle :app:assembleDebug
```

El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar en GitHub
El workflow configura Gradle 8.9 mediante `gradle/actions/setup-gradle@v4` y ejecuta `gradle :app:assembleDebug`; por eso **no exige `gradlew` ni `gradle-wrapper.jar`**. Esto evita el error `gradlew is missing` del workflow anterior.

1. Crear un repositorio vacío y subir todo el contenido de esta carpeta.
2. Abrir **Actions** y ejecutar **Android APK Build** (o hacer push a `main`).
3. Descargar el artifact `intelligent-dj-debug-apk` del workflow terminado.

## Arquitectura
- UI: Kotlin + Jetpack Compose, siempre con un único deck visible.
- Playback: dos instancias internas de ExoPlayer para preparar la siguiente pista y realizar crossfade; el segundo deck nunca se muestra como control independiente.
- Biblioteca: SAF ahora; Room para persistir catálogo y análisis en siguiente iteración.
- Reproducción inicial: Media3/ExoPlayer para validar biblioteca y flujo de reproducción.
- Evolución futura del motor: salida PCM única con dos decks internos, samplers y master; migración a Oboe para baja latencia. No abrir un stream por deck.
- Análisis: BPM, beatgrid, key/Camelot, energía, loudness e intro/outro, persistidos localmente.
- Automix Smart: puntaje de compatibilidad armónica, BPM, energía y estructura; seleccionar desde toda la biblioteca evitando repeticiones.
- Grabación: capturar el bus Master PCM interno y codificar MP3 CBR 320 kbps; nunca usar micrófono.

## Estado honesto de esta versión
La app permite elegir una carpeta, recorrer subcarpetas, enumerar/reproducir pistas y lanzar el análisis de cada archivo en segundo plano. La interfaz muestra un solo deck. Para la transición, dos ExoPlayer ocultos permiten preparar la siguiente pista y cruzar volúmenes durante seis segundos; la velocidad del entrante se ajusta de forma conservadora usando BPM estimado. El analizador decodifica el flujo completo de audio local mediante MediaCodec hasta el final del archivo (sin límite de 75 segundos). Calcula energía RMS en bloques de cinco segundos a lo largo de toda la pista, BPM por ventanas consecutivas de treinta segundos, tonalidad/Camelot con muestras distribuidas a lo largo de toda la canción, beatgrid inicial, duración de frase e inicio aproximado de intro/outro. Registra duración total y duración efectivamente analizada; la cobertura completa se considera cuando ambas coinciden. Los BPM por ventana y la línea de energía permiten identificar cambios y secciones a lo largo del tema. La carga y análisis siguen siendo secuenciales por pista y los resultados aún no se guardan de forma persistente entre sesiones. El Automix puede iniciar la transición al llegar al outro estimado, o usar los últimos 20 segundos si la confianza es baja. La confianza es un indicador heurístico, no una probabilidad calibrada. Es una primera implementación DSP, no un analizador comercial certificado: BPM y tonalidad pueden fallar con intros largas, percusión atonal, cambios de tempo, mezclas en vivo o archivos con codecs poco compatibles. El análisis recorre el archivo completo, pero todavía no persiste resultados entre sesiones. El análisis de tonalidad y estructura es heurístico; no equivale a separación de stems ni a etiquetado semántico garantizado de verso/estribillo/drop. Room, beatgrid preciso con downbeat validado, detección musical real de frases/intro/outro, crossfader/EQ profesional, salida PCM de baja latencia, pads editables y grabación MP3 siguen pendientes. El crossfade actual es una transición inicial de volumen, no un mezclador profesional ni una sincronización de beats/frases garantizada. El C++ actual es solo un esqueleto JNI, no un mezclador profesional. Probar el APK en dispositivos reales y comparar resultados con pistas conocidas antes de usarlo en sonido profesional.

## Próximas etapas
1. Room + persistencia del catálogo, líneas de tiempo y resultados completos de análisis.
2. Validar BPM por secciones, beatgrid/downbeat y tonalidad/Camelot con pistas de referencia.
3. Refinar la detección de frases, intros/outros y puntos de transición automática con análisis estructural de todo el tema.
4. Motor PCM/Oboe con dos decks internos y una única interfaz visible, crossfader, EQ y transiciones Smart.
5. Cuatro samplers configurables.
6. Grabador interno MP3 320 kbps y pruebas de estabilidad.

## Licencias
Revisar licencias de cualquier biblioteca/codec incorporado antes de distribuir una versión comercial. Esta base no incorpora Essentia ni LAME.
