# Keep Media3 and Android framework defaults.
