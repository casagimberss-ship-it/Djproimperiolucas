package com.imperio.djpromix

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.setPadding
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var deckA: Deck
    private lateinit var deckB: Deck
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private val library = mutableListOf<Track>()
    private var partyMode = false
    private var partyIndex = -1
    private var partyPlaying = false

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let { importFolder(it) }
    }
    private val pickA = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { loadTrack(deckA, Track(it, queryName(it) ?: "Pista")) } }
    private val pickB = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { loadTrack(deckB, Track(it, queryName(it) ?: "Pista")) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 9, 14)
        window.navigationBarColor = Color.rgb(7, 9, 14)
        deckA = Deck("A"); deckB = Deck("B")
        render()
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(18)) }
        scroll.addView(root)
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("IMPERIO", 23, GOLD, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("DJ PRO MIX  •  STAGE 2", 10, MUTED, true))
        root.addView(header)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabs.addView(action("DJ DECKS") { partyMode = false; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        tabs.addView(action("MODO FIESTA") { partyMode = true; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(tabs)
        root.addView(action("▣  IMPORTAR CARPETA DE MÚSICA") { folderPicker.launch(null) })
        root.addView(label("BIBLIOTECA  ·  ${library.size} pistas", 12, GOLD, true))
        if (partyMode) renderParty() else renderDecks()
        status = label("Listo · importa una carpeta para comenzar", 11, MUTED)
        root.addView(status)
        setContentView(scroll)
        applyMix()
    }

    private fun renderDecks() {
        val horizontal = resources.configuration.smallestScreenWidthDp >= 600
        val decks = LinearLayout(this).apply { orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        decks.addView(deckPanel(deckA, { pickA.launch(arrayOf("audio/*")) }, 0), LinearLayout.LayoutParams(if (horizontal) 0 else -1, if (horizontal) -2 else -2, if (horizontal) 1f else 0f))
        decks.addView(deckPanel(deckB, { pickB.launch(arrayOf("audio/*")) }, 1), LinearLayout.LayoutParams(if (horizontal) 0 else -1, if (horizontal) -2 else -2, if (horizontal) 1f else 0f))
        root.addView(decks)
        root.addView(label("MIXER CENTRAL", 13, GOLD, true).apply { gravity = Gravity.CENTER })
        root.addView(label("CROSSFADER  A  ◀────────●────────▶  B", 10, MUTED, true))
        val cross = SeekBar(this).apply { max = 100; progress = 50; setOnSeekBarChangeListener(change { applyMix(it.progress, null) }) }
        root.addView(cross)
        val master = SeekBar(this).apply { max = 100; progress = 85; setOnSeekBarChangeListener(change { applyMix(null, it.progress) }) }
        root.addView(label("MASTER VOLUME", 10, MUTED, true)); root.addView(master)
        root.addView(label("BIBLIOTECA MUSICAL", 13, GOLD, true))
        renderLibrary(root)
    }

    private fun deckPanel(deck: Deck, load: () -> Unit, index: Int): View {
        val accent = if (index == 0) CYAN else GOLD
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10)); setBackgroundColor(if (index == 0) Color.rgb(17, 31, 45) else Color.rgb(39, 28, 22)) }
        panel.addView(label("DECK ${deck.name}  ●  ${if (deck.player?.isPlaying == true) "PLAYING" else "READY"}", 16, accent, true))
        panel.addView(action("＋ CARGAR PISTA") { load() })
        panel.addView(label(deck.title, 13, WHITE, true).also { deck.titleView = it })
        panel.addView(label("BPM ${deck.bpm?.toString() ?: "---"}     KEY ${deck.key ?: "---"}", 11, accent, true).also { deck.analysisView = it })
        val seek = SeekBar(this).apply { max = 1000; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) deck.player?.let { if (it.duration > 0) it.seekTo(it.duration * p / 1000) } }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        }) }
        deck.seek = seek; panel.addView(seek)
        val time = label("00:00 / 00:00", 10, MUTED).also { deck.timeView = it }; panel.addView(time)
        val transport = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        transport.addView(action("▶ PLAY / PAUSE") { toggle(deck) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        transport.addView(action("■ STOP") { deck.player?.run { pause(); seekTo(0) }; updateDeck(deck) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        transport.addView(action("CUE") { deck.cue = deck.player?.currentPosition ?: 0L }, LinearLayout.LayoutParams(0, dp(44), 1f))
        panel.addView(transport)
        panel.addView(label("PITCH ±8%", 10, MUTED, true))
        panel.addView(SeekBar(this).apply { max = 160; progress = 80; setOnSeekBarChangeListener(change { deck.player?.setPlaybackSpeed(0.92f + it.progress / 1000f) }) })
        panel.addView(label("HOT CUES", 10, MUTED, true))
        val pads = GridLayout(this).apply { columnCount = 4 }
        repeat(8) { n -> pads.addView(action("CUE ${n + 1}") { val p = deck.player ?: return@action; if (deck.hot[n] == null) deck.hot[n] = p.currentPosition else p.seekTo(deck.hot[n]!!) }, GridLayout.LayoutParams().apply { width = 0; height = dp(38); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) }) }
        panel.addView(pads)
        return panel
    }

    private fun renderParty() {
        root.addView(label("MODO FIESTA AUTOMÁTICO", 21, GOLD, true))
        root.addView(label("Reproducción continua de la biblioteca. La selección armónica utiliza BPM y tonalidad asignados a las pistas.", 12, MUTED))
        root.addView(action(if (partyPlaying) "Ⅱ  DETENER MODO FIESTA" else "▶  INICIAR MODO FIESTA") { if (partyPlaying) stopParty() else startParty() })
        root.addView(action("SIGUIENTE PISTA COMPATIBLE") { playNextPartyTrack() })
        root.addView(label("DECK PRINCIPAL · ${deckA.title}", 14, WHITE, true))
        root.addView(label("BPM ${deckA.bpm ?: "---"}  ·  KEY ${deckA.key ?: "---"}", 12, CYAN, true))
        renderLibrary(root)
    }

    private fun renderLibrary(target: LinearLayout) {
        if (library.isEmpty()) {
            target.addView(label("No hay pistas. Pulsa IMPORTAR CARPETA DE MÚSICA.", 12, MUTED)); return
        }
        library.forEachIndexed { index, track ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(if (index % 2 == 0) PANEL else BG); setPadding(dp(4)) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(track.title, 12, WHITE, true))
            info.addView(label("${track.bpm?.let { "$it BPM" } ?: "BPM sin analizar"}  ·  ${track.key ?: "Tonalidad sin asignar"}", 10, MUTED))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(action("A") { loadTrack(deckA, track) })
            row.addView(action("B") { loadTrack(deckB, track) })
            row.addView(action("♫") { editTrackAnalysis(track) })
            target.addView(row)
        }
    }

    private fun importFolder(uri: Uri) {
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val folder = DocumentFile.fromTreeUri(this, uri) ?: return
        val found = mutableListOf<Track>()
        fun scan(dir: DocumentFile) {
            dir.listFiles().forEach { f ->
                if (f.isDirectory) scan(f) else if (f.isFile && (f.type?.startsWith("audio/") == true || f.name.orEmpty().matches(Regex("(?i).+\\.(mp3|wav|flac|m4a|aac|ogg|opus|wma)$")))) {
                    if (found.none { it.uri == f.uri }) found.add(Track(f.uri, f.name ?: "Audio"))
                }
            }
        }
        scan(folder)
        library.clear(); library.addAll(found.sortedBy { it.title.lowercase(Locale.getDefault()) })
        Toast.makeText(this, "Importadas ${library.size} pistas", Toast.LENGTH_LONG).show()
        render()
    }

    private fun editTrackAnalysis(track: Track) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16)) }
        val bpm = EditText(this).apply { hint = "BPM (ej. 124)"; inputType =  numberType(); setText(track.bpm?.toString() ?: "") }
        val key = EditText(this).apply { hint = "Tonalidad Camelot (ej. 8A o 9B)"; setText(track.key ?: "") }
        box.addView(bpm); box.addView(key)
        android.app.AlertDialog.Builder(this).setTitle("Datos musicales · ${track.title}").setMessage("Puedes cargar BPM y clave Camelot para que el modo fiesta busque mezclas compatibles.").setView(box)
            .setPositiveButton("GUARDAR") { _, _ -> track.bpm = bpm.text.toString().toIntOrNull()?.takeIf { it in 50..220 }; track.key = key.text.toString().trim().uppercase(Locale.US).takeIf { it.matches(Regex("(1[0-2]|[1-9])[AB]")) }; render() }
            .setNegativeButton("CANCELAR", null).show()
    }

    private fun numberType() = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL

    private fun startParty() {
        if (library.isEmpty()) { Toast.makeText(this, "Importa una carpeta primero", Toast.LENGTH_SHORT).show(); return }
        partyPlaying = true; partyMode = true
        val first = library.indexOfFirst { it.bpm != null || it.key != null }.let { if (it < 0) 0 else it }
        partyIndex = first
        loadTrack(deckA, library[partyIndex]); deckA.player?.play()
        deckA.player?.addListener(object : Player.Listener { override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED && partyPlaying) playNextPartyTrack() } })
        render()
    }

    private fun stopParty() { partyPlaying = false; deckA.player?.pause(); render() }

    private fun playNextPartyTrack() {
        if (library.isEmpty()) return
        val current = library.getOrNull(partyIndex)
        val candidates = library.filter { it.uri != current?.uri }
        val next = candidates.minByOrNull { score(current, it) } ?: library.first()
        partyIndex = library.indexOf(next)
        loadTrack(deckA, next)
        if (partyPlaying) deckA.player?.play()
        status.text = "Siguiente: ${next.title} · ${compatibilityLabel(current, next)}"
    }

    private fun score(a: Track?, b: Track): Int {
        if (a == null) return 0
        val tempo = if (a.bpm != null && b.bpm != null) abs(a.bpm!! - b.bpm!!) * 3 else 30
        val harmonic = if (a.key != null && b.key != null) camelotDistance(a.key!!, b.key!!) * 20 else 30
        return tempo + harmonic
    }

    private fun camelotDistance(a: String, b: String): Int {
        val ma = Regex("(1[0-2]|[1-9])([AB])").matchEntire(a) ?: return 6
        val mb = Regex("(1[0-2]|[1-9])([AB])").matchEntire(b) ?: return 6
        val na = ma.groupValues[1].toInt(); val nb = mb.groupValues[1].toInt()
        val wheel = minOf(abs(na - nb), 12 - abs(na - nb))
        return wheel + if (ma.groupValues[2] == mb.groupValues[2]) 0 else 1
    }

    private fun compatibilityLabel(a: Track?, b: Track) = if (a?.key != null && b.key != null && camelotDistance(a.key!!, b.key!!) <= 1) "compatible armónicamente" else "compatibilidad no verificada"

    private fun loadTrack(deck: Deck, track: Track) {
        try {
            if (deck.player == null) deck.player = ExoPlayer.Builder(this).build()
            deck.player!!.setMediaItem(MediaItem.fromUri(track.uri)); deck.player!!.prepare(); deck.player!!.playWhenReady = false
            deck.title = track.title; deck.bpm = track.bpm; deck.key = track.key
            deck.titleView?.text = track.title; deck.analysisView?.text = "BPM ${track.bpm ?: "---"}     KEY ${track.key ?: "---"}"
            deck.player!!.addListener(object : Player.Listener { override fun onPlaybackStateChanged(state: Int) { updateDeck(deck) }; override fun onIsPlayingChanged(isPlaying: Boolean) { updateDeck(deck) } })
            status.text = "Deck ${deck.name}: ${track.title}"; updateDeck(deck)
        } catch (e: Exception) { Toast.makeText(this, "No se pudo cargar: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun queryName(uri: Uri): String? = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    private fun toggle(deck: Deck) { val p = deck.player ?: return; if (p.isPlaying) p.pause() else p.play(); updateDeck(deck) }
    private fun updateDeck(deck: Deck) { val p = deck.player ?: return; val d = p.duration.coerceAtLeast(0); deck.timeView?.text = "${fmt(p.currentPosition)} / ${fmt(d)}"; if (d > 0) deck.seek?.progress = (p.currentPosition * 1000 / d).toInt() }
    private fun applyMix(xValue: Int? = null, masterValue: Int? = null) { val x = (xValue ?: 50) / 100f; val m = (masterValue ?: 85) / 100f; deckA.player?.volume = (1f - x) * m; deckB.player?.volume = x * m }
    private fun fmt(ms: Long) = String.format(Locale.US, "%02d:%02d", ms / 60000, (ms / 1000) % 60)
    private fun change(block: (SeekBar) -> Unit) = object : SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { if (user) block(s) }; override fun onStartTrackingTouch(s: SeekBar) {}; override fun onStopTrackingTouch(s: SeekBar) {} }
    private fun label(t: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { text = t; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(dp(5), dp(6), dp(5), dp(6)) }
    private fun action(t: String, click: () -> Unit) = Button(this).apply { text = t; textSize = 10f; isAllCaps = false; setTextColor(WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(48, 57, 70)); setOnClickListener { click() } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { deckA.player?.release(); deckB.player?.release(); super.onDestroy() }

    data class Track(val uri: Uri, val title: String, var bpm: Int? = null, var key: String? = null)
    data class Deck(val name: String, var player: ExoPlayer? = null, var title: String = "Sin pista cargada", var bpm: Int? = null, var key: String? = null, var cue: Long = 0, val hot: Array<Long?> = arrayOfNulls(8), var titleView: TextView? = null, var analysisView: TextView? = null, var timeView: TextView? = null, var seek: SeekBar? = null)
    companion object { const val BG = 0xFF090D14.toInt(); const val PANEL = 0xFF151C27.toInt(); const val GOLD = 0xFFFFC247.toInt(); const val CYAN = 0xFF35D8E8.toInt(); const val WHITE = Color.WHITE; const val MUTED = 0xFF9BA4B2.toInt() }
}
