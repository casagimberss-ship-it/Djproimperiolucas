# IMPERIO DJ PRO MIX — Stage 2

Android nativo Kotlin, Android phones and tablets.

## Incluido en esta etapa
- Importación recursiva de una carpeta musical mediante Android Storage Access Framework (SAF), con permiso persistente.
- Biblioteca con pistas detectadas por MIME/extensión y carga en Deck A o Deck B.
- Interfaz DJ oscura con dos decks, transporte, pitch, hot cues, crossfader y master.
- Modo Fiesta con reproducción continua y selección de la siguiente pista según BPM y tonalidad Camelot disponibles.
- Edición manual de BPM y clave Camelot por pista para alimentar la selección armónica.

## Importante sobre el análisis musical
Esta etapa todavía NO calcula BPM ni tonalidad directamente desde la señal de audio. Los campos se pueden cargar manualmente. El motor de análisis real (decodificación PCM, detección de beats, estimación de tempo y perfil cromático/clave) y el crossfade automático entre dos decks son la siguiente fase técnica. No se muestran valores inventados como resultados de análisis.

## Compilar
Usar Java 17, Android SDK 35 y Gradle 8.9. Abrir el proyecto en Android Studio o usar el workflow de GitHub Actions del repositorio.
