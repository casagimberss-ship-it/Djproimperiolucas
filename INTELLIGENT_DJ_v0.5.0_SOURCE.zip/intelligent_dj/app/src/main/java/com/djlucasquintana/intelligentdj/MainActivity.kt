package com.djlucasquintana.intelligentdj

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import androidx.media3.common.PlaybackParameters
import kotlin.math.abs

private val Bg = Color(0xFF090D16)
private val Panel = Color(0xFF141C2B)
private val Accent = Color(0xFF19D3C5)
private val Muted = Color(0xFF9AA8BC)

data class Track(val name: String, val uri: Uri, val analysis: TrackAnalysis = TrackAnalysis())

class MainActivity : ComponentActivity() {
    // Dos reproductores internos, una sola interfaz/deck visible.
    private var player: ExoPlayer? = null
    private var hiddenPlayer: ExoPlayer? = null
    private var primaryIsActive = true
    private var transitionJob: Job? = null

    private fun activePlayer(): ExoPlayer? = if (primaryIsActive) player else hiddenPlayer
    private fun standbyPlayer(): ExoPlayer? = if (primaryIsActive) hiddenPlayer else player

    private fun matchedPlaybackSpeed(currentBpm: Double?, nextBpm: Double?): Float {
        if (currentBpm == null || nextBpm == null || currentBpm <= 0.0 || nextBpm <= 0.0) return 1f
        val candidates = listOf(nextBpm / 2.0, nextBpm, nextBpm * 2.0)
        val matched = candidates.minByOrNull { abs(it - currentBpm) } ?: nextBpm
        return (currentBpm / matched).coerceIn(0.94, 1.06).toFloat()
    }

    private fun crossfadeTo(track: Track, currentBpm: Double?, onComplete: () -> Unit) {
        if (transitionJob?.isActive == true) return
        val outgoing = activePlayer() ?: return
        val incoming = standbyPlayer() ?: return
        transitionJob = lifecycleScope.launch {
            try {
                incoming.stop()
                incoming.clearMediaItems()
                incoming.setMediaItem(MediaItem.fromUri(track.uri))
                incoming.volume = 0f
                incoming.playbackParameters = PlaybackParameters(matchedPlaybackSpeed(currentBpm, track.analysis.bpm))
                incoming.prepare()
                // Esperar a que el decoder esté listo sin bloquear el hilo de UI.
                var waited = 0
                while (incoming.playbackState != androidx.media3.common.Player.STATE_READY && waited < 4000) {
                    delay(100); waited += 100
                }
                if (incoming.playbackState != androidx.media3.common.Player.STATE_READY) {
                    incoming.stop(); incoming.clearMediaItems(); incoming.volume = 1f
                    return@launch
                }
                incoming.play()
                val steps = 30
                repeat(steps) { step ->
                    val incomingLevel = (step + 1).toFloat() / steps
                    outgoing.volume = 1f - incomingLevel
                    incoming.volume = incomingLevel
                    delay(200)
                }
                outgoing.pause()
                outgoing.stop()
                outgoing.clearMediaItems()
                outgoing.volume = 1f
                incoming.volume = 1f
                primaryIsActive = !primaryIsActive
                onComplete()
            } catch (_: Exception) {
                incoming.pause(); incoming.stop(); incoming.clearMediaItems(); incoming.volume = 1f
                outgoing.volume = 1f
            }
        }
    }
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val tracks = DocumentFile.fromTreeUri(this, uri)?.let { root ->
                    fun collect(directory: DocumentFile): List<DocumentFile> = directory.listFiles().flatMap { child ->
                        when {
                            child.isDirectory -> collect(child)
                            child.isFile && child.name?.substringAfterLast('.', "")?.lowercase() in setOf("mp3", "wav", "m4a", "flac", "ogg", "aac") -> listOf(child)
                            else -> emptyList()
                        }
                    }
                    collect(root).sortedBy { it.name?.lowercase() }
                }?.map { Track(it.name ?: "Audio", it.uri) }.orEmpty()
            onTracksLoaded(tracks)
        }
    }
    private var trackCallback: ((List<Track>) -> Unit)? = null
    private fun onTracksLoaded(tracks: List<Track>) { trackCallback?.invoke(tracks) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        hiddenPlayer = ExoPlayer.Builder(this).build()
        setContent {
            var tracks by remember { mutableStateOf(emptyList<Track>()) }
            var current by remember { mutableIntStateOf(0) }
            var playing by remember { mutableStateOf(false) }
            var playedIndices by remember { mutableStateOf(setOf<Int>()) }
            var folderLabel by remember { mutableStateOf("Ninguna carpeta seleccionada") }
            var analysisStatus by remember { mutableStateOf("Análisis de audio pendiente") }
            var autoMixEnabled by remember { mutableStateOf(true) }
            var autoAttemptedForIndex by remember { mutableIntStateOf(-1) }
            LaunchedEffect(playing, current, tracks.size, autoMixEnabled) {
                if (playing && autoMixEnabled && tracks.size > 1) {
                    while (true) {
                        val active = activePlayer()
                        val durationMs = active?.duration ?: androidx.media3.common.C.TIME_UNSET
                        val positionMs = active?.currentPosition ?: 0L
                        if (durationMs > 0L && durationMs != androidx.media3.common.C.TIME_UNSET && current != autoAttemptedForIndex) {
                            val analysis = tracks.getOrNull(current)?.analysis
                            val outroCueMs = analysis?.outroStartSeconds?.times(1000.0)?.toLong()
                            val confidence = analysis?.analysisConfidence ?: 0.0
                            // Use detected outro only when confidence is adequate; otherwise use a conservative 20 s fallback.
                            val cueMs = if (outroCueMs != null && confidence >= 0.45) outroCueMs else (durationMs - 20_000L).coerceAtLeast(0L)
                            if (positionMs >= cueMs) {
                                val next = SmartMixEngine.selectNext(tracks.map { it.analysis }, current, playedIndices)
                                if (next != null) {
                                    autoAttemptedForIndex = current
                                    val outgoingBpm = analysis?.bpm
                                    crossfadeTo(tracks[next], outgoingBpm) {
                                        playedIndices = playedIndices + current
                                        current = next
                                        playing = true
                                    }
                                }
                                break
                            }
                        }
                        delay(400)
                    }
                }
            }
            trackCallback = { loaded ->
                tracks = loaded; current = 0; playedIndices = emptySet(); autoAttemptedForIndex = -1
                folderLabel = "${loaded.size} pistas encontradas"
                analysisStatus = "Analizando biblioteca…"
                lifecycleScope.launch {
                    loaded.forEachIndexed { index, track ->
                        val result = AudioAnalyzer.analyze(this@MainActivity, track.uri)
                        tracks = tracks.toMutableList().also { it[index] = track.copy(analysis = result) }
                        analysisStatus = "Analizadas ${index + 1} de ${loaded.size} pistas"
                    }
                    analysisStatus = "Análisis finalizado • ${loaded.size} pistas"
                }
            }
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item {
                            Column {
                                Text("INTELLIGENT DJ", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                Text("by Dj Lucas Quintana", color = Accent, style = MaterialTheme.typography.labelLarge)
                                Text("SMART AUTOMIX • ANDROID", color = Muted, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        item {
                            PanelCard("REPRODUCTOR") {
                                Text(if (tracks.isNotEmpty()) tracks.getOrNull(current)?.name ?: "Sin pista" else "Cargá tu música para comenzar", color = Color.White, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    InfoPill("BPM", tracks.getOrNull(current)?.analysis?.bpm?.toInt()?.toString() ?: "--")
                                    InfoPill("KEY", tracks.getOrNull(current)?.analysis?.camelot?.let { camelotToKey(it) } ?: "--")
                                    InfoPill("CAMELOT", tracks.getOrNull(current)?.analysis?.camelot ?: "--")
                                    InfoPill("MATCH", if (tracks.size > 1) "Smart" else "Pendiente")
                                }
                                Spacer(Modifier.height(12.dp))
                                LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { if (tracks.isNotEmpty()) { if (playing) activePlayer()?.pause() else { if (activePlayer()?.mediaItemCount == 0) activePlayer()?.setMediaItem(MediaItem.fromUri(tracks[current].uri)); activePlayer()?.prepare(); activePlayer()?.play() }; playing = !playing } }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Accent) }
                                    IconButton(onClick = {
                                        if (tracks.size > 1) {
                                            val analyses = tracks.map { it.analysis }
                                            val next = SmartMixEngine.selectNext(analyses, current, playedIndices)
                                            if (next != null) {
                                                val outgoingBpm = tracks.getOrNull(current)?.analysis?.bpm
                                                val nextTrack = tracks[next]
                                                if (playing && activePlayer()?.isPlaying == true) {
                                                    crossfadeTo(nextTrack, outgoingBpm) {
                                                        playedIndices = playedIndices + current
                                                        current = next
                                                        playing = true
                                                    }
                                                } else {
                                                    playedIndices = playedIndices + current
                                                    val incoming = standbyPlayer()
                                                    incoming?.stop()
                                                    incoming?.setMediaItem(MediaItem.fromUri(nextTrack.uri))
                                                    incoming?.playbackParameters = PlaybackParameters(matchedPlaybackSpeed(outgoingBpm, nextTrack.analysis.bpm))
                                                    incoming?.prepare(); incoming?.play()
                                                    activePlayer()?.stop()
                                                    primaryIsActive = !primaryIsActive
                                                    current = next
                                                    playing = true
                                                }
                                            }
                                        }
                                    }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                                }
                                Text("SMART • BPM ADAPTIVE • ENERGÍA PROGRESSIVE", color = Accent, style = MaterialTheme.typography.labelSmall)
                                Text("1 DECK VISIBLE • 2 DECKS INTERNOS • CROSSFADE 6 s", color = Muted, style = MaterialTheme.typography.labelSmall)
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.weight(1f)) {
                                        Text("AUTOMIX AUTOMÁTICO", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                        Text("Transición al detectar el outro o en los últimos 20 s", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Switch(checked = autoMixEnabled, onCheckedChange = { autoMixEnabled = it })
                                }
                                val confidence = tracks.getOrNull(current)?.analysis?.analysisConfidence
                                InfoPill("ANÁLISIS", confidence?.let { "${(it * 100).toInt()}%" } ?: "--")
                                Text("$analysisStatus • BPM, tonalidad, beatgrid y estructura son estimaciones experimentales", color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        item {
                            PanelCard("SAMPLERS • 4 PADS") {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("PAD 1", "PAD 2", "PAD 3", "PAD 4").forEach { label ->
                                        Button(onClick = {}, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 16.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF26364B))) { Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall) }
                                    }
                                }
                                Text("Pads editables: próxima etapa", color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        item {
                            PanelCard("GRABACIÓN DEL SET") {
                                Text("MP3 • 320 kbps • captura interna", color = Color.White)
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) { Text("GRABACIÓN — PRÓXIMAMENTE") }
                                Text("La grabación tomará la mezcla interna; no usará el micrófono.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        item {
                            PanelCard("BIBLIOTECA") {
                                Button(onClick = { folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("SELECCIONAR CARPETA DE MÚSICA")
                                }
                                Text(folderLabel, color = Muted, style = MaterialTheme.typography.bodySmall)
                                Text("${tracks.size} pistas • escaneo recursivo", color = Accent, fontWeight = FontWeight.Bold)
                            }
                        }
                        items(tracks) { track ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                                Text(track.name, color = Color.White, modifier = Modifier.fillMaxWidth().padding(12.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() { transitionJob?.cancel(); player?.release(); hiddenPlayer?.release(); player = null; hiddenPlayer = null; super.onDestroy() }
}

@Composable private fun PanelCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = {
            Text(title, color = Accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            content()
        })
    }
}

@Composable private fun InfoPill(label: String, value: String) {
    Column(Modifier.background(Color(0xFF202C40), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) {
        Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
    }
}


private fun camelotToKey(value: String): String {
    val number = value.dropLast(1).toIntOrNull() ?: return "--"
    val major = mapOf(1 to "B", 2 to "F#", 3 to "C#", 4 to "G#", 5 to "D#", 6 to "A#", 7 to "F", 8 to "C", 9 to "G", 10 to "D", 11 to "A", 12 to "E")
    val minor = mapOf(1 to "G#m", 2 to "D#m", 3 to "A#m", 4 to "Fm", 5 to "Cm", 6 to "Gm", 7 to "Dm", 8 to "Am", 9 to "Em", 10 to "Bm", 11 to "F#m", 12 to "C#m")
    return (if (value.endsWith("A")) minor[number] else major[number]) ?: "--"
}
