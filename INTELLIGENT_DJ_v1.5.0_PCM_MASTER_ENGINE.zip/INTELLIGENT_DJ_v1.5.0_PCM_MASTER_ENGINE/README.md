# INTELLIGENT DJ v1.5.0 – PCM Master Engine (Fase 1)

Base técnica inicial para migrar decks y sampler a un bus maestro PCM nativo de seis buses.

**Alcance:** el bus JNI está incorporado pero aún no está conectado a ExoPlayer/AudioTrack. La grabación actual conserva MediaProjection y seguirá solicitando consentimiento por sesión. Ver `LEEME_v1.5.0_PCM_MASTER_ENGINE.txt` antes de probar.
