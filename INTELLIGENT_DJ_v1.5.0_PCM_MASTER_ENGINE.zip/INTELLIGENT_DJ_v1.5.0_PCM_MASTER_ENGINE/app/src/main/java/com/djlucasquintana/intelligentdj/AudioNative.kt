package com.djlucasquintana.intelligentdj

/** JNI API for the PCM master-bus migration. Bus map: 0/1 = decks A/B, 2..5 = sampler pads 1..4.
 * PCM is signed 16-bit interleaved stereo at 44.1 kHz. This foundation is not yet connected
 * to ExoPlayer output; the current recording path remains the Android playback-capture service.
 */
object AudioNative {
    init { System.loadLibrary("intelligent_dj_audio") }
    external fun setMasterGain(gain: Float)
    external fun getMasterGain(): Float
    external fun resetPcmBuses()
    external fun setBusGain(bus: Int, gain: Float)
    /** Push interleaved stereo PCM; returns accepted frame count. */
    external fun pushPcm(bus: Int, samples: ShortArray): Int
    /** Mix queued buses into output; returns rendered frame count. */
    external fun renderPcm(output: ShortArray, requestedFrames: Int): Int
}
