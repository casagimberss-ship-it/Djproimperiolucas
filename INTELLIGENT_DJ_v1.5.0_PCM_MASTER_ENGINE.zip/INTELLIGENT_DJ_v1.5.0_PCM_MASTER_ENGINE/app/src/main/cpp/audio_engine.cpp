#include <jni.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <mutex>
#include <vector>

namespace {
constexpr int kBusCount = 6; // Deck A, Deck B, Pads 1..4
constexpr int kChannels = 2;
constexpr int kCapacityFrames = 44100 * 8;
struct Bus {
    std::vector<int16_t> ring = std::vector<int16_t>(kCapacityFrames * kChannels, 0);
    int readFrame = 0;
    int writeFrame = 0;
    int queuedFrames = 0;
    float gain = 1.0f;
};
std::array<Bus, kBusCount> buses;
std::mutex busMutex;
std::atomic<float> masterGain{1.0f};

int16_t clamp16(float v) {
    return static_cast<int16_t>(std::max(-32768.0f, std::min(32767.0f, v)));
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_djlucasquintana_intelligentdj_AudioNative_setMasterGain(JNIEnv*, jclass, jfloat gain) {
    masterGain.store(std::clamp(gain, 0.0f, 1.5f), std::memory_order_relaxed);
}
extern "C" JNIEXPORT jfloat JNICALL
Java_com_djlucasquintana_intelligentdj_AudioNative_getMasterGain(JNIEnv*, jclass) {
    return masterGain.load(std::memory_order_relaxed);
}
extern "C" JNIEXPORT void JNICALL
Java_com_djlucasquintana_intelligentdj_AudioNative_resetPcmBuses(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(busMutex);
    for (auto& b : buses) { b.readFrame = b.writeFrame = b.queuedFrames = 0; }
}
extern "C" JNIEXPORT void JNICALL
Java_com_djlucasquintana_intelligentdj_AudioNative_setBusGain(JNIEnv*, jclass, jint bus, jfloat gain) {
    if (bus < 0 || bus >= kBusCount) return;
    std::lock_guard<std::mutex> lock(busMutex);
    buses[bus].gain = std::clamp(gain, 0.0f, 2.0f);
}
extern "C" JNIEXPORT jint JNICALL
Java_com_djlucasquintana_intelligentdj_AudioNative_pushPcm(JNIEnv* env, jclass, jint bus, jshortArray samples) {
    if (bus < 0 || bus >= kBusCount || samples == nullptr) return 0;
    const jsize count = env->GetArrayLength(samples);
    const int frames = static_cast<int>(count / kChannels);
    if (frames <= 0) return 0;
    std::vector<jshort> input(static_cast<size_t>(frames * kChannels));
    env->GetShortArrayRegion(samples, 0, frames * kChannels, input.data());
    if (env->ExceptionCheck()) return 0;
    std::lock_guard<std::mutex> lock(busMutex);
    Bus& b = buses[bus];
    const int accepted = std::min(frames, kCapacityFrames - b.queuedFrames);
    for (int i = 0; i < accepted; ++i) {
        const int dst = ((b.writeFrame + i) % kCapacityFrames) * kChannels;
        b.ring[dst] = input[i * kChannels];
        b.ring[dst + 1] = input[i * kChannels + 1];
    }
    b.writeFrame = (b.writeFrame + accepted) % kCapacityFrames;
    b.queuedFrames += accepted;
    return accepted;
}
extern "C" JNIEXPORT jint JNICALL
Java_com_djlucasquintana_intelligentdj_AudioNative_renderPcm(JNIEnv* env, jclass, jshortArray output, jint requestedFrames) {
    if (output == nullptr || requestedFrames <= 0) return 0;
    const jsize outCount = env->GetArrayLength(output);
    const int frames = std::min(requestedFrames, static_cast<int>(outCount / kChannels));
    if (frames <= 0) return 0;
    std::vector<jshort> mixed(static_cast<size_t>(frames * kChannels), 0);
    {
        std::lock_guard<std::mutex> lock(busMutex);
        const float master = masterGain.load(std::memory_order_relaxed);
        for (auto& b : buses) {
            const int take = std::min(frames, b.queuedFrames);
            for (int i = 0; i < take; ++i) {
                const int src = ((b.readFrame + i) % kCapacityFrames) * kChannels;
                for (int ch = 0; ch < kChannels; ++ch) {
                    const int idx = i * kChannels + ch;
                    mixed[idx] = clamp16(static_cast<float>(mixed[idx]) +
                        static_cast<float>(b.ring[src + ch]) * b.gain * master);
                }
            }
            b.readFrame = (b.readFrame + take) % kCapacityFrames;
            b.queuedFrames -= take;
        }
    }
    env->SetShortArrayRegion(output, 0, frames * kChannels, mixed.data());
    return frames;
}
