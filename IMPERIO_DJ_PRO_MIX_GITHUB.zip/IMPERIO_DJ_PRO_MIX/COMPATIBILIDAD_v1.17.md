# Compatibilidad y migración v1.17

- `applicationId`/namespace preservados: `com.imperio.djpromix`.
- Min SDK 26 y Java 17 conservados.
- Media3 1.5.1 actual; no se agrega dependencia de red ni servicio remoto.
- Los cuatro pads y preferencias v1.16.1 se mantienen como banco inicial legado; la migración debe copiar URIs existentes al banco `LEGACY` solo si el usuario aún no tiene bancos v1.17.
- No borrar ni renombrar claves antiguas. La migración es idempotente y conserva permisos persistentes SAF.
- Si un URI pierde permiso, marcar ese pad como “Volvé a cargar el sample”; no descartar el resto del banco.
- No cambiar versionCode/versionName hasta compilar y validar el release integrado.
