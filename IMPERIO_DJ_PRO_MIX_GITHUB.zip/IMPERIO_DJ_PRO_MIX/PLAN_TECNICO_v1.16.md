# MODO FIESTA v1.16 — SHOW & PERFORMANCE

## Selección aprobada
1 temporizador configurable; 2 cuenta regresiva/avisos; 3 cálculo de pistas; 4 cierre inteligente; 5 cronómetro por tanda; 6 Reverb automático; 7 Echo Out automático; 8 efectos manuales; 9 cadena de efectos; 10 efectos por género; 11 Brake/Backspin/Flanger/Filter/Delay; 12 sampler de 4 pads; 14 carga automática de samples; 15 bancos; 17 disparo cuantizado; 19 volumen independiente; 20 efectos por pad; 21 One Shot/Loop/Stop; 22 grabación de sesión; 23 modo actuación.

## Principios
- Offline total: sin login, servicios remotos, telemetría ni descarga de modelos/sonidos.
- Mantener Dark Profesional, marca y crédito actuales.
- No sustituir ExoPlayer ni servicios de audio existentes.
- No cambiar applicationId/namespace ni borrar preferencias, biblioteca, cues o análisis previos.
- Permisos de audio y SAF se solicitan solo cuando la función los necesita.

## Arquitectura
- SessionDurationPlanner estima cantidad de pistas usando duración media y solapamiento esperado.
- SessionCountdown controla el estado del set; la UI/servicio Android debe usar reloj monotónico y Foreground Service si el set continúa con pantalla apagada.
- SmartClosingController decide sugerencia de cierre en base al tiempo restante; nunca corta abruptamente una pista.
- TransitionEffectPlan define automatizaciones por beats. Reverb/Echo Out y demás efectos requieren DSP real integrado al grafo de audio.
- SamplerPadModel representa cuatro pads persistentes; SamplerBankStore guarda URIs SAF, modo y volumen en preferencias nuevas.
- SamplerTriggerPolicy calcula la próxima frontera de beat para cuantización.
- SamplerMixPolicy limita ganancia para conservar headroom y evitar clipping.
- Sampler playback debe mezclarse en el mismo bus/master que los decks y ser incluido en grabación si el usuario lo habilita.
- SessionRecordingPlan documenta el contrato con el grabador existente.

## Implementación por etapas
A. Temporizador y tanda: UI, persistencia de sesión, notificaciones y cierre progresivo.
B. DSP de transición: nodos Reverb, Echo/Delay, Filter, Flanger; Echo Out con rampa wet/dry y ganancia; sincronización por beat.
C. Sampler: selector SAF WAV/MP3, permisos persistentes, precarga al iniciar, cuatro reproductores/voices, One Shot/Loop/Stop, cuantización, sincronización BPM, volumen y FX por pad.
D. Bancos y actuación: bancos guardados, último banco restaurado, controles grandes y feedback visual.
E. Grabación: mezcla master incluyendo decks y opcionalmente sampler/FX, encoder y espacio libre.
F. QA: audio simultáneo, latencia, clipping, cambio de orientación, reinicio, archivos movidos, modo avión y sesiones largas.

## Reglas de seguridad de audio
- El sampler no debe bloquear los decks ni el hilo principal.
- Limitar voces simultáneas y normalizar/headroom para evitar clipping.
- Cuantización usa el reloj de audio/beat clock, no Handler/timers de UI.
- Loop debe ser gapless o declarar limitación según decoder/formato.
- Si falta permiso SAF o un sample ya no existe, mostrar pad vacío/error recuperable sin cerrar la app.
- Efectos automáticos deben tener bypass físico/UI inmediato.
- Cierre inteligente propone transición final y conserva Stop/Pause manual.

## Aceptación
- Set de 15–720 minutos con cuenta regresiva correcta en background.
- Cuatro pads se restauran al reiniciar y recargan si las URIs siguen autorizadas.
- One Shot/Loop/Stop funcionan durante reproducción de ambos decks.
- Cuantización con tolerancia objetivo menor a 20 ms en dispositivo de referencia.
- Cada pad tiene volumen independiente y control de efectos/bypass.
- Reverb/Echo Out se sincronizan a beats y no producen clipping audible.
- Grabación refleja la mezcla master según opciones elegidas.
- Todas las funciones previas pasan pruebas de regresión.
