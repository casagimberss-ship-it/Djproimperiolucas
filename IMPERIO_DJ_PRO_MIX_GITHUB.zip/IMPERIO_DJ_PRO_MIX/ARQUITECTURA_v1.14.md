# Arquitectura v1.14 — módulos y contratos

| Módulo | Responsabilidad | Estado del paquete |
|---|---|---|
| LoopRollSlicer | Cuantización, regiones y slices | Núcleo lógico inicial, sin integración PCM/UI |
| VocalActivityAnalyzer | Contrato de inferencia vocal local | Interfaz; falta modelo validado |
| PredictiveTransitionEngine | Ranking explicable de transiciones | Prototipo determinista |
| MusicLightSyncEngine | Eventos musicales para escenas | Motor lógico; sin transporte DMX |

## Límites de seguridad
- Ningún módulo nuevo debe ejecutarse en el hilo principal si procesa audio.
- No compartir ni mutar listas internas de ExoPlayer desde UI sin sincronización.
- Los cambios de pista, buffering y stop invalidan loops pendientes.
- Todas las salidas de luz deben limitar intensidad y permitir blackout inmediato.
- Toda recomendación predictiva es consultiva por defecto.
