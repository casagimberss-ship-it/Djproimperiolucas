# MODO FIESTA v1.11.0

- Rebranding visual a MODO FIESTA y crédito DJ Lucas Quintana.
- Onda completa con zoom y desplazamiento.
- Marcadores de estructura musical aproximados derivados del análisis RMS.
- Beat Sync con control de confianza y límite de corrección ±6 %.
- Grabación interna MP3 320 kbps conservada.
- IA neuronal local y aprendizaje progresivo conservados.
- Identidad de paquete mantenida para facilitar actualización sin perder datos.
