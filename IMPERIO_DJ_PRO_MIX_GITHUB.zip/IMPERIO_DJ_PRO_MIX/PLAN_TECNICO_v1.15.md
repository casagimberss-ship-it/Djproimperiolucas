# MODO FIESTA v1.15 — SMART GENRE MIX
## Objetivo y alcance aprobado
Reconocimiento de géneros/subgéneros; importación y unión de playlists; clasificación de energía; crossfader manual/inteligente; mezcla Camelot; transiciones por frases; loops/Loop Roll/Slicer/Hot Cues; detección de estructura; Fiesta Mode; generador de tandas; DJ automático y asistido; protección vocal; aprendizaje local; recomendaciones por energía.

## Arquitectura offline
- No login, APIs remotas, telemetría, streaming obligatorio ni descarga de modelos en ejecución.
- Importación por Storage Access Framework (SAF); persistir permisos URI y deduplicar pistas.
- Reutilizar AudioAnalyzer existente para BPM, tonalidad, waveform, curva energética y marcadores estimados.
- Clasificador acústico de género/subgénero cuantizado y ejecutado localmente. No inferir subgéneros solo por BPM o nombre de archivo; usar umbral de confianza y estado Sin clasificar.
- Guardar correcciones del DJ en almacenamiento local y emplearlas como etiquetas supervisadas.
- Recomendador con género, BPM, Camelot, energía, estructura, actividad vocal y preferencias.
- ExoPlayer existente permanece como motor. Crossfader será una capa de ganancia A/B con curvas equal-power y limitación anti-clipping.
- DJ asistido recomienda solamente. DJ automático exige activación expresa, con pausa, stop, skip y toma manual inmediata.

## Etapas
A Biblioteca: importar múltiples playlists, permisos SAF, deduplicación, géneros editables y energía.
B Modelos: modelo local para género/subgénero, detector vocal y clasificación de secciones. Medir precisión con música real de cumbia clásica/villera/cheta, cuarteto, funky, RKT, RKT funky y reggaetón old school.
C Mezclador: crossfader manual/automático, preescucha, EQ, loops y Hot Cues integrados con posiciones reales del reproductor.
D Inteligencia: Camelot, frases de 8/16/32 beats, tandas, Fiesta Mode y ranking explicable.
E Aprendizaje: persistencia local, correcciones de género y preferencias; opción para reiniciar aprendizaje.
F QA: modo avión, formatos variados, sesiones largas, memoria limitada y actualización desde versión anterior.

## Criterios de aceptación
- Reproduce y analiza en modo avión.
- Playlists combinadas sin duplicados y con permisos SAF recuperables.
- Clasificación muestra confianza y permite corrección manual.
- Sin detector vocal confiable, no se activa protección vocal automática.
- DJ asistido no cambia pista sin orden del DJ.
- DJ automático tiene takeover instantáneo.
- Crossfader sin saltos ni clipping.
- Todas las recomendaciones explican género/BPM/tonalidad/energía.
- Se preservan package, preferencias, caché, cues y servicios anteriores.
