package com.imperio.djpromix
/** Offline editable taxonomy. Acoustic genre inference requires a validated local model. */
object GenreCatalog {
 data class Genre(val id:String,val label:String,val parentId:String?=null)
 val genres=listOf(Genre("cumbia","Cumbia"),Genre("cumbia_clasica","Cumbia clásica","cumbia"),Genre("cumbia_villera","Cumbia villera","cumbia"),Genre("cumbia_cheta","Cumbia cheta","cumbia"),Genre("cuarteto","Cuarteto"),Genre("cuarteto_cordobes","Cuarteto cordobés","cuarteto"),Genre("cuarteto_moderno","Cuarteto moderno","cuarteto"),Genre("funky","Funky"),Genre("rkt","RKT"),Genre("rkt_funky","RKT funky","rkt"),Genre("reggaeton","Reggaetón"),Genre("reggaeton_old","Reggaetón old school","reggaeton"),Genre("cachengue","Cachengue"),Genre("merengue","Merengue"),Genre("salsa","Salsa"),Genre("electronica","Electrónica"),Genre("unknown","Sin clasificar"))
 private val index=genres.associateBy{it.id}
 fun find(id:String)=index[id]
 fun children(id:String)=genres.filter{it.parentId==id}
 fun normalize(id:String?)=id?.takeIf{index.containsKey(it)}?:"unknown"
}
