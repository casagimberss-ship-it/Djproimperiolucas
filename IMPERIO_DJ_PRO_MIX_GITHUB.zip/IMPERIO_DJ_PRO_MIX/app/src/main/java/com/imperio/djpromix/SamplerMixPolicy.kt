package com.imperio.djpromix

/** Mix-safety helpers for sampler pads. */
object SamplerMixPolicy {
    fun outputGain(padVolume: Float, masterHeadroomDb: Float = -6f): Float {
        val headroom= Math.pow(10.0,masterHeadroomDb.coerceIn(-24f,0f)/20.0).toFloat()
        return padVolume.coerceIn(0f,1f)*headroom
    }
    fun shouldStop(mode: SamplerPadModel.Mode, oneShotFinished: Boolean): Boolean =
        mode==SamplerPadModel.Mode.ONE_SHOT && oneShotFinished
}
