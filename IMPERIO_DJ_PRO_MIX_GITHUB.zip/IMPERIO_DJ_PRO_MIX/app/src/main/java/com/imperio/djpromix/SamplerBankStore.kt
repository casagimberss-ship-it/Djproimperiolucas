package com.imperio.djpromix

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local-only sampler bank metadata. SAF permissions must be persisted by the UI when selecting files. */
class SamplerBankStore(context: Context) {
    private val prefs=context.getSharedPreferences("modo_fiesta_sampler_v116",Context.MODE_PRIVATE)
    fun saveBank(bankName: String, pads: List<SamplerPadModel.Pad>) {
        require(pads.size==4)
        val array=JSONArray()
        pads.sortedBy { it.index }.forEach { p ->
            array.put(JSONObject().put("index",p.index).put("title",p.title).put("uri",p.uri)
                .put("mode",p.mode.name).put("volume",p.volume).put("quantize",p.quantize).put("syncBpm",p.syncBpm))
        }
        prefs.edit().putString("bank_${bankName.take(40)}",array.toString()).apply()
        prefs.edit().putString("last_bank",bankName.take(40)).apply()
    }
    fun loadBank(bankName: String): List<SamplerPadModel.Pad> {
        val raw=prefs.getString("bank_${bankName.take(40)}",null) ?: return SamplerPadModel.emptyPads()
        val arr=JSONArray(raw)
        return (0 until arr.length()).mapNotNull { i ->
            val o=arr.optJSONObject(i) ?: return@mapNotNull null
            val mode=runCatching { SamplerPadModel.Mode.valueOf(o.optString("mode")) }.getOrDefault(SamplerPadModel.Mode.ONE_SHOT)
            runCatching { SamplerPadModel.Pad(o.optInt("index"),o.optString("title"),o.optString("uri").takeIf{it!="null"},mode,o.optDouble("volume",1.0).toFloat().coerceIn(0f,1f),o.optBoolean("quantize"),o.optBoolean("syncBpm")) }.getOrNull()
        }.sortedBy { it.index }.take(4).let { if(it.size==4) it else SamplerPadModel.emptyPads() }
    }
    fun lastBankName(): String? = prefs.getString("last_bank",null)
}
