package com.imperio.djpromix

/** Recording configuration contract; actual capture/encoder remains in the existing recorder service. */
data class SessionRecordingPlan(val enabled: Boolean, val format: String = "MP3", val bitrateKbps: Int = 320, val includeSampler: Boolean = true) {
    fun isValid() = format in setOf("MP3","WAV") && bitrateKbps in setOf(128,160,192,256,320)
}
