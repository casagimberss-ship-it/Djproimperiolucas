package com.imperio.djpromix

/** Offline mix modes selected for MODO FIESTA v1.18. */
object MixModeCatalog {
    enum class Mode { BEATMATCH, HARMONIC, PHRASE, INTRO, OUTRO, BASS_SWAP, VOCAL_SAFE, DROP, LOOP, PARTY_EXPLOSIVE, PARTY_PROGRESSIVE, FULL_FLOOR, NO_REPEAT, RHYTHM_CHANGE, ENERGY, PARTY_CLOSING }
    data class Profile(val mode: Mode, val label: String, val description: String)
    val profiles = listOf(
        Profile(Mode.BEATMATCH,"Beatmatch automático","Iguala tempo dentro de límites configurados"),
        Profile(Mode.HARMONIC,"Harmonic Mix","Prioriza compatibilidad Camelot cuando hay tonalidad fiable"),
        Profile(Mode.PHRASE,"Phrase Mix","Alinea entradas y salidas por frases detectadas"),
        Profile(Mode.INTRO,"Intro Mix","Busca una ventana de entrada en la introducción"),
        Profile(Mode.OUTRO,"Outro Mix","Busca una ventana de salida en el final"),
        Profile(Mode.BASS_SWAP,"Bass Swap","Planifica intercambio gradual de graves"),
        Profile(Mode.VOCAL_SAFE,"Vocal Mix","Evita solapamientos vocales detectados"),
        Profile(Mode.DROP,"Drop Mix","Programa la entrada cerca de un drop detectado"),
        Profile(Mode.LOOP,"Loop Transition","Usa un loop de salida como recurso de transición"),
        Profile(Mode.PARTY_EXPLOSIVE,"Fiesta explosiva","Mantiene energía alta"),
        Profile(Mode.PARTY_PROGRESSIVE,"Fiesta progresiva","Incrementa energía gradualmente"),
        Profile(Mode.FULL_FLOOR,"Pista llena","Prioriza canciones con puntuación local de baile"),
        Profile(Mode.NO_REPEAT,"Sin repetición","Evita repetir temas y artistas en una ventana"),
        Profile(Mode.RHYTHM_CHANGE,"Cambios de ritmo","Alterna familias rítmicas con transición controlada"),
        Profile(Mode.ENERGY,"Mix por energía","Ordena según curva objetivo de energía"),
        Profile(Mode.PARTY_CLOSING,"Cierre de fiesta","Prepara un descenso gradual hacia el tema final")
    )
}
