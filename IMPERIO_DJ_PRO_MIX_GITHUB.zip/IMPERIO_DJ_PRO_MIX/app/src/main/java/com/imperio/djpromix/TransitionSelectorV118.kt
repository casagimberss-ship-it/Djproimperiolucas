package com.imperio.djpromix

import kotlin.math.abs

/** Deterministic candidate scorer. It plans transitions; it does not control ExoPlayer. */
class TransitionSelectorV118 {
    data class Preferences(
        val maxTempoChangePercent: Double = 8.0,
        val preferHarmonic: Boolean = true,
        val avoidVocalOverlap: Boolean = true,
        val preferPhraseAlignment: Boolean = true,
        val transitionBeats: Int = 16
    )

    fun select(outgoing: TrackMixAnalysis, incoming: TrackMixAnalysis, p: Preferences = Preferences()): TransitionCandidate? {
        val a = outgoing.bpm ?: return null
        val b = incoming.bpm ?: return null
        if (outgoing.bpmConfidence < .45 || incoming.bpmConfidence < .45) return null
        val ratio = a / b
        val pct = abs(ratio - 1.0) * 100.0
        if (pct > p.maxTempoChangePercent) return null
        val reasons = mutableListOf("BPM compatible")
        var score = 0.55 + (1.0 - pct / p.maxTempoChangePercent.coerceAtLeast(0.1)) * .2
        if (p.preferHarmonic && outgoing.camelotKey != null && outgoing.camelotKey == incoming.camelotKey && outgoing.keyConfidence >= .5 && incoming.keyConfidence >= .5) {
            score += .1; reasons += "Tonalidad compatible"
        }
        if (p.preferPhraseAlignment && outgoing.phraseLengthBeats != null && incoming.phraseLengthBeats != null && outgoing.phraseLengthBeats == incoming.phraseLengthBeats) {
            score += .08; reasons += "Frases compatibles"
        }
        if (p.avoidVocalOverlap && outgoing.vocalIntervals.isNotEmpty() && incoming.vocalIntervals.isNotEmpty()) {
            score -= .08; reasons += "Revisar posible solapamiento vocal"
        }
        val out = outgoing.outroStartMs ?: 0L
        val into = incoming.introEndMs ?: 0L
        return TransitionCandidate(out, into, p.transitionBeats.coerceIn(4, 64), ratio, score.coerceIn(0.0, 1.0), reasons)
    }
}
