package com.imperio.djpromix

/** Playback-rate planning. Pitch-preserving time-stretch requires a dedicated DSP backend. */
object SamplerPitchPolicy {
    fun semitonesToRate(semitones: Float): Float? {
        if (!semitones.isFinite() || semitones !in -12f..12f) return null
        return Math.pow(2.0, semitones.toDouble() / 12.0).toFloat()
    }

    fun combinedRate(sourceBpm: Double, deckBpm: Double, semitones: Float): Float? {
        val tempo = SamplerBeatGrid.tempoRate(sourceBpm, deckBpm) ?: return null
        val pitch = semitonesToRate(semitones) ?: return null
        return (tempo * pitch).coerceIn(0.25f, 4f)
    }
}
