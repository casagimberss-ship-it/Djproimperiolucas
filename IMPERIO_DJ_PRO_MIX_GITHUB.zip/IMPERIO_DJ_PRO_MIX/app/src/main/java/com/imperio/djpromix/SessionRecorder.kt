package com.imperio.djpromix

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Build
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import kotlin.concurrent.thread

/** Captures this app's MEDIA playback and encodes stereo MP3 directly to the user-selected URI. */
class SessionRecorder(
    private val context: Context,
    private val projection: MediaProjection,
    private val destination: Uri,
    private val onFinished: (Result<Unit>) -> Unit
) {
    @Volatile private var recording = false
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private val sampleRate = 48000
    private val channels = 2
    private val bitRate = 320

    fun start(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val config = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .build()
            val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val audioRecord = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes((minBuffer.coerceAtLeast(8192)) * 2)
                .setAudioPlaybackCaptureConfig(config)
                .build()
            if (audioRecord.state != AudioRecord.STATE_INITIALIZED) { audioRecord.release(); return false }
            recorder = audioRecord
            recording = true
            audioRecord.startRecording()
            worker = thread(name = "ImperioMp3Recorder") { captureLoop() }
            true
        } catch (_: Exception) {
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            false
        }
    }

    fun stop() {
        recording = false
        try { recorder?.stop() } catch (_: Exception) {}
    }

    private fun captureLoop() {
        var result: Result<Unit>
        var lame: AndroidLame? = null
        try {
            val encoder = LameBuilder()
                .setInSampleRate(sampleRate)
                .setOutChannels(channels)
                .setOutBitrate(bitRate)
                .setOutSampleRate(sampleRate)
                .setQuality(2)
                .build()
            lame = encoder
            val output = context.contentResolver.openOutputStream(destination, "w")
                ?: throw IllegalStateException("No se pudo abrir el destino MP3")
            output.use { stream ->
                val pcm = ShortArray(8192)
                val mp3 = ByteArray(7200 + pcm.size * 5)
                while (recording) {
                    val count = recorder?.read(pcm, 0, pcm.size) ?: break
                    if (count > 0) {
                        val framesPerChannel = count / channels
                        if (framesPerChannel > 0) {
                            val encoded = encoder.encodeBufferInterLeaved(pcm, framesPerChannel, mp3)
                            if (encoded > 0) stream.write(mp3, 0, encoded)
                        }
                    } else if (count < 0 && recording) {
                        throw IllegalStateException("Error leyendo audio: $count")
                    }
                }
                val flushed = encoder.flush(mp3)
                if (flushed > 0) stream.write(mp3, 0, flushed)
                stream.flush()
            }
            result = Result.success(Unit)
        } catch (e: Exception) {
            result = Result.failure(e)
        } finally {
            recording = false
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            try { lame?.close() } catch (_: Exception) {}
            try { projection.stop() } catch (_: Exception) {}
        }
        onFinished(result)
    }
}
