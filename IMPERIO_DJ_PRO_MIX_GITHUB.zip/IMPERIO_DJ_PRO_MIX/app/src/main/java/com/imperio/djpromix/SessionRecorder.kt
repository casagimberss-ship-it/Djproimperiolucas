package com.imperio.djpromix

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Build
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.concurrent.thread

/** Captures this app's MEDIA playback (Android 10+) and saves a standard PCM WAV file. */
class SessionRecorder(
    private val context: Context,
    private val projection: MediaProjection,
    private val destination: Uri,
    private val onFinished: (Result<Unit>) -> Unit
) {
    @Volatile private var recording = false
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private val sampleRate = 48000
    private val channels = 2

    fun start(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val config = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .build()
            val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val audioRecord = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes((minBuffer.coerceAtLeast(8192)) * 2)
                .setAudioPlaybackCaptureConfig(config)
                .build()
            if (audioRecord.state != AudioRecord.STATE_INITIALIZED) { audioRecord.release(); return false }
            recorder = audioRecord
            recording = true
            audioRecord.startRecording()
            worker = thread(name = "ImperioSessionRecorder") { captureLoop() }
            true
        } catch (_: Exception) {
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            false
        }
    }

    fun stop() {
        recording = false
        try { recorder?.stop() } catch (_: Exception) {}
    }

    private fun captureLoop() {
        val temp = File(context.cacheDir, "imperio_session_recording.wav")
        var result: Result<Unit>
        try {
            FileOutputStream(temp).use { stream ->
                val out = BufferedOutputStream(stream)
                out.write(ByteArray(44))
                val buffer = ByteArray(16384)
                while (recording) {
                    val count = recorder?.read(buffer, 0, buffer.size) ?: break
                    if (count < 0) break
                    if (count > 0) out.write(buffer, 0, count)
                }
                out.flush()
            }
            recorder?.release(); recorder = null
            val dataLength = temp.length() - 44
            RandomAccessFile(temp, "rw").use { file ->
                file.seek(0); file.write(wavHeader(dataLength.toInt()))
            }
            context.contentResolver.openOutputStream(destination, "w")?.use { output -> temp.inputStream().use { it.copyTo(output) } }
                ?: throw IllegalStateException("No se pudo crear el archivo de grabación")
            temp.delete()
            result = Result.success(Unit)
        } catch (e: Exception) {
            recorder?.release(); recorder = null; temp.delete()
            result = Result.failure(e)
        } finally {
            try { projection.stop() } catch (_: Exception) {}
        }
        onFinished(result)
    }

    private fun wavHeader(dataSize: Int): ByteArray {
        val byteRate = sampleRate * channels * 2
        val h = ByteArray(44)
        fun ascii(offset: Int, value: String) { value.toByteArray(Charsets.US_ASCII).copyInto(h, offset) }
        fun le16(offset: Int, value: Int) { h[offset] = value.toByte(); h[offset + 1] = (value shr 8).toByte() }
        fun le32(offset: Int, value: Int) { for (i in 0..3) h[offset + i] = (value shr (8 * i)).toByte() }
        ascii(0, "RIFF"); le32(4, dataSize + 36); ascii(8, "WAVE"); ascii(12, "fmt ")
        le32(16, 16); le16(20, 1); le16(22, channels); le32(24, sampleRate); le32(28, byteRate)
        le16(32, channels * 2); le16(34, 16); ascii(36, "data"); le32(40, dataSize)
        return h
    }
}
