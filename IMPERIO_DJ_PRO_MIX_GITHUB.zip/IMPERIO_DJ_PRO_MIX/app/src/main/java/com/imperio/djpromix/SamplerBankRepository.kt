package com.imperio.djpromix

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local bank index for v1.17. Keeps v1.16 preferences untouched. */
class SamplerBankRepository(context: Context) {
    private val prefs = context.getSharedPreferences("modo_fiesta_sampler_banks_v117", Context.MODE_PRIVATE)

    fun bankNames(): List<String> = prefs.getString("bank_names", "")!!.split('|')
        .map { it.trim() }.filter { it.isNotEmpty() }.distinct().sorted()

    fun save(name: String, padUris: List<String?>): Boolean {
        val clean = name.trim().take(32)
        if (clean.isBlank() || padUris.size != 4) return false
        val names = (bankNames() + clean).distinct().sorted()
        val data = JSONArray().apply { padUris.forEach { put(it ?: JSONObject.NULL) } }
        prefs.edit().putString("bank_$clean", data.toString()).putString("bank_names", names.joinToString("|"))
            .putString("last_bank", clean).apply()
        return true
    }

    fun load(name: String): List<String?>? {
        val raw = prefs.getString("bank_${name.take(32)}", null) ?: return null
        return runCatching {
            val data = JSONArray(raw)
            if (data.length() != 4) return null
            (0 until 4).map { i -> data.optString(i).takeUnless { it == "null" || it.isBlank() } }
        }.getOrNull()
    }

    fun lastBank(): String? = prefs.getString("last_bank", null)
}
