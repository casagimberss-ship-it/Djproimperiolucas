package com.imperio.djpromix
object EnergyClassifier {
 enum class Level{LOW,MEDIUM,HIGH}
 data class Result(val level:Level,val average:Float,val peak:Float)
 fun classify(curve:String?):Result?{val v=curve?.split(",")?.mapNotNull{it.toFloatOrNull()}?.filter{it in 0f..5f}?:return null;if(v.isEmpty())return null;val a=v.average().toFloat();val p=v.maxOrNull()?:a;return Result(when{a<1.8f->Level.LOW;a<3.5f->Level.MEDIUM;else->Level.HIGH},a,p)}
}
