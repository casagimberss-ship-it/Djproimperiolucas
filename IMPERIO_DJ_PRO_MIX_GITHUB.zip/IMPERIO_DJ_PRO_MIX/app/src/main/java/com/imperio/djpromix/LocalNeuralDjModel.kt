package com.imperio.djpromix

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.tanh

/** Small on-device MLP. Pairwise preferences are learned locally when the DJ overrides the suggested next track. */
class LocalNeuralDjModel(context: Context) {
    private val prefs = context.getSharedPreferences("imperio_neural_dj", Context.MODE_PRIVATE)
    private val inputSize = 6
    private val hiddenSize = 8
    private val w1 = Array(hiddenSize) { h -> DoubleArray(inputSize) { i -> (((h + 3) * (i + 5) % 11) - 5) * 0.025 } }
    private val b1 = DoubleArray(hiddenSize)
    private val w2 = DoubleArray(hiddenSize)
    private var b2 = 0.0
    var learnedComparisons: Int = 0
        private set

    init { restore() }

    fun choose(current: AiDjEngine.Candidate, candidates: List<AiDjEngine.Candidate>, style: AiDjEngine.Style): AiDjEngine.Decision? {
        if (candidates.isEmpty()) return null
        val baseline = AiDjEngine.choose(current, candidates, style) ?: return null
        if (learnedComparisons < 3) return baseline
        val ranked = candidates.map { candidate ->
            val heuristic = AiDjEngine.choose(current, listOf(candidate), style)?.score ?: 1000
            val learned = forward(features(current, candidate, style))
            candidate to (heuristic - learned * 18.0)
        }.minByOrNull { it.second } ?: return baseline
        return AiDjEngine.Decision(ranked.first.index, ranked.second.toInt(), "red neuronal local · ${learnedComparisons} preferencias aprendidas")
    }

    /** Learns that a manually chosen track is preferred over the AI suggestion. */
    fun learn(current: AiDjEngine.Candidate, chosen: AiDjEngine.Candidate, rejected: AiDjEngine.Candidate, style: AiDjEngine.Style) {
        if (chosen.index == rejected.index) return
        val good = features(current, chosen, style)
        val bad = features(current, rejected, style)
        repeat(8) {
            val goodOut = forward(good)
            val badOut = forward(bad)
            val probability = 1.0 / (1.0 + exp((badOut - goodOut).coerceIn(-20.0, 20.0)))
            val error = (1.0 - probability) * 0.035
            val goodHidden = DoubleArray(hiddenSize) { h -> tanh(b1[h] + (0 until inputSize).sumOf { i -> w1[h][i] * good[i] }) }
            val badHidden = DoubleArray(hiddenSize) { h -> tanh(b1[h] + (0 until inputSize).sumOf { i -> w1[h][i] * bad[i] }) }
            for (h in 0 until hiddenSize) {
                val gradGood = error * goodHidden[h]
                val gradBad = -error * badHidden[h]
                val outGrad = error * w2[h]
                w2[h] += gradGood + gradBad
                val dzGood = outGrad * (1.0 - goodHidden[h] * goodHidden[h])
                val dzBad = -outGrad * (1.0 - badHidden[h] * badHidden[h])
                b1[h] += dzGood + dzBad
                for (i in 0 until inputSize) w1[h][i] += dzGood * good[i] + dzBad * bad[i]
            }
        }
        learnedComparisons++
        persist()
    }

    private fun features(a: AiDjEngine.Candidate, b: AiDjEngine.Candidate, style: AiDjEngine.Style): DoubleArray {
        val tempo = if (a.bpm != null && b.bpm != null) minOf(abs(a.bpm - b.bpm), abs(a.bpm - b.bpm * 2), abs(a.bpm * 2 - b.bpm)) / 40.0 else 1.0
        val key = if (a.key != null && b.key != null) keyDistance(a.key, b.key) / 7.0 else 1.0
        val currentEnergy = a.energy ?: 3
        val target = when (style) { AiDjEngine.Style.PROGRESSIVE -> (currentEnergy + 1).coerceAtMost(5); AiDjEngine.Style.HITS -> 5; else -> currentEnergy }
        val energy = if (b.energy == null) 1.0 else abs(b.energy - target) / 4.0
        return doubleArrayOf(tempo.coerceIn(0.0, 1.0), key.coerceIn(0.0, 1.0), energy, if (b.entrySeconds == null) 1.0 else 0.0, 1.0 - (b.beatConfidence ?: 0f).coerceIn(0f, 1f), if (b.recentlyPlayed) 1.0 else 0.0)
    }

    private fun forward(x: DoubleArray): Double {
        val hidden = DoubleArray(hiddenSize) { h -> tanh(b1[h] + (0 until inputSize).sumOf { i -> w1[h][i] * x[i] }) }
        return b2 + (0 until hiddenSize).sumOf { h -> w2[h] * hidden[h] }
    }

    private fun keyDistance(a: String, b: String): Int {
        val x = Regex("(1[0-2]|[1-9])([AB])").matchEntire(a) ?: return 7
        val y = Regex("(1[0-2]|[1-9])([AB])").matchEntire(b) ?: return 7
        val n = x.groupValues[1].toInt(); val m = y.groupValues[1].toInt()
        return minOf(abs(n - m), 12 - abs(n - m)) + if (x.groupValues[2] == y.groupValues[2]) 0 else 1
    }

    private fun persist() {
        val root = JSONObject().put("w1", JSONArray().also { a -> w1.forEach { row -> a.put(JSONArray().also { r -> row.forEach { r.put(it) } }) } })
            .put("b1", JSONArray().also { a -> b1.forEach { a.put(it) } })
            .put("w2", JSONArray().also { a -> w2.forEach { a.put(it) } }).put("b2", b2).put("count", learnedComparisons)
        prefs.edit().putString("model", root.toString()).apply()
    }

    private fun restore() {
        try {
            val root = JSONObject(prefs.getString("model", null) ?: return)
            val rows = root.getJSONArray("w1"); val biases = root.getJSONArray("b1"); val out = root.getJSONArray("w2")
            for (h in 0 until minOf(hiddenSize, rows.length())) { val row = rows.getJSONArray(h); for (i in 0 until minOf(inputSize, row.length())) w1[h][i] = row.getDouble(i); if (h < biases.length()) b1[h] = biases.getDouble(h); if (h < out.length()) w2[h] = out.getDouble(h) }
            b2 = root.optDouble("b2", 0.0); learnedComparisons = root.optInt("count", 0)
        } catch (_: Exception) { learnedComparisons = 0 }
    }
}
