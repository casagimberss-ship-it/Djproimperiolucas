package com.imperio.djpromix

/** Reduces decoded mono PCM samples to normalized min/max peaks for a UI waveform.
 * Decoding/resampling is supplied by the audio layer; this class performs no I/O.
 */
object SamplerWaveformAnalyzer {
    data class Peak(val min: Float, val max: Float)

    fun analyze(samples: FloatArray, targetBars: Int = 240): List<Peak> {
        require(targetBars > 0)
        if (samples.isEmpty()) return emptyList()
        val bars = minOf(targetBars, samples.size)
        return List(bars) { bar ->
            val start = bar * samples.size / bars
            val end = maxOf(start + 1, (bar + 1) * samples.size / bars)
            var low = 1f
            var high = -1f
            for (i in start until minOf(end, samples.size)) {
                val value = samples[i].takeIf { it.isFinite() }?.coerceIn(-1f, 1f) ?: 0f
                low = minOf(low, value)
                high = maxOf(high, value)
            }
            Peak(low, high)
        }
    }
}
