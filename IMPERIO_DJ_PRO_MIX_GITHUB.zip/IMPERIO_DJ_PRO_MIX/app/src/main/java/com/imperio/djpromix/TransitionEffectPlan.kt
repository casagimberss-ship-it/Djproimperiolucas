package com.imperio.djpromix

/** Describes effect automation; audio DSP nodes must be implemented in the playback graph. */
object TransitionEffectPlan {
    enum class Effect { REVERB, ECHO_OUT, ECHO, FILTER, FLANGER, DELAY, BRAKE, BACKSPIN }
    data class Step(val effect: Effect, val startBeatOffset: Int, val durationBeats: Int, val wetPercent: Int)
    fun defaultChain(includeReverb: Boolean = true, includeEchoOut: Boolean = true): List<Step> = buildList {
        if (includeReverb) add(Step(Effect.REVERB,0,16,24))
        if (includeEchoOut) add(Step(Effect.ECHO_OUT,8,8,35))
    }
    fun validate(steps: List<Step>) = steps.all { it.startBeatOffset>=0 && it.durationBeats in 1..64 && it.wetPercent in 0..100 }
}
