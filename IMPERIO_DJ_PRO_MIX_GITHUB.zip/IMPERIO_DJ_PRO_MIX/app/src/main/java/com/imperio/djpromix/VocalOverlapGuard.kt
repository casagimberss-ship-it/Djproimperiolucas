package com.imperio.djpromix
object VocalOverlapGuard {
 data class Decision(val allowFullBlend:Boolean,val suggestedCrossfadePercent:Int,val reason:String)
 /** Null means no validated local vocal inference: do not block or automate on a guess. */
 fun evaluate(current:Boolean?,next:Boolean?):Decision=if(current==null||next==null)Decision(true,50,"Detector vocal no disponible; usar preescucha") else if(current&&next)Decision(false,25,"Dos voces simultáneas: reducir solapamiento") else Decision(true,50,"Solapamiento vocal aceptable")
}
