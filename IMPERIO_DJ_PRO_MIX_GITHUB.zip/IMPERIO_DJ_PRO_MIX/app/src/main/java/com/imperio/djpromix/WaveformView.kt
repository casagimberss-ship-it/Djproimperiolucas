package com.imperio.djpromix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.max

/** Draws peak values decoded from the selected track's PCM audio, not decorative sample bars. */
class WaveformView(context: Context) : View(context) {
    private val bars = mutableListOf<Float>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var playhead = 0f

    fun setWaveform(encoded: String?) {
        bars.clear()
        if (!encoded.isNullOrBlank()) {
            encoded.split(',').forEach { token ->
                token.toFloatOrNull()?.let { bars.add((it / 1000f).coerceIn(0.015f, 1f)) }
            }
        }
        invalidate()
    }

    fun setPlayhead(fraction: Float) {
        playhead = fraction.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val mid = height / 2f
        val count = bars.size
        if (count == 0) {
            paint.color = 0xFF9AA7B7.toInt()
            paint.textSize = 12f * resources.displayMetrics.scaledDensity
            canvas.drawText("Importá y analizá una pista para generar su onda", 8f, mid + paint.textSize / 3f, paint)
            return
        }
        val gap = max(1f, width / (count * 3f))
        val barWidth = max(1f, (width - gap * (count - 1)) / count)
        val playedUntil = (playhead * count).toInt()
        bars.forEachIndexed { index, amplitude ->
            val x = index * (barWidth + gap)
            val half = max(2f, amplitude * (height * 0.43f))
            paint.color = if (index <= playedUntil) 0xFFFF526B.toInt() else 0xFF8B3446.toInt()
            canvas.drawRoundRect(RectF(x, mid - half, x + barWidth, mid + half), barWidth / 2f, barWidth / 2f, paint)
        }
        val cursorX = playhead * width
        paint.color = 0xFFFFFFFF.toInt()
        paint.strokeWidth = 2f * resources.displayMetrics.density
        canvas.drawLine(cursorX, 2f, cursorX, height - 2f, paint)
    }
}
