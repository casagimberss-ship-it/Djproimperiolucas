package com.imperio.djpromix

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Full-track waveform with pinch zoom, drag navigation and approximate musical structure cues. */
class WaveformView(context: Context) : View(context) {
    private val bars = mutableListOf<Float>()
    private val markers = mutableListOf<Pair<Float, String>>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var playhead = 0f
    private var zoom = 1f
    private var windowStart = 0f
    private var lastTouchX = 0f
    private var scaling = false
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean { scaling = true; return true }
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val old = zoom
            zoom = (zoom * detector.scaleFactor).coerceIn(1f, 8f)
            val focus = (windowStart + detector.focusX / width.coerceAtLeast(1) / old).coerceIn(0f, 1f)
            windowStart = (focus - detector.focusX / width.coerceAtLeast(1) / zoom).coerceIn(0f, 1f - 1f / zoom)
            invalidate(); return true
        }
        override fun onScaleEnd(detector: ScaleGestureDetector) { scaling = false }
    })

    fun setWaveform(encoded: String?) {
        bars.clear()
        if (!encoded.isNullOrBlank()) encoded.split(',').forEach { token -> token.toFloatOrNull()?.let { bars.add((it / 1000f).coerceIn(0.015f, 1f)) } }
        zoom = 1f; windowStart = 0f; invalidate()
    }

    fun setStructureMarkers(encoded: String?) {
        markers.clear()
        if (!encoded.isNullOrBlank()) encoded.split(';').forEach { token ->
            val parts = token.split(':', limit = 2)
            if (parts.size == 2) parts[0].toFloatOrNull()?.let { markers.add(it.coerceIn(0f, 1f) to parts[1]) }
        }
        invalidate()
    }

    fun setPlayhead(fraction: Float) { playhead = fraction.coerceIn(0f, 1f); invalidate() }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastTouchX = event.x; return true }
            MotionEvent.ACTION_MOVE -> if (!scaleDetector.isInProgress && !scaling && zoom > 1f) {
                val delta = (lastTouchX - event.x) / width.coerceAtLeast(1) / zoom
                windowStart = (windowStart + delta).coerceIn(0f, 1f - 1f / zoom)
                lastTouchX = event.x; invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { scaling = false; performClick(); return true }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val mid = height / 2f
        if (bars.isEmpty()) {
            paint.color = 0xFF9AA7B7.toInt(); paint.textSize = 12f * resources.displayMetrics.scaledDensity
            canvas.drawText("Importá y analizá una pista para generar su onda", 8f, mid + paint.textSize / 3f, paint); return
        }
        val start = (windowStart * bars.size).toInt().coerceIn(0, bars.lastIndex)
        val visible = (bars.size / zoom).toInt().coerceAtLeast(1)
        val end = min(bars.size, start + visible)
        val count = end - start
        val gap = max(1f, width / (count * 3f))
        val barWidth = max(1f, (width - gap * (count - 1)) / count)
        bars.subList(start, end).forEachIndexed { local, amplitude ->
            val global = start + local
            val x = local * (barWidth + gap)
            val half = max(2f, amplitude * (height * 0.40f))
            paint.color = if (global.toFloat() / bars.size <= playhead) 0xFFFF526B.toInt() else 0xFF8B3446.toInt()
            canvas.drawRoundRect(RectF(x, mid - half, x + barWidth, mid + half), barWidth / 2f, barWidth / 2f, paint)
        }
        markers.forEach { (position, label) ->
            if (position >= windowStart && position <= windowStart + 1f / zoom) {
                val x = ((position - windowStart) * zoom * width)
                paint.color = 0xFFFFD166.toInt(); paint.strokeWidth = 1.5f * resources.displayMetrics.density
                canvas.drawLine(x, 2f, x, height - 2f, paint)
                paint.textSize = 8f * resources.displayMetrics.scaledDensity
                canvas.drawText(label, (x + 2f).coerceAtMost(width - 58f), 10f * resources.displayMetrics.scaledDensity, paint)
            }
        }
        if (playhead >= windowStart && playhead <= windowStart + 1f / zoom) {
            val x = (playhead - windowStart) * zoom * width
            paint.color = 0xFFFFFFFF.toInt(); paint.strokeWidth = 2f * resources.displayMetrics.density
            canvas.drawLine(x, 2f, x, height - 2f, paint)
        }
    }
}
