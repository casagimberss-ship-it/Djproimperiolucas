package com.imperio.djpromix
object PhraseTransitionPlanner {
 data class Plan(val startAtSeconds:Double,val beats:Int,val durationSeconds:Double,val confidence:Float,val note:String)
 fun plan(currentBpm:Int?,nextBpm:Int?,entrySeconds:Int?,phraseBeats:Int=32):Plan?{if(currentBpm !in 60..200||nextBpm !in 60..200)return null;val beats=phraseBeats.coerceIn(4,64);val avg=(currentBpm!!+nextBpm!!)/2.0;return Plan((entrySeconds?:0).coerceAtLeast(0).toDouble(),beats,beats*60.0/avg,if(entrySeconds==null) 0.45f else 0.72f,"Frase estimada; confirmar mediante preescucha")}
}
