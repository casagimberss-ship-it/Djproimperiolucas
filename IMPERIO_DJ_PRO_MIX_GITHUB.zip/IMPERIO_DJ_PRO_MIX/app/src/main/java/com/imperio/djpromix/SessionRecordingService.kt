package com.imperio.djpromix

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Foreground service required by modern Android while capturing app playback. */
class SessionRecordingService : Service() {
    private var recorder: SessionRecorder? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { recorder?.stop(); return START_NOT_STICKY }
            ACTION_START -> startCapture(intent)
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        createChannel()
        startForeground(NOTIFICATION_ID, notification())
        try {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            @Suppress("DEPRECATION")
            val data = (if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else intent.getParcelableExtra(EXTRA_DATA))
                ?: throw IllegalStateException("Falta autorización de captura")
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = manager.getMediaProjection(resultCode, data)
            val uri = intent.data ?: throw IllegalStateException("Falta el destino del archivo")
            val session = SessionRecorder(this, projection, uri) { result ->
                getSharedPreferences("imperio_party", MODE_PRIVATE).edit().putBoolean("recordingActive", false).apply()
                sendBroadcast(Intent(ACTION_FINISHED).setPackage(packageName).putExtra(EXTRA_SUCCESS, result.isSuccess).putExtra(EXTRA_ERROR, result.exceptionOrNull()?.message ?: ""))
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            recorder = session
            if (!session.start()) {
                projection.stop()
                throw IllegalStateException("No se pudo iniciar AudioRecord")
            }
            getSharedPreferences("imperio_party", MODE_PRIVATE).edit().putBoolean("recordingActive", true).apply()
        } catch (e: Exception) {
            getSharedPreferences("imperio_party", MODE_PRIVATE).edit().putBoolean("recordingActive", false).apply()
            sendBroadcast(Intent(ACTION_FINISHED).setPackage(packageName).putExtra(EXTRA_SUCCESS, false).putExtra(EXTRA_ERROR, e.message ?: "Error de captura"))
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun notification(): Notification {
        val stopIntent = PendingIntent.getService(this, 31, Intent(this, SessionRecordingService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("IMPERIO DJ PRO MIX")
            .setContentText("Grabando sesión de audio")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Detener grabación", stopIntent)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Grabación de sesión", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    companion object {
        const val ACTION_START = "com.imperio.djpromix.RECORD_START"
        const val ACTION_STOP = "com.imperio.djpromix.RECORD_STOP"
        const val ACTION_FINISHED = "com.imperio.djpromix.RECORD_FINISHED"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_SUCCESS = "success"
        const val EXTRA_ERROR = "error"
        private const val CHANNEL_ID = "imperio_session_recording"
        private const val NOTIFICATION_ID = 6202
    }
}
