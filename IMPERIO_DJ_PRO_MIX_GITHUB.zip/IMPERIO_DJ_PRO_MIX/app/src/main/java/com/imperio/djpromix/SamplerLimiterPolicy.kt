package com.imperio.djpromix

/** Peak safety policy for a future audio callback; not a replacement for a real-time limiter. */
object SamplerLimiterPolicy {
    data class Gain(val linear: Float, val reductionDb: Float)

    fun gainForPeak(peak: Float, ceiling: Float = 0.8912509f): Gain {
        val safePeak = if (peak.isFinite()) kotlin.math.abs(peak) else 0f
        val target = ceiling.coerceIn(0.1f, 1f)
        val gain = if (safePeak <= target || safePeak == 0f) 1f else target / safePeak
        val db = if (gain >= 1f) 0f else (20.0 * kotlin.math.log10(gain.toDouble())).toFloat()
        return Gain(gain, db)
    }
}
