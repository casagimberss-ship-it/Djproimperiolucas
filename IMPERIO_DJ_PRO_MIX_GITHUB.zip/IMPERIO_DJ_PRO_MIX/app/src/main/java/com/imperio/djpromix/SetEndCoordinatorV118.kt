package com.imperio.djpromix

/** State machine specification for end-of-set behavior. Host must feed real player callbacks. */
class SetEndCoordinatorV118 {
    enum class State { IDLE, RUNNING, WAITING_FOR_CURRENT_TRACK, STOPPING_PLAYERS, FINALIZING_RECORDING, SAVING_STATS, FINISHED, ERROR }
    enum class Event { START, TIMER_REACHED_ZERO, CURRENT_TRACK_ENDED, PLAYERS_STOPPED, RECORDING_CLOSED, STATS_SAVED, FAILURE }
    var state: State = State.IDLE
        private set

    fun dispatch(event: Event): State {
        state = when (state to event) {
            State.IDLE to Event.START -> State.RUNNING
            State.RUNNING to Event.TIMER_REACHED_ZERO -> State.WAITING_FOR_CURRENT_TRACK
            State.WAITING_FOR_CURRENT_TRACK to Event.CURRENT_TRACK_ENDED -> State.STOPPING_PLAYERS
            State.STOPPING_PLAYERS to Event.PLAYERS_STOPPED -> State.FINALIZING_RECORDING
            State.FINALIZING_RECORDING to Event.RECORDING_CLOSED -> State.SAVING_STATS
            State.SAVING_STATS to Event.STATS_SAVED -> State.FINISHED
            else -> if (event == Event.FAILURE) State.ERROR else state
        }
        return state
    }
}
