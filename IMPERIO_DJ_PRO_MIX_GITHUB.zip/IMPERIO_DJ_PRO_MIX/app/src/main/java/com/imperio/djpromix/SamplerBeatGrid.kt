package com.imperio.djpromix

/** Beat-grid math. The deck must provide a measured BPM and phase from its analyzer. */
object SamplerBeatGrid {
    enum class Quantize(val beats: Int) { OFF(0), BEAT(1), BAR_1(4), BAR_2(8) }

    data class Trigger(val delayMs: Long, val targetBeat: Long)

    fun nextTrigger(bpm: Double, beatPosition: Double, quantize: Quantize): Trigger? {
        if (bpm !in 40.0..240.0 || !beatPosition.isFinite() || beatPosition < 0.0) return null
        if (quantize == Quantize.OFF) return Trigger(0L, beatPosition.toLong())
        val unit = quantize.beats.toDouble()
        val target = kotlin.math.ceil((beatPosition - 1e-9) / unit) * unit
        val delay = ((target - beatPosition) * 60_000.0 / bpm).toLong().coerceAtLeast(0L)
        return Trigger(delay, target.toLong())
    }

    /** Rate multiplier for tempo matching without pitch preservation. */
    fun tempoRate(sourceBpm: Double, deckBpm: Double): Float? {
        if (sourceBpm !in 40.0..240.0 || deckBpm !in 40.0..240.0) return null
        return (deckBpm / sourceBpm).toFloat().coerceIn(0.5f, 2.0f)
    }
}
