package com.imperio.djpromix

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.*

/** Decodes the complete audio track and estimates tempo, key, structure and waveform from PCM audio. */
object AudioAnalyzer {
    data class Result(val bpm: Int?, val camelot: String?, val confidence: Float, val introSeconds: Int?, val entrySeconds: Int?, val energyCurve: String?, val beatConfidence: Float, val waveform: String?, val structureMarkers: String?)
    private const val TARGET_RATE = 11025

    fun analyze(context: Context, uri: Uri): Result {
        val pcm = decode(context, uri)
        if (pcm.size < TARGET_RATE * 8) return Result(null, null, 0f, null, null, null, 0f, null, null)
        val bpm = estimateBpm(pcm)
        val (key, confidence) = estimateKey(pcm)
        val structure = analyzeStructure(pcm, bpm)
        return Result(bpm, key, confidence, structure.intro, structure.entry, structure.curve, structure.beatConfidence, buildWaveform(pcm), structure.markers)
    }

    private fun decode(context: Context, uri: Uri): FloatArray {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        val samples = FloatAccumulator(TARGET_RATE * 30)
        try {
            extractor.setDataSource(context, uri, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { track = i; format = f; break }
            }
            if (track < 0) return FloatArray(0)
            val audioFormat = format ?: return FloatArray(0)
            extractor.selectTrack(track)
            val mime = audioFormat.getString(MediaFormat.KEY_MIME) ?: return FloatArray(0)
            val decoder = MediaCodec.createDecoderByType(mime)
            codec = decoder
            decoder.configure(audioFormat, null, null, 0)
            decoder.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var sampleRate = if (audioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (audioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var pcmFloat = false
            var sourceIndex = 0L
            var nextTarget = 0L
            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = decoder.dequeueInputBuffer(10000)
                    if (inIndex >= 0) {
                        val input = decoder.getInputBuffer(inIndex)!!
                        input.clear()
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val outIndex = decoder.dequeueOutputBuffer(info, 10000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val out = decoder.outputFormat
                        sampleRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        pcmFloat = out.containsKey(MediaFormat.KEY_PCM_ENCODING) && out.getInteger(MediaFormat.KEY_PCM_ENCODING) == 4
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outIndex >= 0) {
                        val output = decoder.getOutputBuffer(outIndex)
                        if (output != null && info.size > 0) {
                            output.order(ByteOrder.LITTLE_ENDIAN)
                            val start = info.offset
                            val end = info.offset + info.size
                            output.position(start); output.limit(end)
                            val frameBytes = channels * if (pcmFloat) 4 else 2
                            while (output.remaining() >= frameBytes) {
                                var mono = 0f
                                repeat(channels) {
                                    mono += if (pcmFloat) output.float else output.short / 32768f
                                }
                                mono /= channels.coerceAtLeast(1)
                                // Resample by nearest-neighbour; sufficient for coarse music analysis.
                                if (sourceIndex * TARGET_RATE >= nextTarget * sampleRate) {
                                    samples.add(mono)
                                    nextTarget++
                                }
                                sourceIndex++
                            }
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(outIndex, false)
                    }
                }
            }
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            extractor.release()
        }
        return samples.toArray()
    }


    private class FloatAccumulator(initialCapacity: Int) {
        private var data = FloatArray(initialCapacity.coerceAtLeast(1024))
        var size: Int = 0
            private set
        fun add(value: Float) {
            if (size == data.size) data = data.copyOf(data.size + data.size / 2)
            data[size++] = value
        }
        fun toArray(): FloatArray = data.copyOf(size)
    }

    /** 240 normalized peak buckets from decoded PCM; represents the analyzed complete decoded track. */
    private fun buildWaveform(samples: FloatArray, buckets: Int = 240): String {
        if (samples.isEmpty()) return ""
        val result = ArrayList<String>(buckets)
        for (bucket in 0 until buckets) {
            val start = bucket * samples.size / buckets
            val end = ((bucket + 1) * samples.size / buckets).coerceAtLeast(start + 1).coerceAtMost(samples.size)
            var peak = 0f
            for (i in start until end) peak = max(peak, abs(samples[i]))
            result.add((peak.coerceIn(0f, 1f) * 1000f).roundToInt().toString())
        }
        return result.joinToString(",")
    }

    /** Coarse structure scan of the decoded complete decoded track; markers are estimates, not phrase/downbeat labels. */
    private fun analyzeStructure(x: FloatArray, bpm: Int?): Structure {
        val frame = TARGET_RATE / 2 // 0.5 second RMS windows
        val rms = ArrayList<Double>()
        var offset = 0
        while (offset < x.size) {
            val end = min(x.size, offset + frame)
            var sum = 0.0
            for (i in offset until end) sum += x[i].toDouble() * x[i]
            rms.add(sqrt(sum / (end - offset).coerceAtLeast(1)))
            offset = end
        }
        if (rms.isEmpty()) return Structure(null, null, null, 0f, null)
        val peak = rms.maxOrNull() ?: 0.0
        val activeThreshold = max(0.008, peak * 0.12)
        val firstActive = rms.indexOfFirst { it >= activeThreshold }.let { if (it < 0) 0 else it }
        val intro = (firstActive * 0.5).roundToInt()
        // Find the strongest 4-second RMS window in the first 30 seconds as a useful suggested entry.
        val window = 8
        var bestAt = firstActive
        var bestEnergy = Double.NEGATIVE_INFINITY
        val limit = min(rms.size, 60)
        for (i in firstActive until limit) {
            val end = min(limit, i + window)
            if (end - i < 3) continue
            val avg = rms.subList(i, end).average()
            if (avg > bestEnergy) { bestEnergy = avg; bestAt = i }
        }
        val entry = (bestAt * 0.5).roundToInt()
        val bins = 8
        val curve = (0 until bins).joinToString(",") { bin ->
            val start = bin * rms.size / bins
            val end = max(start + 1, (bin + 1) * rms.size / bins).coerceAtMost(rms.size)
            val avg = rms.subList(start, end).average()
            if (peak <= 0.0) "0" else ((avg / peak) * 5.0).roundToInt().coerceIn(0, 5).toString()
        }
        val confidence = if (bpm == null || rms.size < 20) 0f else {
            val lag = (120.0 / bpm / 0.5).roundToInt().coerceAtLeast(1)
            var corr = 0.0; var base = 0.0
            for (i in lag until rms.size) { corr += rms[i] * rms[i-lag]; base += rms[i] * rms[i] }
            (corr / base.coerceAtLeast(1e-9)).toFloat().coerceIn(0f, 1f)
        }
        // Approximate cues are derived from the full-track RMS envelope; they are suggestions, not semantic certainty.
        val peakIndex = rms.indices.maxByOrNull { rms[it] } ?: firstActive
        val riseIndex = (1 until rms.size).maxByOrNull { i -> (rms[i] - rms[i - 1]).coerceAtLeast(0.0) } ?: bestAt
        val outroIndex = (rms.size * 0.88).toInt().coerceIn(0, rms.lastIndex)
        val markers = listOf(
            "${(firstActive.toDouble() / rms.size).coerceIn(0.0, 1.0)}:INTRO",
            "${(bestAt.toDouble() / rms.size).coerceIn(0.0, 1.0)}:ENTRADA",
            "${(riseIndex.toDouble() / rms.size).coerceIn(0.0, 1.0)}:SUBIDA",
            "${(peakIndex.toDouble() / rms.size).coerceIn(0.0, 1.0)}:ENERGÍA",
            "${outroIndex.toDouble() / rms.size}:OUTRO*"
        ).joinToString(";")
        return Structure(intro, entry, curve, confidence, markers)
    }

    private data class Structure(val intro: Int?, val entry: Int?, val curve: String?, val beatConfidence: Float, val markers: String?)

    private fun estimateBpm(x: FloatArray): Int? {
        val win = 1024; val hop = 512
        val env = FloatArray((x.size - win).coerceAtLeast(0) / hop)
        for (i in env.indices) {
            var e = 0.0
            val start = i * hop
            for (j in 0 until win) { val v = x[start + j]; e += v * v }
            env[i] = sqrt(e / win).toFloat()
        }
        if (env.size < 40) return null
        val diff = FloatArray(env.size) { i -> max(0f, env[i] - if (i > 0) env[i - 1] else 0f) }
        val minLag = (60.0 * TARGET_RATE / hop / 180.0).roundToInt().coerceAtLeast(1)
        val maxLag = (60.0 * TARGET_RATE / hop / 65.0).roundToInt().coerceAtMost(diff.size / 2)
        var bestLag = -1; var best = Double.NEGATIVE_INFINITY
        for (lag in minLag..maxLag) {
            var score = 0.0
            for (i in lag until diff.size) score += diff[i] * diff[i - lag]
            if (score > best) { best = score; bestLag = lag }
        }
        if (bestLag <= 0) return null
        var bpm = (60.0 * TARGET_RATE / (hop * bestLag)).roundToInt()
        while (bpm < 80) bpm *= 2
        while (bpm > 160) bpm /= 2
        return bpm.takeIf { it in 60..200 }
    }

    private fun estimateKey(x: FloatArray): Pair<String?, Float> {
        val n = 4096; val hop = 2048
        val chroma = DoubleArray(12)
        val window = DoubleArray(n) { 0.5 - 0.5 * cos(2.0 * PI * it / (n - 1)) }
        val real = DoubleArray(n); val imag = DoubleArray(n)
        var frames = 0
        val availableFrames = 1 + (x.size - n).coerceAtLeast(0) / hop
        val framesToUse = min(300, availableFrames)
        val frameStep = if (framesToUse > 1) (x.size - n) / (framesToUse - 1) else 0
        var offset = 0
        while (offset + n <= x.size && frames < framesToUse) {
            for (i in 0 until n) { real[i] = x[offset + i] * window[i]; imag[i] = 0.0 }
            fft(real, imag)
            for (k in 2 until n / 2) {
                val hz = k.toDouble() * TARGET_RATE / n
                if (hz < 55 || hz > 1600) continue
                val midi = (69 + 12 * ln(hz / 440.0) / ln(2.0)).roundToInt()
                val pc = ((midi % 12) + 12) % 12
                chroma[pc] += hypot(real[k], imag[k])
            }
            frames++
            offset = frames * frameStep
        }
        if (frames == 0 || chroma.sum() <= 0) return Pair(null, 0f)
        val major = doubleArrayOf(6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88)
        val minor = doubleArrayOf(6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17)
        val names = arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")
        var best = Double.NEGATIVE_INFINITY; var second = Double.NEGATIVE_INFINITY; var bestIndex = 0
        for (root in 0 until 12) for (mode in 0..1) {
            val profile = if (mode == 0) major else minor
            var dot = 0.0; var a = 0.0; var b = 0.0
            for (i in 0 until 12) { val v = chroma[(i + root) % 12]; dot += v * profile[i]; a += v*v; b += profile[i]*profile[i] }
            val score = dot / sqrt(a * b).coerceAtLeast(1e-12)
            if (score > best) { second = best; best = score; bestIndex = root + mode * 12 } else if (score > second) second = score
        }
        val root = bestIndex % 12; val minorMode = bestIndex >= 12
        // Camelot wheel mapping: C major=8B, A minor=8A.
        val camelotNumber = if (minorMode) when (root) { 0 -> 5; 1 -> 12; 2 -> 7; 3 -> 2; 4 -> 9; 5 -> 4; 6 -> 11; 7 -> 6; 8 -> 1; 9 -> 8; 10 -> 3; else -> 10 } else when (root) { 0 -> 8; 1 -> 3; 2 -> 10; 3 -> 5; 4 -> 12; 5 -> 7; 6 -> 2; 7 -> 9; 8 -> 4; 9 -> 11; 10 -> 6; else -> 1 }
        val key = "$camelotNumber${if (minorMode) "A" else "B"}"
        val confidence = (best - second).coerceIn(0.0, 1.0).toFloat()
        return Pair(key, confidence)
    }

    private fun fft(real: DoubleArray, imag: DoubleArray) {
        val n = real.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val tr = real[i]; real[i] = real[j]; real[j] = tr; val ti = imag[i]; imag[i] = imag[j]; imag[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val angle = -2.0 * PI / len
            val wLenR = cos(angle); val wLenI = sin(angle)
            var i = 0
            while (i < n) {
                var wr = 1.0; var wi = 0.0
                for (k in 0 until len / 2) {
                    val uR = real[i+k]; val uI = imag[i+k]
                    val vR = real[i+k+len/2] * wr - imag[i+k+len/2] * wi
                    val vI = real[i+k+len/2] * wi + imag[i+k+len/2] * wr
                    real[i+k] = uR + vR; imag[i+k] = uI + vI
                    real[i+k+len/2] = uR - vR; imag[i+k+len/2] = uI - vI
                    val nextWr = wr * wLenR - wi * wLenI
                    wi = wr * wLenI + wi * wLenR; wr = nextWr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
