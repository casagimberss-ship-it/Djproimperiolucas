@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package com.imperio.djpromix

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Real-time PCM processor used by each deck. Controls are atomic so the UI/transition
 * thread never blocks the decoder/audio thread. The processor keeps the stream format
 * unchanged and applies effects directly to decoded PCM before AudioTrack output.
 */
class DjAudioFxProcessor : BaseAudioProcessor() {
    data class State(
        val filterWet: Float = 0f,
        val filterCutoffHz: Float = 20_000f,
        val filterHighPass: Boolean = false,
        val delayWet: Float = 0f,
        val delayMs: Float = 280f,
        val delayFeedback: Float = 0.25f,
        val reverbWet: Float = 0f,
        val echoWet: Float = 0f,
        val echoFeedback: Float = 0.28f,
        val flangerWet: Float = 0f,
        val bassGain: Float = 1f,
        val masterGain: Float = 1f,
        val reverseFrames: Int = 0
    )

    private val state = AtomicReference(State())
    private var sampleRate = 48_000
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT
    private var delayBuffer = FloatArray(0)
    private var reverbBuffer = FloatArray(0)
    private var flangerBuffer = FloatArray(0)
    private var reverseBuffer = FloatArray(0)
    private var delayIndex = 0
    private var reverbIndex = 0
    private var flangerIndex = 0
    private var reverseWrite = 0
    private var reverseFramesLeft = 0
    private var filterLp = FloatArray(2)
    private var filterHp = FloatArray(2)
    private var phase = 0.0

    fun setState(newState: State) {
        state.set(newState.copy(
            filterWet = newState.filterWet.coerceIn(0f, 1f),
            filterCutoffHz = newState.filterCutoffHz.coerceIn(20f, 20_000f),
            delayWet = newState.delayWet.coerceIn(0f, .85f),
            delayMs = newState.delayMs.coerceIn(20f, 1_200f),
            delayFeedback = newState.delayFeedback.coerceIn(0f, .82f),
            reverbWet = newState.reverbWet.coerceIn(0f, .65f),
            echoWet = newState.echoWet.coerceIn(0f, .75f),
            echoFeedback = newState.echoFeedback.coerceIn(0f, .82f),
            flangerWet = newState.flangerWet.coerceIn(0f, .7f),
            bassGain = newState.bassGain.coerceIn(0f, 1.35f),
            masterGain = newState.masterGain.coerceIn(0f, 1.15f),
            reverseFrames = newState.reverseFrames.coerceAtLeast(0)
        ))
    }

    fun snapshot(): State = state.get()

    fun resetFx() = setState(State())

    fun triggerBackspin(durationMs: Long = 450L) {
        reverseFramesLeft = ((durationMs.coerceIn(80L, 1_500L) * sampleRate) / 1000L).toInt()
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT && inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount.coerceIn(1, 2)
        encoding = inputAudioFormat.encoding
        return inputAudioFormat
    }

    @Suppress("DEPRECATION")
    override fun onFlush() {
        val maxDelayFrames = (sampleRate * 1.25f).toInt().coerceAtLeast(256)
        delayBuffer = FloatArray(maxDelayFrames * channels)
        reverbBuffer = FloatArray(sampleRate / 8 * channels)
        flangerBuffer = FloatArray(sampleRate / 50 * channels)
        reverseBuffer = FloatArray(sampleRate / 2 * channels)
        delayIndex = 0; reverbIndex = 0; flangerIndex = 0; reverseWrite = 0
        reverseFramesLeft = 0
        filterLp = FloatArray(channels)
        filterHp = FloatArray(channels)
        phase = 0.0
    }

    override fun onReset() {
        delayBuffer = FloatArray(0)
        reverbBuffer = FloatArray(0)
        flangerBuffer = FloatArray(0)
        reverseBuffer = FloatArray(0)
        resetFx()
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val bytes = inputBuffer.remaining()
        if (bytes == 0) return
        val frameBytes = if (encoding == C.ENCODING_PCM_FLOAT) 4 * channels else 2 * channels
        val frames = bytes / frameBytes
        val output = replaceOutputBuffer(bytes)
        val src = inputBuffer.duplicate().order(ByteOrder.nativeOrder())
        val s = state.get()

        repeat(frames) { frame ->
            val values = FloatArray(2)
            for (ch in 0 until channels) values[ch] = readSample(src)

            val processed = processFrame(values, s)
            for (ch in 0 until channels) writeSample(output, processed[ch])

            // Preserve a short real PCM history used by Backspin.
            for (ch in 0 until channels) {
                if (reverseBuffer.isNotEmpty()) reverseBuffer[reverseWrite * channels + ch] = values[ch]
            }
            reverseWrite = if (reverseBuffer.isEmpty()) 0 else (reverseWrite + 1) % (reverseBuffer.size / channels)
        }
        inputBuffer.position(inputBuffer.position() + frames * frameBytes)
        output.flip()
    }

    private fun processFrame(input: FloatArray, s: State): FloatArray {
        val out = input.copyOf()
        val delayFrames = (s.delayMs * sampleRate / 1000f).toInt().coerceIn(1, delayBuffer.size / channels.coerceAtLeast(1) - 1)
        val echoFrames = (s.delayMs * 1.5f * sampleRate / 1000f).toInt().coerceIn(1, delayBuffer.size / channels.coerceAtLeast(1) - 1)
        val delayBase = ((delayIndex - delayFrames + delayBuffer.size / channels) % (delayBuffer.size / channels)) * channels
        val echoBase = ((delayIndex - echoFrames + delayBuffer.size / channels) % (delayBuffer.size / channels)) * channels
        val currentBase = delayIndex * channels

        for (ch in 0 until channels) {
            var x = input[ch]
            var y = x

            // Bass swap: controlled low shelf using a one-pole low-pass detector.
            val lp = filterLp[ch] + 0.08f * (x - filterLp[ch])
            filterLp[ch] = lp
            y += lp * (s.bassGain - 1f)

            // Resonance-free one-pole filter with wet/dry mix.
            if (s.filterWet > 0.001f) {
                val cutoff = s.filterCutoffHz.coerceIn(20f, (sampleRate * .45f).toFloat())
                val a = (2f * PI.toFloat() * cutoff / sampleRate).coerceIn(.001f, .98f)
                val low = filterLp[ch] + a * (x - filterLp[ch])
                filterLp[ch] = low
                val high = x - low
                val filtered = if (s.filterHighPass) high else low
                y = y * (1f - s.filterWet) + filtered * s.filterWet
            }

            // Short delay / echo feedback.
            val delayed = delayBuffer.getOrElse(delayBase + ch) { 0f }
            val echoed = delayBuffer.getOrElse(echoBase + ch) { 0f }
            y += delayed * s.delayWet
            y += echoed * s.echoWet
            val write = x + delayed * s.delayFeedback + echoed * s.echoFeedback
            if (delayBuffer.isNotEmpty()) delayBuffer[currentBase + ch] = write.coerceIn(-1f, 1f)

            // Small Schroeder-like reverb from a circular diffusion buffer.
            if (s.reverbWet > .001f && reverbBuffer.isNotEmpty()) {
                val rb = (reverbIndex * channels + ch) % reverbBuffer.size
                val rv = reverbBuffer[rb]
                y = y * (1f - s.reverbWet) + (y * .72f + rv * .28f) * s.reverbWet
                reverbBuffer[rb] = (x + rv * .72f) * .75f
            }

            // Chorus/flanger: modulated short delay, real PCM feedback path.
            if (s.flangerWet > .001f && flangerBuffer.isNotEmpty()) {
                val maxFrames = flangerBuffer.size / channels
                val mod = (0.5 + 0.5 * sin(phase)).toFloat()
                val fd = (2f + mod * (maxFrames - 3)).toInt().coerceAtLeast(1)
                val idx = ((flangerIndex - fd + maxFrames) % maxFrames) * channels + ch
                val fv = flangerBuffer[idx]
                y = y * (1f - s.flangerWet) + (y + fv) * .5f * s.flangerWet
                flangerBuffer[flangerIndex * channels + ch] = y
            }
            out[ch] = (y * s.masterGain).coerceIn(-.98f, .98f)
        }
        if (flangerBuffer.isNotEmpty()) flangerIndex = (flangerIndex + 1) % (flangerBuffer.size / channels)
        if (reverbBuffer.isNotEmpty()) reverbIndex = (reverbIndex + 1) % (reverbBuffer.size / channels)
        phase += 2.0 * PI * 0.18 / sampleRate
        if (phase > 2 * PI) phase -= 2 * PI

        // Real PCM reverse window. We replace the newest frames with the captured history,
        // rather than changing a button state only; after the requested window it returns to normal.
        if (reverseFramesLeft > 0 && reverseBuffer.isNotEmpty()) {
            val historyFrames = reverseBuffer.size / channels
            val start = (reverseWrite - 1 + historyFrames) % historyFrames
            val offset = ((historyFrames - 1) - (reverseFramesLeft % historyFrames) + historyFrames) % historyFrames
            for (ch in 0 until channels) {
                val idx = ((start - offset + historyFrames) % historyFrames) * channels + ch
                out[ch] = (reverseBuffer[idx] * .92f).coerceIn(-.98f, .98f)
            }
            reverseFramesLeft--
        }
        return out
    }

    private fun readSample(buffer: ByteBuffer): Float = if (encoding == C.ENCODING_PCM_FLOAT) {
        buffer.float
    } else {
        buffer.short / 32768f
    }

    private fun writeSample(buffer: ByteBuffer, value: Float) {
        val v = value.coerceIn(-1f, 1f)
        if (encoding == C.ENCODING_PCM_FLOAT) buffer.putFloat(v) else buffer.putShort((v * 32767f).toInt().toShort())
    }
}
