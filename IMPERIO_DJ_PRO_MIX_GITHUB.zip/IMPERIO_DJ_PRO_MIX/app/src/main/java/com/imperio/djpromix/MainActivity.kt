package com.imperio.djpromix

import android.content.Intent
import android.graphics.Color
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var deckA: Deck
    private lateinit var deckB: Deck
    private lateinit var masterLabel: TextView
    private lateinit var crossfader: SeekBar
    private lateinit var master: SeekBar
    private lateinit var status: TextView
    private var partyMode = false

    private val pickA = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { loadTrack(deckA, it) }
    }
    private val pickB = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { loadTrack(deckB, it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 10, 15)
        window.navigationBarColor = Color.rgb(8, 10, 15)
        deckA = Deck("A")
        deckB = Deck("B")
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(9, 11, 16))
            setPadding(dp(12))
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        header.addView(label("IMPERIO", 22, GOLD, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("DJ PRO MIX  •  v1.0", 12, MUTED, true))
        root.addView(header)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8)) }
        tabs.addView(action("DECKS") { partyMode = false; render() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        tabs.addView(action("MODO FIESTA") { partyMode = true; render() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        root.addView(tabs)

        if (partyMode) {
            renderParty(root)
        } else {
            val compact = resources.configuration.smallestScreenWidthDp < 600
            val decks = LinearLayout(this).apply {
                orientation = if (compact) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
                weightSum = 2f
            }
            if (compact) {
                decks.addView(deckPanel(deckA, { pickA.launch(arrayOf("audio/*")) }, 0),
                    LinearLayout.LayoutParams(-1, 0, 1f))
                decks.addView(deckPanel(deckB, { pickB.launch(arrayOf("audio/*")) }, 1),
                    LinearLayout.LayoutParams(-1, 0, 1f))
            } else {
                decks.addView(deckPanel(deckA, { pickA.launch(arrayOf("audio/*")) }, 0),
                    LinearLayout.LayoutParams(0, -1, 1f))
                decks.addView(deckPanel(deckB, { pickB.launch(arrayOf("audio/*")) }, 1),
                    LinearLayout.LayoutParams(0, -1, 1f))
            }
            root.addView(decks, LinearLayout.LayoutParams(-1, 0, 1f))
            root.addView(label("MEZCLADOR CENTRAL", 12, GOLD, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
            root.addView(label("CROSSFADER   A  ◀────────●────────▶  B", 11, MUTED, true))
            crossfader = SeekBar(this).apply {
                max = 100; progress = 50
                setOnSeekBarChangeListener(change { applyMix() })
            }
            root.addView(crossfader)
            val masterRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            masterRow.addView(label("MASTER", 12, GOLD, true), LinearLayout.LayoutParams(dp(72), -2))
            master = SeekBar(this).apply {
                max = 100; progress = 85
                setOnSeekBarChangeListener(change { applyMix() })
            }
            masterRow.addView(master, LinearLayout.LayoutParams(0, dp(38), 1f))
            masterLabel = label("85%", 12, WHITE, true)
            masterRow.addView(masterLabel)
            root.addView(masterRow)
            status = label("Listo · Carga una pista en cada deck", 11, MUTED)
            root.addView(status)
        }
        setContentView(root)
        if (!partyMode) applyMix()
    }

    private fun deckPanel(deck: Deck, load: () -> Unit, index: Int): View {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8))
            setBackgroundColor(if (index == 0) Color.rgb(20, 30, 42) else Color.rgb(35, 27, 24))
        }
        panel.addView(label("DECK ${deck.name}", 18, if (index == 0) CYAN else GOLD, true))
        panel.addView(action("＋ CARGAR CANCIÓN") { load() })
        val track = label(deck.title, 12, WHITE, true)
        deck.trackLabel = track
        panel.addView(track)
        val time = label("00:00 / 00:00", 11, MUTED)
        deck.timeLabel = time
        panel.addView(time)
        val seek = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    if (user && deck.player != null && deck.duration > 0) deck.player!!.seekTo(deck.duration * p / 1000)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        deck.seekBar = seek
        panel.addView(seek)
        val transport = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        transport.addView(action("▶ / ❚❚") { toggle(deck) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        transport.addView(action("■ STOP") { deck.player?.pause(); deck.player?.seekTo(0); updateDeck(deck) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        transport.addView(action("CUE") { setCue(deck) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        panel.addView(transport)
        panel.addView(label("PITCH  ±8%", 10, MUTED, true))
        val pitch = SeekBar(this).apply {
            max = 160; progress = 80
            setOnSeekBarChangeListener(change {
                val speed = 0.92f + progress / 1000f
                deck.player?.setPlaybackSpeed(speed)
            })
        }
        panel.addView(pitch)
        panel.addView(label("VOLUMEN", 10, MUTED, true))
        val volume = SeekBar(this).apply {
            max = 100; progress = 100
            setOnSeekBarChangeListener(change { deck.volume = progress / 100f; applyMix() })
        }
        deck.volumeBar = volume
        panel.addView(volume)
        val eqTitle = label("EQ  ·  LOW / MID / HIGH", 10, MUTED, true)
        panel.addView(eqTitle)
        val eq = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("LOW", "MID", "HIGH").forEach { band ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            col.addView(label(band, 9, MUTED, true))
            val bar = SeekBar(this).apply { max = 100; progress = 50 }
            col.addView(bar, LinearLayout.LayoutParams(-1, dp(36)))
            eq.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        panel.addView(eq)
        val padsTitle = label("HOT CUES", 10, MUTED, true)
        panel.addView(padsTitle)
        val pads = GridLayout(this).apply { columnCount = 4 }
        repeat(8) { i ->
            pads.addView(action("CUE ${i + 1}") { setHotCue(deck, i) }, GridLayout.LayoutParams().apply {
                width = 0; height = dp(38); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(2), dp(2), dp(2))
            })
        }
        panel.addView(pads)
        panel.addView(action("LOOP 4 BEATS  •  activar/desactivar") { toggleLoop(deck) })
        return panel
    }

    private fun renderParty(root: LinearLayout) {
        root.addView(label("MODO FIESTA", 24, GOLD, true))
        root.addView(label("Reproductor de ambiente y efectos", 13, MUTED))
        root.addView(action("CARGAR PISTA PARA FIESTA") { pickA.launch(arrayOf("audio/*")) })
        root.addView(label(deckA.title, 15, WHITE, true))
        root.addView(action("▶ / ❚❚  REPRODUCIR") { toggle(deckA) })
        root.addView(action("SIGUIENTE DECK / CARGAR OTRA PISTA") { pickB.launch(arrayOf("audio/*")) })
        root.addView(action("▶ / ❚❚  DECK B") { toggle(deckB) })
        root.addView(label("EFECTOS DE FIESTA", 13, GOLD, true))
        val effects = GridLayout(this).apply { columnCount = 2 }
        listOf("BOCINA", "SIRENA", "LÁSER", "PLATILLO").forEach {
            effects.addView(action(it) { Toast.makeText(this@MainActivity, "Sampler: agrega un archivo de efecto en la próxima etapa", Toast.LENGTH_SHORT).show() },
                GridLayout.LayoutParams().apply { width = 0; height = dp(54); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) })
        }
        root.addView(effects)
        root.addView(action("VOLVER A DECKS") { partyMode = false; render() })
    }

    private fun loadTrack(deck: Deck, uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        try {
            if (deck.player == null) deck.player = ExoPlayer.Builder(this).build()
            deck.player!!.setMediaItem(MediaItem.fromUri(uri))
            deck.player!!.prepare()
            deck.player!!.playWhenReady = false
            deck.title = queryName(uri) ?: "Pista cargada"
            deck.trackLabel?.text = deck.title
            deck.player!!.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { updateDeck(deck) }
                override fun onIsPlayingChanged(isPlaying: Boolean) { updateDeck(deck) }
            })
            status.text = "Deck ${deck.name}: pista cargada"
            updateDeck(deck)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo cargar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    private fun toggle(deck: Deck) {
        val p = deck.player ?: run { Toast.makeText(this, "Carga una canción primero", Toast.LENGTH_SHORT).show(); return }
        if (p.isPlaying) p.pause() else p.play()
        updateDeck(deck)
    }

    private fun setCue(deck: Deck) {
        deck.cuePosition = deck.player?.currentPosition ?: 0L
        Toast.makeText(this, "CUE ${deck.name} guardado", Toast.LENGTH_SHORT).show()
    }

    private fun setHotCue(deck: Deck, index: Int) {
        val p = deck.player ?: return
        if (deck.hotCues[index] == null) {
            deck.hotCues[index] = p.currentPosition
            Toast.makeText(this, "Hot Cue ${index + 1} guardado", Toast.LENGTH_SHORT).show()
        } else {
            p.seekTo(deck.hotCues[index]!!)
            if (!p.isPlaying) p.play()
        }
    }

    private fun toggleLoop(deck: Deck) {
        val p = deck.player ?: return
        val start = p.currentPosition
        val end = start + 2000L
        p.createMessage { _, _ -> if (p.isPlaying) p.seekTo(start) }
            .setPosition(end).setDeleteAfterDelivery(false).setLooper(android.os.Looper.getMainLooper()).send()
        Toast.makeText(this, "Loop de prueba de 2 segundos activado", Toast.LENGTH_SHORT).show()
    }

    private fun updateDeck(deck: Deck) {
        val p = deck.player ?: return
        deck.duration = p.duration.coerceAtLeast(0)
        deck.timeLabel?.text = "${fmt(p.currentPosition)} / ${fmt(deck.duration)}"
        if (deck.duration > 0) deck.seekBar?.progress = (p.currentPosition * 1000 / deck.duration).toInt()
    }

    private fun applyMix() {
        if (!::crossfader.isInitialized || !::master.isInitialized) return
        val x = crossfader.progress / 100f
        val m = master.progress / 100f
        deckA.player?.volume = deckA.volume * (1f - x) * m
        deckB.player?.volume = deckB.volume * x * m
        masterLabel.text = "${master.progress}%"
    }

    private fun fmt(ms: Long): String = String.format(Locale.US, "%02d:%02d", ms / 60000, (ms / 1000) % 60)
    private fun change(block: (SeekBar) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { block(s) }
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(4), dp(5), dp(4), dp(5))
    }
    private fun action(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 10f; isAllCaps = false
        setTextColor(WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(48, 55, 66)))
        setOnClickListener { click() }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        deckA.player?.release(); deckB.player?.release()
        super.onDestroy()
    }

    data class Deck(val name: String) {
        var player: ExoPlayer? = null
        var title = "Sin pista cargada"
        var volume = 1f
        var duration = 0L
        var cuePosition = 0L
        val hotCues = arrayOfNulls<Long>(8)
        var trackLabel: TextView? = null
        var timeLabel: TextView? = null
        var seekBar: SeekBar? = null
        var volumeBar: SeekBar? = null
    }

    companion object {
        const val GOLD = Color.YELLOW
        const val CYAN = Color.CYAN
        const val WHITE = Color.WHITE
        const val MUTED = 0xFF9BA4B2.toInt()
    }
}
