package com.imperio.djpromix

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.core.view.setPadding
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val tracks = mutableListOf<Track>()
    private lateinit var root: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var nowMeta: TextView
    private lateinit var status: TextView
    private lateinit var progress: SeekBar
    private lateinit var playButton: Button
    private lateinit var queueBox: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var analysisRunning = false
    private var players = arrayOfNulls<ExoPlayer>(2)
    private var playbackService: PartyPlaybackService? = null
    private var serviceBound = false
    private val playbackConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val service = (binder as? PartyPlaybackService.LocalBinder)?.getService() ?: return
            playbackService = service
            players = service.players
            attachPlayerListeners()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            playbackService = null
            players = arrayOfNulls(2)
        }
    }
    private var active = 0
    private var currentIndex = -1
    private var nextIndex = -1
    private var userSelectedNext = false
    private var partyOn = false
    private var crossfading = false
    private var masterVolume = 0.85f
    private var shuffle = true
    private var fadeSeconds = 8
    private var aiStyle = AiDjEngine.Style.PROGRESSIVE
    private val recentHistory = ArrayDeque<Int>()
    private var lastAiReason = "La IA elegirá según BPM, tonalidad y energía"
    private var libraryFolderUri: Uri? = null
    private var recordingActive = false
    private var projectionResultCode = 0
    private var projectionResultData: Intent? = null
    private val recordingFinishedReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            recordingActive = false
            val success = intent?.getBooleanExtra(SessionRecordingService.EXTRA_SUCCESS, false) == true
            val error = intent?.getStringExtra(SessionRecordingService.EXTRA_ERROR).orEmpty()
            if (::status.isInitialized) status.text = if (success) "Sesión grabada y guardada correctamente" else "Error al grabar: $error"
            renderRecordingControls()
        }
    }
    private val audioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) requestProjectionPermission() else Toast.makeText(this, "Se necesita el permiso de audio para grabar la salida de IMPERIO", Toast.LENGTH_LONG).show()
    }
    private val projectionPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            projectionResultCode = result.resultCode
            projectionResultData = result.data
            createRecordingFile.launch("IMPERIO_SESION_${System.currentTimeMillis()}.wav")
        } else Toast.makeText(this, "Permiso de captura cancelado", Toast.LENGTH_SHORT).show()
    }
    private val createRecordingFile = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        val data = projectionResultData
        if (uri != null && data != null) {
            val serviceIntent = Intent(this, SessionRecordingService::class.java).apply {
                action = SessionRecordingService.ACTION_START
                putExtra(SessionRecordingService.EXTRA_RESULT_CODE, projectionResultCode)
                putExtra(SessionRecordingService.EXTRA_DATA, data)
                setData(uri)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            recordingActive = true
            status.text = "Iniciando grabación de sesión…"
            renderRecordingControls()
        } else { status.text = "Grabación cancelada"; renderRecordingControls() }
        projectionResultData = null
    }
    private val tick = object : Runnable {
        override fun run() {
            val p = players[active]
            if (p != null && p.duration > 0) {
                progress.max = p.duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                progress.progress = p.currentPosition.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                if (partyOn && !crossfading && nextIndex >= 0 && shouldStartSmartTransition(p)) beginCrossfade()
            }
            handler.postDelayed(this, 400)
        }
    }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let { importFolder(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        restoreLibrary()
        recordingActive = getSharedPreferences("imperio_party", MODE_PRIVATE).getBoolean("recordingActive", false)
        androidx.core.content.ContextCompat.registerReceiver(this, recordingFinishedReceiver, android.content.IntentFilter(SessionRecordingService.ACTION_FINISHED), androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED)
        bindService(Intent(this, PartyPlaybackService::class.java), playbackConnection, BIND_AUTO_CREATE)
        serviceBound = true
        render()
        handler.post(tick)
    }

    private fun attachPlayerListeners() {
        players.forEachIndexed { i, p -> p?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && i == active && partyOn && !crossfading) startNextImmediately()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { updatePlayButton() }
        }) }
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(22)) }
        scroll.addView(root)
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("IMPERIO", 26, GOLD, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("PARTY ENGINE", 11, CYAN, true))
        root.addView(header)
        root.addView(label("AUTO SELECT  ·  SMART TRANSITIONS  ·  ASSISTED QUEUE", 10, MUTED, true))
        root.addView(space(12))
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(18)); background = rounded(PANEL, 20) }
        hero.addView(label("AHORA SONANDO", 11, CYAN, true))
        nowTitle = label("Cargá tu música para comenzar", 21, WHITE, true).apply { gravity = Gravity.CENTER; maxLines = 2 }
        hero.addView(nowTitle)
        nowMeta = label("BPM --  ·  TONALIDAD --  ·  --:--", 12, MUTED).apply { gravity = Gravity.CENTER }
        hero.addView(nowMeta)
        progress = SeekBar(this).apply { max = 1000; progress = 0; isEnabled = false }
        hero.addView(progress)
        root.addView(hero)
        root.addView(space(12))
        val transport = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        transport.addView(action("⏮") { previousTrack() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        playButton = action("▶ INICIAR FIESTA") { toggleParty() }
        transport.addView(playButton, LinearLayout.LayoutParams(0, dp(58), 2f))
        transport.addView(action("⏭") { skipTrack() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(transport)
        root.addView(space(8))
        root.addView(action("＋  IMPORTAR CARPETA COMPLETA DE MÚSICA") { folderPicker.launch(null) })
        root.addView(space(5))
        root.addView(action("ANALIZAR BPM + TONALIDAD AUTOMÁTICAMENTE") { analyzeLibrary() })
        root.addView(label("GRABACIÓN DE SESIÓN", 13, GOLD, true))
        root.addView(action(if (recordingActive) "■  DETENER Y GUARDAR SESIÓN" else "●  GRABAR SESIÓN EN WAV") { toggleSessionRecording() }.apply { setTextColor(if (recordingActive) Color.rgb(255, 120, 100) else Color.WHITE) })
        root.addView(label("La grabación captura el audio multimedia que reproduce IMPERIO. Android solicitará permiso de captura y podrás elegir dónde guardar el WAV.", 10, MUTED))
        root.addView(space(6))
        val options = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        options.addView(action(if (shuffle) "ALEATORIO INTELIGENTE: SÍ" else "ALEATORIO INTELIGENTE: NO") { shuffle = !shuffle; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        options.addView(action("CRUCE: ${fadeSeconds}s") { fadeSeconds = if (fadeSeconds == 8) 12 else if (fadeSeconds == 12) 0 else 8; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(options)
        root.addView(label("VOLUMEN GENERAL", 11, MUTED, true))
        root.addView(SeekBar(this).apply { max = 100; progress = 85; setOnSeekBarChangeListener(listener { masterVolume = it / 100f; players.forEach { p -> p?.volume = masterVolume } }) })
        status = label("Listo · importá una carpeta para crear tu biblioteca", 11, CYAN)
        root.addView(status)
        root.addView(space(8))
        root.addView(label("PRÓXIMA EN LA COLA", 14, GOLD, true))
        val upcoming = tracks.getOrNull(nextIndex)
        root.addView(label(upcoming?.let { "${it.title}  ·  ${it.bpm?.let { b -> "$b BPM" } ?: "BPM pendiente"}  ·  ${if (userSelectedNext) "ELEGIDA POR VOS" else "SELECCIÓN AUTOMÁTICA"}" } ?: "La cola se completará al iniciar la fiesta", 12, CYAN))
        root.addView(label("IMPERIO AI DJ ENGINE  ·  MODO HÍBRIDO", 14, GOLD, true))
        root.addView(action("ESTILO IA: ${aiStyle.label}  ↻ CAMBIAR") {
            aiStyle = AiDjEngine.Style.values()[(aiStyle.ordinal + 1) % AiDjEngine.Style.values().size]
            if (currentIndex in tracks.indices) { nextIndex = chooseNext(currentIndex); userSelectedNext = false }
            render()
        })
        root.addView(label("RECOMENDACIÓN IA", 11, CYAN, true))
        root.addView(label(lastAiReason, 10, MUTED))
        root.addView(label("ANÁLISIS AVANZADO · INTRO · ENTRADA · CURVA DE ENERGÍA · PULSO", 11, GOLD, true))
        root.addView(label("Los marcadores son estimaciones del fragmento inicial analizado. No detectan con certeza downbeats, frases, voces ni outro; la entrada sugerida puede saltar el comienzo de una pista.", 10, MUTED))
        root.addView(label("MOTOR DE MEZCLA  ·  BPM SYNC + FRASE MUSICAL", 11, GOLD, true))
        root.addView(label("La sincronización de tempo se aplica cuando las pistas tienen BPM confiable y la diferencia es pequeña.", 10, MUTED))
        root.addView(label("BIBLIOTECA MUSICAL  ·  ${tracks.size} PISTAS", 14, GOLD, true))
        root.addView(label("▶ reproduce · SIG. fija la próxima canción · ♫ edita datos musicales", 11, MUTED))
        queueBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(queueBox)
        renderQueue()
        setContentView(scroll)
        updatePlayButton()
    }

    private fun renderQueue() {
        queueBox.removeAllViews()
        if (tracks.isEmpty()) { queueBox.addView(label("Todavía no hay canciones importadas.", 12, MUTED)); return }
        tracks.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(5)); setBackgroundColor(if (i % 2 == 0) PANEL else BG) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label("${i + 1}. ${t.title}", 12, if (i == currentIndex) GOLD else WHITE, true))
            info.addView(label("${t.bpm?.let { "$it BPM" } ?: "BPM --"}  ·  ${t.key ?: "Tonalidad --"}  ·  ${t.energy?.let { "ENERGÍA $it/5" } ?: "ENERGÍA --"}", 10, MUTED))
            info.addView(label("${t.introSeconds?.let { "INTRO aprox. ${it}s" } ?: "INTRO --"}  ·  ${t.entrySeconds?.let { "ENTRADA sugerida ${it}s" } ?: "ENTRADA --"}  ·  ${t.beatConfidence?.let { "RITMO ${(it * 100).roundToInt()}%" } ?: "RITMO --"}", 9, CYAN))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(action("▶") { playTrack(i) })
            row.addView(action(if (i == nextIndex) "✓" else "SIG.") { setNextTrack(i) })
            row.addView(action("♫") { editAnalysis(t) })
            queueBox.addView(row)
        }
    }

    private fun importFolder(uri: android.net.Uri) {
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val folder = DocumentFile.fromTreeUri(this, uri) ?: return
        libraryFolderUri = uri
        val found = mutableListOf<Track>()
        fun scan(dir: DocumentFile) { dir.listFiles().forEach { f ->
            if (f.isDirectory) scan(f)
            else if (f.isFile && (f.type?.startsWith("audio/") == true || f.name.orEmpty().matches(Regex("(?i).+\\.(mp3|wav|flac|m4a|aac|ogg|opus|wma)$")))) {
                if (found.none { it.uri == f.uri }) found.add(Track(f.uri, f.name ?: "Audio"))
            }
        } }
        scan(folder)
        val sorted = found.sortedBy { it.title.lowercase(Locale.getDefault()) }
        loadFolderCache(folder, sorted)
        tracks.clear(); tracks.addAll(sorted)
        currentIndex = -1; nextIndex = -1; userSelectedNext = false
        persistLibrary()
        status.text = "Importadas ${tracks.size} canciones · ${tracks.count { it.cacheValid }} análisis reutilizados"
        render()
    }

    private fun analyzeLibrary() {
        if (analysisRunning) { Toast.makeText(this, "El análisis ya está en curso", Toast.LENGTH_SHORT).show(); return }
        if (tracks.isEmpty()) { Toast.makeText(this, "Primero importá una carpeta", Toast.LENGTH_SHORT).show(); return }
        tracks.forEach { track ->
            if (track.cacheValid && track.fileSize >= 0L && track.fileModified >= 0L) {
                val file = DocumentFile.fromSingleUri(this, track.uri)
                if (file == null || !file.exists() || file.length() != track.fileSize || file.lastModified() != track.fileModified) {
                    track.cacheValid = false
                    track.bpm = null; track.key = null
                    track.introSeconds = null; track.entrySeconds = null
                    track.energyCurve = null; track.beatConfidence = null
                }
            }
        }
        val pending = tracks.filter { !it.cacheValid }
        if (pending.isEmpty()) { status.text = "Biblioteca analizada · podés corregir datos manualmente"; return }
        analysisRunning = true
        status.text = "Analizando audio real: 0/${pending.size} · no cierres la aplicación"
        analysisExecutor.execute {
            var completed = 0
            for (track in pending) {
                try {
                    val result = AudioAnalyzer.analyze(this, track.uri)
                    if (track.bpm == null) track.bpm = result.bpm
                    if (track.key == null) track.key = result.camelot
                    track.introSeconds = result.introSeconds
                    track.entrySeconds = result.entrySeconds
                    track.energyCurve = result.energyCurve
                    track.beatConfidence = result.beatConfidence
                    track.cacheValid = true
                } catch (_: Exception) { /* archivo no compatible o sin permiso: continuar */ }
                completed++
                val count = completed
                handler.post {
                    if (!isFinishing && ::status.isInitialized) status.text = "Analizando audio real: $count/${pending.size}"
                }
            }
            handler.post {
                analysisRunning = false
                persistFolderCache()
                persistLibrary()
                if (!isFinishing) {
                    status.text = "Análisis finalizado · $completed pistas procesadas · datos guardados"
                    updateNowPlayingIfReady()
                    renderQueue()
                    if (currentIndex >= 0) { nextIndex = chooseNext(currentIndex); updateNowPlayingIfReady() }
                }
            }
        }
    }

    private fun updateNowPlayingIfReady() {
        if (currentIndex in tracks.indices) updateNowPlaying()
    }

    private fun editAnalysis(track: Track) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16)) }
        val bpm = EditText(this).apply { hint = "BPM (ej. 124)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(track.bpm?.toString() ?: "") }
        val key = EditText(this).apply { hint = "Camelot (ej. 8A o 9B)"; setText(track.key ?: "") }
        val energy = EditText(this).apply { hint = "Energía 1 a 5 (opcional)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(track.energy?.toString() ?: "") }
        box.addView(bpm); box.addView(key); box.addView(energy)
        android.app.AlertDialog.Builder(this).setTitle(track.title).setMessage("Corregí BPM y tonalidad Camelot para mejorar la selección y sincronización de mezclas.").setView(box)
            .setPositiveButton("GUARDAR") { _, _ -> track.bpm = bpm.text.toString().toIntOrNull()?.takeIf { it in 50..220 }; track.key = key.text.toString().trim().uppercase(Locale.US).takeIf { it.matches(Regex("(1[0-2]|[1-9])[AB]")) }; track.energy = energy.text.toString().toIntOrNull()?.takeIf { it in 1..5 }; persistFolderCache(); persistLibrary(); renderQueue(); status.text = "Datos musicales guardados" }
            .setNegativeButton("CANCELAR", null).show()
    }

    private fun toggleParty() {
        if (tracks.isEmpty()) { Toast.makeText(this, "Primero importá una carpeta de música", Toast.LENGTH_SHORT).show(); return }
        if (partyOn) { partyOn = false; players.forEach { it?.pause() }; playbackService?.setPartyActive(false); status.text = "Fiesta pausada" }
        else if (currentIndex >= 0) { partyOn = true; ContextCompat.startForegroundService(this, Intent(this, PartyPlaybackService::class.java)); playbackService?.startParty(); players[active]?.play(); playbackService?.setPartyActive(true); status.text = "Modo Fiesta activo" }
        else { partyOn = true; ContextCompat.startForegroundService(this, Intent(this, PartyPlaybackService::class.java)); playbackService?.startParty(); playTrack(selectFirst()) }
        updatePlayButton()
    }

    private fun selectFirst(): Int = if (nextIndex in tracks.indices) nextIndex else if (shuffle) tracks.indices.random() else 0
    private fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        if (players[active] == null) { Toast.makeText(this, "Preparando motor de audio… intentá nuevamente en un segundo", Toast.LENGTH_SHORT).show(); return }
        partyOn = true; ContextCompat.startForegroundService(this, Intent(this, PartyPlaybackService::class.java)); playbackService?.startParty(); playbackService?.setPartyActive(true); crossfading = false; currentIndex = index; recentHistory.addLast(index); while (recentHistory.size > 5) recentHistory.removeFirst(); nextIndex = chooseNext(index); userSelectedNext = false
        val p = players[active] ?: return
        p.stop(); p.clearMediaItems(); p.setMediaItem(MediaItem.fromUri(tracks[index].uri)); p.volume = masterVolume; p.prepare(); p.play()
        players[1 - active]?.pause(); players[1 - active]?.clearMediaItems()
        updateNowPlaying(); renderQueue(); updatePlayButton()
    }

    private fun chooseNext(from: Int): Int {
        if (tracks.size <= 1) return from
        val options = tracks.indices.filter { it != from }
        if (!shuffle) return (from + 1) % tracks.size
        val current = tracks[from]
        val currentCandidate = AiDjEngine.Candidate(from, current.bpm, current.key, current.energy, false, current.entrySeconds, current.beatConfidence)
        val candidates = options.map { index ->
            val t = tracks[index]
            AiDjEngine.Candidate(index, t.bpm, t.key, t.energy, recentHistory.contains(index), t.entrySeconds, t.beatConfidence)
        }
        val decision = AiDjEngine.choose(currentCandidate, candidates, aiStyle)
        if (decision != null) {
            lastAiReason = "${tracks[decision.index].title} · ${decision.reason} · puntuación ${decision.score}"
            return decision.index
        }
        return options.random()
    }

    private fun compatibilityScore(a: Track, b: Track): Int {
        val tempo = if (a.bpm != null && b.bpm != null) {
            val direct = abs(a.bpm!! - b.bpm!!)
            val halfDouble = minOf(abs(a.bpm!! - b.bpm!! * 2), abs(a.bpm!! * 2 - b.bpm!!))
            minOf(direct, halfDouble) * 2
        } else 25
        val key = if (a.key != null && b.key != null) camelotDistance(a.key!!, b.key!!) * 15 else 25
        val speedPenalty = if (a.bpm != null && b.bpm != null) {
            val ratio = a.bpm!!.toFloat() / b.bpm!!.toFloat()
            if (ratio in 0.94f..1.06f) 0 else 18
        } else 0
        return tempo + key + speedPenalty
    }

    private fun camelotDistance(a: String, b: String): Int {
        val x = Regex("(1[0-2]|[1-9])([AB])").matchEntire(a) ?: return 6
        val y = Regex("(1[0-2]|[1-9])([AB])").matchEntire(b) ?: return 6
        val n = x.groupValues[1].toInt(); val m = y.groupValues[1].toInt()
        return minOf(abs(n - m), 12 - abs(n - m)) + if (x.groupValues[2] == y.groupValues[2]) 0 else 1
    }

    // Alineación aproximada a una frase de 4 compases usando el BPM conocido.
    // Si no hay BPM, se utiliza el crossfade estándar como alternativa segura.
    private fun shouldStartSmartTransition(player: ExoPlayer): Boolean {
        val remaining = player.duration - player.currentPosition
        val fadeWindow = if (fadeSeconds == 0) 0L else fadeSeconds * 1000L
        if (remaining > fadeWindow) return false
        if (fadeSeconds == 0) return true
        val bpm = tracks.getOrNull(currentIndex)?.bpm ?: return true
        val fourBarsMs = (16.0 * 60000.0 / bpm.toDouble()).toLong().coerceAtLeast(1000L)
        val positionInPhrase = player.currentPosition % fourBarsMs
        val nearBoundary = positionInPhrase <= 450L || fourBarsMs - positionInPhrase <= 450L
        return nearBoundary || remaining <= 900L
    }

    private fun beginCrossfade() {
        val next = nextIndex
        if (next !in tracks.indices) { startNextImmediately(); return }
        crossfading = true
        val incomingIndex = 1 - active
        val incoming = players[incomingIndex] ?: return
        val outgoing = players[active] ?: return
        val outgoingBpm = tracks.getOrNull(currentIndex)?.bpm
        val incomingBpm = tracks.getOrNull(next)?.bpm
        val speed = if (outgoingBpm != null && incomingBpm != null) {
            (outgoingBpm.toFloat() / incomingBpm.toFloat()).coerceIn(0.94f, 1.06f)
        } else 1f
        incoming.stop(); incoming.clearMediaItems(); incoming.setMediaItem(MediaItem.fromUri(tracks[next].uri))
        incoming.setPlaybackSpeed(speed)
        // Use the analyzed opening entry marker when available; otherwise start at zero.
        tracks.getOrNull(next)?.entrySeconds?.let { incoming.seekTo(it * 1000L) }
        incoming.volume = 0f; incoming.prepare(); incoming.play()
        val duration = if (fadeSeconds == 0) 1 else fadeSeconds * 1000L
        val started = System.currentTimeMillis()
        val fade = object : Runnable {
            override fun run() {
                if (!partyOn) { incoming.pause(); crossfading = false; return }
                val fraction = ((System.currentTimeMillis() - started).toFloat() / duration).coerceIn(0f, 1f)
                outgoing.volume = masterVolume * (1f - fraction)
                incoming.volume = masterVolume * fraction
                if (fraction < 1f) handler.postDelayed(this, 80) else {
                    outgoing.pause(); outgoing.clearMediaItems(); active = incomingIndex; currentIndex = next; recentHistory.addLast(currentIndex); while (recentHistory.size > 5) recentHistory.removeFirst(); nextIndex = chooseNext(currentIndex); userSelectedNext = false; crossfading = false
                    updateNowPlaying(); renderQueue()
                    val syncText = if (outgoingBpm != null && incomingBpm != null && speed != 1f) " · tempo ${(incomingBpm * speed).roundToInt()} BPM" else if (outgoingBpm != null && incomingBpm != null) " · BPM sincronizado" else " · sin datos BPM"
                    status.text = "Transición por frase · ${tracks[currentIndex].title}$syncText"
                }
            }
        }
        handler.post(fade)
    }

    private fun setNextTrack(index: Int) {
        if (index !in tracks.indices || index == currentIndex) return
        nextIndex = index
        userSelectedNext = true
        status.text = "Próxima canción elegida: ${tracks[index].title}"
        renderQueue()
    }

    private fun loadFolderCache(folder: DocumentFile, imported: MutableList<Track>) {
        val cache = folder.findFile(CACHE_FILE) ?: return
        try {
            val raw = contentResolver.openInputStream(cache.uri)?.bufferedReader()?.use { it.readText() } ?: return
            val array = JSONArray(raw)
            val records = HashMap<String, JSONObject>()
            for (i in 0 until array.length()) { val item = array.getJSONObject(i); records[item.optString("uri")] = item }
            imported.forEach { track ->
                val file = DocumentFile.fromSingleUri(this, track.uri)
                val record = records[track.uri.toString()] ?: return@forEach
                val size = file?.length() ?: -1L
                val modified = file?.lastModified() ?: -1L
                if (record.optLong("size", -2L) == size && record.optLong("modified", -2L) == modified && size >= 0L && modified >= 0L) {
                    track.bpm = if (record.isNull("bpm")) null else record.optInt("bpm")
                    track.key = if (record.isNull("key")) null else record.optString("key")
                    track.energy = if (record.isNull("energy")) null else record.optInt("energy")
                    track.introSeconds = if (record.isNull("introSeconds")) null else record.optInt("introSeconds")
                    track.entrySeconds = if (record.isNull("entrySeconds")) null else record.optInt("entrySeconds")
                    track.energyCurve = if (record.isNull("energyCurve")) null else record.optString("energyCurve")
                    track.beatConfidence = if (record.isNull("beatConfidence")) null else record.optDouble("beatConfidence").toFloat()
                    track.fileSize = size; track.fileModified = modified; track.cacheValid = true
                }
            }
        } catch (_: Exception) { /* cache dañada: se vuelve a analizar */ }
    }

    private fun persistFolderCache() {
        val folderUri = libraryFolderUri ?: return
        try {
            val folder = DocumentFile.fromTreeUri(this, folderUri) ?: return
            val cache = folder.findFile(CACHE_FILE) ?: folder.createFile("application/json", CACHE_FILE) ?: return
            val array = JSONArray()
            tracks.forEach { t ->
                val file = DocumentFile.fromSingleUri(this, t.uri)
                val size = file?.length() ?: t.fileSize
                val modified = file?.lastModified() ?: t.fileModified
                t.fileSize = size; t.fileModified = modified
                array.put(JSONObject().apply {
                    put("uri", t.uri.toString()); put("size", size); put("modified", modified)
                    put("bpm", t.bpm ?: JSONObject.NULL); put("key", t.key ?: JSONObject.NULL); put("energy", t.energy ?: JSONObject.NULL)
                    put("introSeconds", t.introSeconds ?: JSONObject.NULL); put("entrySeconds", t.entrySeconds ?: JSONObject.NULL)
                    put("energyCurve", t.energyCurve ?: JSONObject.NULL); put("beatConfidence", t.beatConfidence ?: JSONObject.NULL)
                })
            }
            contentResolver.openOutputStream(cache.uri, "wt")?.bufferedWriter()?.use { it.write(array.toString()) }
        } catch (_: Exception) { /* se conserva también la biblioteca privada */ }
    }

    private fun toggleSessionRecording() {
        if (recordingActive) {
            startService(Intent(this, SessionRecordingService::class.java).setAction(SessionRecordingService.ACTION_STOP))
            status.text = "Finalizando archivo WAV…"
            return
        }
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) {
            Toast.makeText(this, "La grabación de audio interno requiere Android 10 o superior", Toast.LENGTH_LONG).show(); return
        }
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) requestProjectionPermission()
        else audioPermission.launch(android.Manifest.permission.RECORD_AUDIO)
    }

    private fun requestProjectionPermission() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionPermission.launch(manager.createScreenCaptureIntent())
    }

    private fun renderRecordingControls() {
        if (!isFinishing) render()
    }

    private fun persistLibrary() {
        val array = JSONArray()
        tracks.forEach { t ->
            array.put(JSONObject().apply {
                put("uri", t.uri.toString()); put("title", t.title)
                put("fileSize", t.fileSize); put("fileModified", t.fileModified); put("cacheValid", t.cacheValid)
                put("bpm", t.bpm ?: JSONObject.NULL); put("key", t.key ?: JSONObject.NULL); put("energy", t.energy ?: JSONObject.NULL)
                put("introSeconds", t.introSeconds ?: JSONObject.NULL); put("entrySeconds", t.entrySeconds ?: JSONObject.NULL)
                put("energyCurve", t.energyCurve ?: JSONObject.NULL); put("beatConfidence", t.beatConfidence ?: JSONObject.NULL)
            })
        }
        getSharedPreferences("imperio_party", MODE_PRIVATE).edit()
            .putString("library", array.toString())
            .putString("libraryFolderUri", libraryFolderUri?.toString())
            .apply()
    }

    private fun restoreLibrary() {
        val prefs = getSharedPreferences("imperio_party", MODE_PRIVATE)
        libraryFolderUri = prefs.getString("libraryFolderUri", null)?.let { Uri.parse(it) }
        val raw = prefs.getString("library", null) ?: return
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val uri = android.net.Uri.parse(item.getString("uri"))
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val bpm = if (item.isNull("bpm")) null else item.optInt("bpm").takeIf { it in 50..220 }
                val key = if (item.isNull("key")) null else item.optString("key")
                val energy = if (item.isNull("energy")) null else item.optInt("energy").takeIf { it in 1..5 }
                val track = Track(uri, item.optString("title", "Audio"), bpm, key, energy)
                track.fileSize = item.optLong("fileSize", -1L)
                track.fileModified = item.optLong("fileModified", -1L)
                track.cacheValid = item.optBoolean("cacheValid", false)
                track.introSeconds = if (item.isNull("introSeconds")) null else item.optInt("introSeconds")
                track.entrySeconds = if (item.isNull("entrySeconds")) null else item.optInt("entrySeconds")
                track.energyCurve = if (item.isNull("energyCurve")) null else item.optString("energyCurve")
                track.beatConfidence = if (item.isNull("beatConfidence")) null else item.optDouble("beatConfidence").toFloat()
                tracks.add(track)
            }
        } catch (_: Exception) { tracks.clear() }
    }

    private fun startNextImmediately() {
        if (tracks.isEmpty()) return
        val n = if (nextIndex in tracks.indices) nextIndex else chooseNext(currentIndex.coerceAtLeast(0))
        playTrack(n)
    }
    private fun skipTrack() { if (tracks.isNotEmpty()) { val n = if (nextIndex in tracks.indices) nextIndex else chooseNext(currentIndex.coerceAtLeast(0)); playTrack(n); userSelectedNext = false; nextIndex = chooseNext(n); renderQueue() } }
    private fun previousTrack() { if (tracks.isNotEmpty()) { val n = if (currentIndex > 0) currentIndex - 1 else tracks.lastIndex; playTrack(n); nextIndex = chooseNext(n); userSelectedNext = false; renderQueue() } }
    private fun updateNowPlaying() {
        val t = tracks.getOrNull(currentIndex) ?: return
        nowTitle.text = t.title
        nowMeta.text = "${t.bpm?.let { "$it BPM" } ?: "BPM --"}  ·  ${t.key ?: "KEY --"}  ·  ${durationText(players[active]?.duration ?: 0)}"
    }
    private fun updatePlayButton() { if (::playButton.isInitialized) playButton.text = if (partyOn && players[active]?.isPlaying == true) "Ⅱ  PAUSAR FIESTA" else "▶  INICIAR FIESTA" }
    private fun durationText(ms: Long) = if (ms <= 0) "--:--" else String.format(Locale.US, "%02d:%02d", ms / 60000, ms / 1000 % 60)
    private fun listener(block: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { if (user) block(p) }; override fun onStartTrackingTouch(s: SeekBar) {}; override fun onStopTrackingTouch(s: SeekBar) {} }
    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(dp(5), dp(6), dp(5), dp(6)) }
    private fun action(text: String, click: () -> Unit) = Button(this).apply { this.text = text; textSize = 10f; isAllCaps = false; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(42, 53, 68)); setOnClickListener { click() } }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.rgb(48, 60, 76)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(recordingFinishedReceiver) } catch (_: Exception) {}
        analysisExecutor.shutdownNow()
        if (serviceBound) { try { unbindService(playbackConnection) } catch (_: Exception) {}; serviceBound = false }
        // El servicio es propietario de los reproductores: no se liberan al cerrar la Activity.
        super.onDestroy()
    }
    data class Track(val uri: android.net.Uri, val title: String, var bpm: Int? = null, var key: String? = null, var energy: Int? = null) {
        var fileSize: Long = -1L
        var fileModified: Long = -1L
        var cacheValid: Boolean = false
        var introSeconds: Int? = null
        var entrySeconds: Int? = null
        var energyCurve: String? = null
        var beatConfidence: Float? = null
    }
    companion object { const val CACHE_FILE = "imperio_dj_analysis_cache.json"; const val BG = 0xFF080C13.toInt(); const val PANEL = 0xFF151E2A.toInt(); const val GOLD = 0xFFFFC34D.toInt(); const val CYAN = 0xFF38D9E8.toInt(); const val WHITE = Color.WHITE; const val MUTED = 0xFF9AA7B7.toInt() }
}
