package com.imperio.djpromix

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private val tracks = mutableListOf<Track>()
    private lateinit var root: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var nowMeta: TextView
    private lateinit var status: TextView
    private lateinit var progress: SeekBar
    private lateinit var playButton: Button
    private lateinit var queueBox: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var players = arrayOfNulls<ExoPlayer>(2)
    private var active = 0
    private var currentIndex = -1
    private var nextIndex = -1
    private var partyOn = false
    private var crossfading = false
    private var masterVolume = 0.85f
    private var shuffle = true
    private var fadeSeconds = 8
    private val tick = object : Runnable {
        override fun run() {
            val p = players[active]
            if (p != null && p.duration > 0) {
                progress.max = p.duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                progress.progress = p.currentPosition.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                if (partyOn && !crossfading && nextIndex >= 0 && p.duration - p.currentPosition <= fadeSeconds * 1000L) beginCrossfade()
            }
            handler.postDelayed(this, 400)
        }
    }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let { importFolder(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        players[0] = ExoPlayer.Builder(this).build()
        players[1] = ExoPlayer.Builder(this).build()
        players.forEachIndexed { i, p -> p?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && i == active && partyOn && !crossfading) startNextImmediately()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { updatePlayButton() }
        }) }
        render()
        handler.post(tick)
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(22)) }
        scroll.addView(root)
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("IMPERIO", 26, GOLD, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("PARTY ENGINE", 11, CYAN, true))
        root.addView(header)
        root.addView(label("REPRODUCCIÓN AUTOMÁTICA INTELIGENTE", 11, MUTED, true))
        root.addView(space(12))
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(18)); background = rounded(PANEL, 20) }
        hero.addView(label("AHORA SONANDO", 11, CYAN, true))
        nowTitle = label("Cargá tu música para comenzar", 21, WHITE, true).apply { gravity = Gravity.CENTER; maxLines = 2 }
        hero.addView(nowTitle)
        nowMeta = label("BPM --  ·  TONALIDAD --  ·  --:--", 12, MUTED).apply { gravity = Gravity.CENTER }
        hero.addView(nowMeta)
        progress = SeekBar(this).apply { max = 1000; progress = 0; isEnabled = false }
        hero.addView(progress)
        root.addView(hero)
        root.addView(space(12))
        val transport = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        transport.addView(action("⏮") { previousTrack() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        playButton = action("▶ INICIAR FIESTA") { toggleParty() }
        transport.addView(playButton, LinearLayout.LayoutParams(0, dp(58), 2f))
        transport.addView(action("⏭") { skipTrack() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(transport)
        root.addView(space(8))
        root.addView(action("＋  IMPORTAR CARPETA COMPLETA DE MÚSICA") { folderPicker.launch(null) })
        root.addView(space(6))
        val options = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        options.addView(action(if (shuffle) "ALEATORIO INTELIGENTE: SÍ" else "ALEATORIO INTELIGENTE: NO") { shuffle = !shuffle; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        options.addView(action("CRUCE: ${fadeSeconds}s") { fadeSeconds = if (fadeSeconds == 8) 12 else if (fadeSeconds == 12) 0 else 8; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(options)
        root.addView(label("VOLUMEN GENERAL", 11, MUTED, true))
        root.addView(SeekBar(this).apply { max = 100; progress = 85; setOnSeekBarChangeListener(listener { masterVolume = it / 100f; players.forEach { p -> p?.volume = masterVolume } }) })
        status = label("Listo · importá una carpeta para crear tu biblioteca", 11, CYAN)
        root.addView(status)
        root.addView(space(8))
        root.addView(label("BIBLIOTECA MUSICAL  ·  ${tracks.size} PISTAS", 14, GOLD, true))
        root.addView(label("Tocá una canción para reproducirla. Usá ♫ para cargar BPM y tonalidad si los conocés.", 11, MUTED))
        queueBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(queueBox)
        renderQueue()
        setContentView(scroll)
        updatePlayButton()
    }

    private fun renderQueue() {
        queueBox.removeAllViews()
        if (tracks.isEmpty()) { queueBox.addView(label("Todavía no hay canciones importadas.", 12, MUTED)); return }
        tracks.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(5)); setBackgroundColor(if (i % 2 == 0) PANEL else BG) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label("${i + 1}. ${t.title}", 12, if (i == currentIndex) GOLD else WHITE, true))
            info.addView(label("${t.bpm?.let { "$it BPM" } ?: "BPM --"}  ·  ${t.key ?: "Tonalidad --"}", 10, MUTED))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(action("▶") { playTrack(i) })
            row.addView(action("♫") { editAnalysis(t) })
            queueBox.addView(row)
        }
    }

    private fun importFolder(uri: android.net.Uri) {
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val folder = DocumentFile.fromTreeUri(this, uri) ?: return
        val found = mutableListOf<Track>()
        fun scan(dir: DocumentFile) { dir.listFiles().forEach { f ->
            if (f.isDirectory) scan(f)
            else if (f.isFile && (f.type?.startsWith("audio/") == true || f.name.orEmpty().matches(Regex("(?i).+\\.(mp3|wav|flac|m4a|aac|ogg|opus|wma)$")))) {
                if (found.none { it.uri == f.uri }) found.add(Track(f.uri, f.name ?: "Audio"))
            }
        } }
        scan(folder)
        tracks.clear(); tracks.addAll(found.sortedBy { it.title.lowercase(Locale.getDefault()) })
        status.text = "Importadas ${tracks.size} canciones · biblioteca lista"
        render()
    }

    private fun editAnalysis(track: Track) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16)) }
        val bpm = EditText(this).apply { hint = "BPM (ej. 124)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(track.bpm?.toString() ?: "") }
        val key = EditText(this).apply { hint = "Camelot (ej. 8A o 9B)"; setText(track.key ?: "") }
        box.addView(bpm); box.addView(key)
        android.app.AlertDialog.Builder(this).setTitle(track.title).setMessage("Datos para ordenar mezclas armónicas. El análisis automático de BPM/tonalidad aún no está incorporado.").setView(box)
            .setPositiveButton("GUARDAR") { _, _ -> track.bpm = bpm.text.toString().toIntOrNull()?.takeIf { it in 50..220 }; track.key = key.text.toString().trim().uppercase(Locale.US).takeIf { it.matches(Regex("(1[0-2]|[1-9])[AB]")) }; renderQueue() }
            .setNegativeButton("CANCELAR", null).show()
    }

    private fun toggleParty() {
        if (tracks.isEmpty()) { Toast.makeText(this, "Primero importá una carpeta de música", Toast.LENGTH_SHORT).show(); return }
        if (partyOn) { partyOn = false; players.forEach { it?.pause() }; status.text = "Fiesta pausada" }
        else if (currentIndex >= 0) { partyOn = true; players[active]?.play(); status.text = "Modo Fiesta activo" }
        else { partyOn = true; playTrack(selectFirst()) }
        updatePlayButton()
    }

    private fun selectFirst(): Int = if (shuffle) tracks.indices.random() else 0
    private fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        partyOn = true; crossfading = false; currentIndex = index; nextIndex = chooseNext(index)
        val p = players[active] ?: return
        p.stop(); p.clearMediaItems(); p.setMediaItem(MediaItem.fromUri(tracks[index].uri)); p.volume = masterVolume; p.prepare(); p.play()
        players[1 - active]?.pause(); players[1 - active]?.clearMediaItems()
        updateNowPlaying(); renderQueue(); updatePlayButton()
    }

    private fun chooseNext(from: Int): Int {
        if (tracks.size <= 1) return from
        val options = tracks.indices.filter { it != from }
        if (!shuffle) return (from + 1) % tracks.size
        return options.minByOrNull { compatibilityScore(tracks[from], tracks[it]) } ?: options.random()
    }

    private fun compatibilityScore(a: Track, b: Track): Int {
        val tempo = if (a.bpm != null && b.bpm != null) minOf(abs(a.bpm!! - b.bpm!!), abs(a.bpm!! - b.bpm!! * 2), abs(a.bpm!! * 2 - b.bpm!!)) * 2 else 25
        val key = if (a.key != null && b.key != null) camelotDistance(a.key!!, b.key!!) * 15 else 25
        return tempo + key
    }

    private fun camelotDistance(a: String, b: String): Int {
        val x = Regex("(1[0-2]|[1-9])([AB])").matchEntire(a) ?: return 6
        val y = Regex("(1[0-2]|[1-9])([AB])").matchEntire(b) ?: return 6
        val n = x.groupValues[1].toInt(); val m = y.groupValues[1].toInt()
        return minOf(abs(n - m), 12 - abs(n - m)) + if (x.groupValues[2] == y.groupValues[2]) 0 else 1
    }

    private fun beginCrossfade() {
        val next = nextIndex
        if (next !in tracks.indices) { startNextImmediately(); return }
        crossfading = true
        val incomingIndex = 1 - active
        val incoming = players[incomingIndex] ?: return
        incoming.stop(); incoming.clearMediaItems(); incoming.setMediaItem(MediaItem.fromUri(tracks[next].uri)); incoming.volume = 0f; incoming.prepare(); incoming.play()
        val outgoing = players[active] ?: return
        val duration = if (fadeSeconds == 0) 1 else fadeSeconds * 1000L
        val started = System.currentTimeMillis()
        val fade = object : Runnable {
            override fun run() {
                if (!partyOn) { incoming.pause(); crossfading = false; return }
                val fraction = ((System.currentTimeMillis() - started).toFloat() / duration).coerceIn(0f, 1f)
                outgoing.volume = masterVolume * (1f - fraction)
                incoming.volume = masterVolume * fraction
                if (fraction < 1f) handler.postDelayed(this, 80) else {
                    outgoing.pause(); outgoing.clearMediaItems(); active = incomingIndex; currentIndex = next; nextIndex = chooseNext(currentIndex); crossfading = false
                    updateNowPlaying(); renderQueue(); status.text = "Mezcla automática · ${tracks[currentIndex].title}"
                }
            }
        }
        handler.post(fade)
    }

    private fun startNextImmediately() {
        if (tracks.isEmpty()) return
        val n = if (nextIndex in tracks.indices) nextIndex else chooseNext(currentIndex.coerceAtLeast(0))
        playTrack(n)
    }
    private fun skipTrack() { if (tracks.isNotEmpty()) { val n = if (nextIndex in tracks.indices) nextIndex else chooseNext(currentIndex.coerceAtLeast(0)); playTrack(n) } }
    private fun previousTrack() { if (tracks.isNotEmpty()) playTrack(if (currentIndex > 0) currentIndex - 1 else tracks.lastIndex) }
    private fun updateNowPlaying() {
        val t = tracks.getOrNull(currentIndex) ?: return
        nowTitle.text = t.title
        nowMeta.text = "${t.bpm?.let { "$it BPM" } ?: "BPM --"}  ·  ${t.key ?: "KEY --"}  ·  ${durationText(players[active]?.duration ?: 0)}"
    }
    private fun updatePlayButton() { if (::playButton.isInitialized) playButton.text = if (partyOn && players[active]?.isPlaying == true) "Ⅱ  PAUSAR FIESTA" else "▶  INICIAR FIESTA" }
    private fun durationText(ms: Long) = if (ms <= 0) "--:--" else String.format(Locale.US, "%02d:%02d", ms / 60000, ms / 1000 % 60)
    private fun listener(block: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { if (user) block(p) }; override fun onStartTrackingTouch(s: SeekBar) {}; override fun onStopTrackingTouch(s: SeekBar) {} }
    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(dp(5), dp(6), dp(5), dp(6)) }
    private fun action(text: String, click: () -> Unit) = Button(this).apply { this.text = text; textSize = 10f; isAllCaps = false; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(42, 53, 68)); setOnClickListener { click() } }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.rgb(48, 60, 76)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); players.forEach { it?.release() }; super.onDestroy() }
    data class Track(val uri: android.net.Uri, val title: String, var bpm: Int? = null, var key: String? = null)
    companion object { const val BG = 0xFF080C13.toInt(); const val PANEL = 0xFF151E2A.toInt(); const val GOLD = 0xFFFFC34D.toInt(); const val CYAN = 0xFF38D9E8.toInt(); const val WHITE = Color.WHITE; const val MUTED = 0xFF9AA7B7.toInt() }
}
