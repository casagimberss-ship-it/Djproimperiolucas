package com.imperio.djpromix
/** Merge layer for multiple SAF-imported playlists; caller persists URI grants and catalog. */
class PlaylistImportCatalog {
 data class TrackRef(val uri:String,val displayName:String,val playlistName:String)
 data class Playlist(val name:String,val tracks:List<TrackRef>)
 private val playlists=linkedMapOf<String,Playlist>()
 fun add(value:Playlist){playlists[value.name]=value}
 fun remove(name:String){playlists.remove(name)}
 fun allPlaylists()=playlists.values.toList()
 fun mergedTracks():List<TrackRef>{val seen=linkedSetOf<String>();return playlists.values.flatMap{it.tracks}.filter{seen.add(it.uri)}}
 fun playlistCount()=playlists.size
}
