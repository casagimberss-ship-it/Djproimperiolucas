package com.imperio.djpromix

import kotlin.math.abs

/** Deterministic on-device DJ decision engine. It uses analyzed/manual metadata; it is not a cloud or neural model. */
object AiDjEngine {
    enum class Style(val label: String, val targetEnergy: Int) {
        PROGRESSIVE("PROGRESIVA", 4), STEADY("ENERGÍA CONSTANTE", 3), HITS("ÉXITOS", 5), HARMONIC("ARMÓNICA", 3)
    }

    data class Candidate(
        val index: Int,
        val bpm: Int?,
        val key: String?,
        val energy: Int?,
        val recentlyPlayed: Boolean
    )

    data class Decision(val index: Int, val score: Int, val reason: String)

    fun choose(current: Candidate, options: List<Candidate>, style: Style): Decision? {
        if (options.isEmpty()) return null
        val ranked = options.map { candidate -> candidate to score(current, candidate, style) }
            .sortedBy { it.second }
        val best = ranked.first()
        val reasons = mutableListOf<String>()
        if (current.bpm != null && best.first.bpm != null) reasons += "tempo compatible"
        if (current.key != null && best.first.key != null) reasons += "tonalidad armónica"
        if (best.first.energy != null) reasons += "energía ${best.first.energy}/5"
        if (reasons.isEmpty()) reasons += "datos disponibles de biblioteca"
        return Decision(best.first.index, best.second, reasons.joinToString(" · "))
    }

    private fun score(a: Candidate, b: Candidate, style: Style): Int {
        var total = 0.0
        if (a.bpm != null && b.bpm != null) {
            val direct = abs(a.bpm - b.bpm).toDouble()
            val halfDouble = minOf(abs(a.bpm - b.bpm * 2), abs(a.bpm * 2 - b.bpm)).toDouble()
            total += minOf(direct, halfDouble) * 1.8
        } else total += 22.0

        if (a.key != null && b.key != null) total += camelotDistance(a.key, b.key) * if (style == Style.HARMONIC) 22.0 else 13.0
        else total += if (style == Style.HARMONIC) 30.0 else 15.0

        if (b.energy != null) {
            val currentEnergy = a.energy ?: a.bpm?.let { ((it - 80) / 20 + 1).coerceIn(1, 5) } ?: 3
            val desired = when (style) {
                Style.PROGRESSIVE -> (currentEnergy + 1).coerceAtMost(5)
                Style.STEADY -> currentEnergy
                Style.HITS -> style.targetEnergy
                Style.HARMONIC -> currentEnergy
            }
            total += abs(b.energy - desired) * if (style == Style.PROGRESSIVE || style == Style.HITS) 12.0 else 8.0
        }
        if (b.recentlyPlayed) total += 1000.0
        return total.toInt()
    }

    private fun camelotDistance(a: String, b: String): Int {
        val x = Regex("(1[0-2]|[1-9])([AB])").matchEntire(a) ?: return 6
        val y = Regex("(1[0-2]|[1-9])([AB])").matchEntire(b) ?: return 6
        val n = x.groupValues[1].toInt(); val m = y.groupValues[1].toInt()
        return minOf(abs(n - m), 12 - abs(n - m)) + if (x.groupValues[2] == y.groupValues[2]) 0 else 1
    }
}
