package com.imperio.djpromix

/** Contract for an on-device vocal activity model. A real model/runtime must be supplied. */
interface VocalActivityAnalyzer {
    data class WindowResult(
        val startMs: Long,
        val endMs: Long,
        val vocalProbability: Float,
        val confidence: Float
    ) {
        init {
            require(startMs >= 0 && endMs > startMs)
            require(vocalProbability in 0f..1f && confidence in 0f..1f)
        }
    }

    /** Returns timestamped estimates; implementations must run off the UI/audio callback thread. */
    suspend fun analyzePcm(monoPcm: FloatArray, sampleRate: Int): List<WindowResult>
}
