package com.imperio.djpromix

/** Analysis values are estimates; confidence must travel with every detection. */
data class TrackMixAnalysis(
    val bpm: Double? = null,
    val bpmConfidence: Double = 0.0,
    val camelotKey: String? = null,
    val keyConfidence: Double = 0.0,
    val introEndMs: Long? = null,
    val outroStartMs: Long? = null,
    val phraseLengthBeats: Int? = null,
    val vocalIntervals: List<LongRange> = emptyList(),
    val instrumentalIntervals: List<LongRange> = emptyList(),
    val dropTimesMs: List<Long> = emptyList(),
    val energy: Double? = null,
    val loudnessLufs: Double? = null,
    val silenceIntervals: List<LongRange> = emptyList()
) {
    init {
        require(bpm == null || bpm in 40.0..240.0)
        require(bpmConfidence in 0.0..1.0 && keyConfidence in 0.0..1.0)
        require(energy == null || energy in 0.0..1.0)
    }
}

data class TransitionCandidate(
    val outgoingPositionMs: Long,
    val incomingPositionMs: Long,
    val durationBeats: Int,
    val tempoRatio: Double,
    val score: Double,
    val reasons: List<String>
)
