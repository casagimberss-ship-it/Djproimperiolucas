package com.imperio.djpromix

import kotlin.math.floor

/** Pure timing model for quantized roll/slicer controls. Does not seek or process PCM. */
object LoopRollSlicer {
    data class Region(val startMs: Long, val endMs: Long) {
        init { require(startMs >= 0 && endMs > startMs) }
        val durationMs: Long get() = endMs - startMs
    }

    data class Slice(val index: Int, val startMs: Long, val endMs: Long)

    fun beatDurationMs(bpm: Double): Long {
        require(bpm.isFinite() && bpm in 30.0..300.0)
        return (60_000.0 / bpm).toLong().coerceAtLeast(1L)
    }

    fun quantizedRegion(positionMs: Long, bpm: Double, beats: Double, trackDurationMs: Long): Region {
        require(positionMs >= 0 && trackDurationMs > 0 && beats > 0.0)
        val beat = beatDurationMs(bpm)
        val start = ((positionMs.toDouble() / beat).let(::floor) * beat).toLong().coerceIn(0L, trackDurationMs - 1)
        val requested = (beat * beats).toLong().coerceAtLeast(1L)
        val end = (start + requested).coerceAtMost(trackDurationMs)
        return Region(start, end)
    }

    fun split(region: Region, count: Int): List<Slice> {
        require(count in 2..64)
        return List(count) { i ->
            val start = region.startMs + region.durationMs * i / count
            val end = region.startMs + region.durationMs * (i + 1) / count
            Slice(i, start, end)
        }
    }
}
