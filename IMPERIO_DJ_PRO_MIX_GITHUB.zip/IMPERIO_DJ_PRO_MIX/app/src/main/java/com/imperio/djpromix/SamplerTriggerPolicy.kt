package com.imperio.djpromix

/** Scheduling policy for beat-quantized sampler triggers. Actual scheduling belongs to the audio engine. */
object SamplerTriggerPolicy {
    fun nextBeatDelayMs(currentBpm: Double, beatPhase: Double): Long? {
        if (currentBpm !in 40.0..240.0 || beatPhase !in 0.0..1.0) return null
        val beatMs=60000.0/currentBpm
        return ((1.0-beatPhase)*beatMs).toLong().coerceAtLeast(0)
    }
}
