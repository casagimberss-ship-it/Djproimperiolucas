package com.imperio.djpromix

import kotlin.math.pow

/** Safe planning helpers; final gain/DSP must be applied by the audio graph. */
object MixSafetyPoliciesV118 {
    data class GainPlan(val outgoingLinear: Float, val incomingLinear: Float, val peakCeilingDbfs: Float = -1.0f)
    fun equalPower(progress: Float): GainPlan {
        val x = progress.coerceIn(0f, 1f)
        return GainPlan(kotlin.math.cos(x * Math.PI / 2).toFloat(), kotlin.math.sin(x * Math.PI / 2).toFloat())
    }
    fun loudnessCompensation(sourceLufs: Float?, targetLufs: Float = -14f, maxBoostDb: Float = 6f, maxCutDb: Float = -9f): Float {
        if (sourceLufs == null || !sourceLufs.isFinite()) return 1f
        val gainDb = (targetLufs - sourceLufs).coerceIn(maxCutDb, maxBoostDb)
        return 10.0.pow(gainDb / 20.0).toFloat()
    }
    fun shouldSkipSilence(silenceDurationMs: Long, minimumMs: Long = 1800L): Boolean = silenceDurationMs >= minimumMs
}
