package com.imperio.djpromix
import kotlin.math.abs
object FiestaSetPlanner {
 data class Track(val id:String,val genre:String,val bpm:Int?,val camelot:String?,val energy:Int?,val recentlyPlayed:Boolean=false)
 data class Suggestion(val track:Track,val score:Int,val reasons:List<String>)
 fun rank(current:Track,candidates:List<Track>,genre:String?=null,targetEnergy:Int?=null)=candidates.filter{it.id!=current.id}.map{t->var s=0;val r=mutableListOf<String>();if(t.genre==current.genre){s+=25;r+="mismo género"};if(genre!=null&&t.genre==genre){s+=20;r+="género de tanda"};if(t.bpm!=null&&current.bpm!=null){val d=minOf(abs(t.bpm-current.bpm),abs(t.bpm*2-current.bpm),abs(t.bpm-current.bpm*2));s+=(20-d).coerceAtLeast(0);r+="BPM cercano"};if(t.camelot!=null&&current.camelot!=null&&HarmonicMixPlanner.compare(current.camelot,t.camelot).compatible){s+=20;r+="armónica compatible"};if(targetEnergy!=null&&t.energy!=null){s+=(15-abs(targetEnergy-t.energy)*4).coerceAtLeast(0);r+="energía objetivo"};if(t.recentlyPlayed){s-=30;r+="reproducida recientemente"};Suggestion(t,s,r)}.sortedByDescending{it.score}
}
