package com.imperio.djpromix

import kotlin.math.abs

/** Explainable first-pass transition ranking. This is a heuristic, not a trained neural model. */
object PredictiveTransitionEngine {
    data class Track(
        val id: String,
        val bpm: Double,
        val energy: Double,
        val keyCamelot: String?,
        val introMs: Long,
        val outroMs: Long,
        val vocalProbability: Double = 0.0,
        val analysisConfidence: Double = 0.5
    )

    data class Suggestion(val trackId: String, val score: Int, val reasons: List<String>)

    fun rank(current: Track, candidates: List<Track>, maxBpmDelta: Double = 8.0): List<Suggestion> {
        require(maxBpmDelta in 0.5..40.0)
        return candidates.filter { it.id != current.id && it.bpm > 0.0 }
            .map { candidate ->
                val bpmDelta = abs(current.bpm - candidate.bpm)
                val energyDelta = abs(current.energy - candidate.energy)
                val reasons = mutableListOf<String>()
                var score = 100
                score -= (bpmDelta * 4).toInt()
                if (bpmDelta <= maxBpmDelta) reasons += "BPM compatible" else reasons += "BPM difference high"
                score -= (energyDelta * 20).toInt()
                reasons += if (energyDelta <= 0.2) "Energy continuity" else "Energy change"
                if (current.keyCamelot != null && current.keyCamelot == candidate.keyCamelot) {
                    score += 12; reasons += "Same Camelot key"
                }
                if (current.vocalProbability > 0.65 && candidate.vocalProbability > 0.65) {
                    score -= 10; reasons += "Vocal overlap risk"
                }
                score = (score * candidate.analysisConfidence.coerceIn(0.0, 1.0)).toInt().coerceIn(0, 100)
                Suggestion(candidate.id, score, reasons)
            }.sortedByDescending { it.score }
    }
}
