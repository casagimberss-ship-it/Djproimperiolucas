package com.imperio.djpromix

/** Produces logical lighting events only. A separately validated DMX transport is required. */
object MusicLightSyncEngine {
    enum class EventType { BEAT, DOWNBEAT, BASS_HIT, ENERGY_CHANGE, PHRASE_BOUNDARY }
    data class MusicEvent(val timeMs: Long, val type: EventType, val intensity: Float)

    fun beatEvents(startMs: Long, durationMs: Long, bpm: Double, energy: Float): List<MusicEvent> {
        require(startMs >= 0 && durationMs >= 0)
        require(bpm.isFinite() && bpm in 30.0..300.0)
        val safeEnergy = energy.coerceIn(0f, 1f)
        val beatMs = (60_000.0 / bpm).toLong().coerceAtLeast(1L)
        val count = (durationMs / beatMs).coerceAtMost(10_000L).toInt()
        return List(count) { index ->
            val type = if (index % 4 == 0) EventType.DOWNBEAT else EventType.BEAT
            MusicEvent(startMs + index * beatMs, type, safeEnergy)
        }
    }
}
