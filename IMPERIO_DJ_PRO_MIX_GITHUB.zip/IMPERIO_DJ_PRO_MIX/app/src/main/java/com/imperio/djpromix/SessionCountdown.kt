package com.imperio.djpromix

/** Monotonic-clock independent timer state. Host UI/service supplies elapsed seconds. */
class SessionCountdown {
    data class State(val totalSeconds: Long, val elapsedSeconds: Long, val remainingSeconds: Long, val finished: Boolean)
    private var total = 0L
    private var elapsed = 0L
    fun start(minutes: Int) { require(minutes in 1..720); total=minutes*60L; elapsed=0L }
    fun addElapsed(seconds: Long): State { elapsed=(elapsed+seconds.coerceAtLeast(0)).coerceAtMost(total); return state() }
    fun reset() { total=0L; elapsed=0L }
    fun state() = State(total,elapsed,(total-elapsed).coerceAtLeast(0),total>0 && elapsed>=total)
}
