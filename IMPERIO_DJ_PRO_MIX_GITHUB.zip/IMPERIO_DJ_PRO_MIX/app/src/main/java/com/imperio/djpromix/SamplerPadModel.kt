package com.imperio.djpromix

/** Four-pad persistent sampler descriptor. Playback engine is deliberately separate. */
object SamplerPadModel {
    enum class Mode { ONE_SHOT, LOOP }
    data class Pad(val index: Int, val title: String, val uri: String?, val mode: Mode, val volume: Float, val quantize: Boolean, val syncBpm: Boolean) {
        init { require(index in 1..4); require(volume in 0f..1f) }
    }
    fun emptyPads() = (1..4).map { Pad(it,"PAD $it",null,Mode.ONE_SHOT,1f,false,false) }
    fun normalized(pad: Pad) = pad.copy(title=pad.title.take(32),volume=pad.volume.coerceIn(0f,1f))
}
