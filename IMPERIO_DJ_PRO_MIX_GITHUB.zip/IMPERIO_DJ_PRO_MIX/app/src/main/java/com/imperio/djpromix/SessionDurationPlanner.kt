package com.imperio.djpromix

/** Computes a session schedule from a target duration and average track length. */
object SessionDurationPlanner {
    data class Schedule(val targetMinutes: Int, val estimatedTracks: Int, val transitionReserveSeconds: Int, val warning: String)
    fun create(targetMinutes: Int, averageTrackSeconds: Int, transitionSeconds: Int = 12): Schedule? {
        if (targetMinutes !in 1..720 || averageTrackSeconds !in 30..1800) return null
        val total = targetMinutes * 60
        val effective = (averageTrackSeconds - transitionSeconds.coerceIn(0,60)).coerceAtLeast(30)
        val count = kotlin.math.ceil(total.toDouble()/effective).toInt()
        return Schedule(targetMinutes,count,transitionSeconds.coerceIn(0,60),"Estimación: ajustar según duración real y mezcla")
    }
}
