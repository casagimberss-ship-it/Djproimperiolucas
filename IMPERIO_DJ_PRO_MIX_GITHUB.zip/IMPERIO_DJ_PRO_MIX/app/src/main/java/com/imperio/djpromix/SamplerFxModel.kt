package com.imperio.djpromix

/** Serializable-friendly FX intent. Parameters are not audio processing by themselves. */
object SamplerFxModel {
    enum class Type { REVERB, ECHO, DELAY, FILTER, FLANGER }
    data class Effect(val type: Type, val wet: Float = 0.25f, val feedback: Float = 0.25f, val cutoffHz: Int = 12_000) {
        init { require(wet in 0f..1f); require(feedback in 0f..0.85f); require(cutoffHz in 20..20_000) }
    }
    data class Chain(val enabled: Boolean = false, val effects: List<Effect> = emptyList()) {
        init { require(effects.size <= 5) }
    }
    fun safe(chain: Chain) = chain.copy(effects = chain.effects.take(5).map {
        it.copy(wet = it.wet.coerceIn(0f, 1f), feedback = it.feedback.coerceIn(0f, .85f), cutoffHz = it.cutoffHz.coerceIn(20, 20_000))
    })
}
