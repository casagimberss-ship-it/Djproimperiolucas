package com.imperio.djpromix
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
/** Manual genre corrections persist only on device; no network or telemetry. */
class OfflineLearningStore(context:Context){
 private val prefs=context.getSharedPreferences("modo_fiesta_smart_genre_v115",Context.MODE_PRIVATE)
 fun saveGenreCorrection(uri:String,genreId:String){val old=JSONArray(prefs.getString("genre_corrections","[]"));val next=JSONArray();for(i in 0 until old.length()){val o=old.optJSONObject(i)?:continue;if(o.optString("uri")!=uri)next.put(o)};next.put(JSONObject().put("uri",uri).put("genre",GenreCatalog.normalize(genreId)).put("at",System.currentTimeMillis()));prefs.edit().putString("genre_corrections",next.toString()).apply()}
 fun genreCorrection(uri:String):String?{val a=JSONArray(prefs.getString("genre_corrections","[]"));for(i in a.length()-1 downTo 0){val o=a.optJSONObject(i)?:continue;if(o.optString("uri")==uri)return GenreCatalog.normalize(o.optString("genre"))};return null}
}
