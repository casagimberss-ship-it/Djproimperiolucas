package com.imperio.djpromix

/** Offline set sequencing rules; history is supplied by the host repository. */
class PartySetPolicyV118 {
    data class Track(val id: String, val artist: String, val energy: Double, val rhythmFamily: String, val danceScore: Double = 0.5)
    data class Rules(val noRepeatWindow: Int = 12, val targetEnergy: Double = 0.75, val progressiveStep: Double = 0.06)

    fun rank(candidates: List<Track>, recentTrackIds: Set<String>, recentArtists: Set<String>, rules: Rules = Rules()): List<Track> =
        candidates.filter { it.id !in recentTrackIds && it.artist !in recentArtists }
            .sortedByDescending { 1.0 - kotlin.math.abs(it.energy - rules.targetEnergy) + it.danceScore * .25 }

    fun progressiveTarget(currentEnergy: Double, step: Double = .06): Double = (currentEnergy + step).coerceIn(0.0, 1.0)

    fun closingTarget(currentEnergy: Double, remainingSongs: Int): Double {
        if (remainingSongs <= 1) return (currentEnergy * .55).coerceIn(0.0, 1.0)
        return (currentEnergy - .08 / remainingSongs).coerceIn(0.0, 1.0)
    }

    fun canChangeRhythm(from: String, to: String, bridgeTrackAvailable: Boolean): Boolean = from == to || bridgeTrackAvailable
}
