package com.imperio.djpromix
import kotlin.math.abs
object HarmonicMixPlanner {
 data class Match(val compatible:Boolean,val distance:Int,val reason:String)
 fun compare(first:String?,second:String?):Match{val a=parse(first)?:return Match(false,99,"Tonalidad A no disponible");val b=parse(second)?:return Match(false,99,"Tonalidad B no disponible");val d=minOf(abs(a.first-b.first),12-abs(a.first-b.first));val ok=(a.first==b.first&&a.second==b.second)||(a.second==b.second&&d==1)||(a.first==b.first&&a.second!=b.second);return Match(ok,d+if(a.second==b.second)0 else 1,if(ok)"Compatibilidad Camelot sugerida" else "Cambio armónico más arriesgado")}
 private fun parse(s:String?):Pair<Int,String>?{val m=Regex("(1[0-2]|[1-9])([AB])").matchEntire(s?.trim()?.uppercase()?:"")?:return null;return m.groupValues[1].toInt() to m.groupValues[2]}
}
