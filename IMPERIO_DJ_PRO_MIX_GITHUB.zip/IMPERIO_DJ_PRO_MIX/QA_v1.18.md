# QA v1.18 — Matriz propuesta

1. Offline: modo avión, sin DNS/red; análisis, cola y selector siguen disponibles.
2. BPM: confianza baja, diferencia dentro/fuera de límite, archivos con BPM variable y halftime/double-time.
3. Armónica: Camelot compatible, incompatible, tonalidad desconocida y baja confianza.
4. Frases/intros/outros: metadatos ausentes, detección falsa y límites de archivo.
5. Vocal: intervalos solapados/no solapados y detector incierto; permitir override manual.
6. Bass Swap/crossfade: medir pico combinado y evitar clipping.
7. Silencio: silencio real, breakdown, intro ambiental y pausa intencional; nunca saltar por duración solamente.
8. Set: no repetir pista/artista, historial vacío, biblioteca pequeña y cambios de familia rítmica sin puente.
9. Vista previa: comprobar ruta de salida real, mezcla principal intacta, volumen independiente y desconexión de auriculares.
10. Fin de set: timer a cero durante reproducción, espera de fin real, tema pausado, error de decoder, grabación activa/inactiva, cierre de archivo y persistencia de estadísticas.
11. Regresión: reproducción dual, sampler, loops, cues, grabación, biblioteca, preferencias, Dark Profesional y compatibilidad de datos anteriores.
12. Rendimiento: CPU, memoria, batería, latencia y estabilidad en Android 8+ (API 26+) con pantalla apagada.
