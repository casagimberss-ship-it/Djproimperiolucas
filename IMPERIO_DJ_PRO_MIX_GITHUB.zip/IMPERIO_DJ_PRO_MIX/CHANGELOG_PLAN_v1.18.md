# Cambios planificados v1.18

- Selector automático de transición con BPM, tonalidad, frases y seguridad vocal.
- Perfiles Beatmatch, Harmonic, Phrase, Intro, Outro, Bass Swap, Vocal Safe, Drop y Loop.
- Perfiles de fiesta explosiva/progresiva, pista llena, sin repetición, cambios de ritmo, energía y cierre.
- Políticas de compensación de loudness y detección temporal de silencios.
- Diseño de mezcla asistida y vista previa.
- Cierre diferido de sesión al finalizar el tema actual.
