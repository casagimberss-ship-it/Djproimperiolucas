# Arquitectura v1.18

```text
Biblioteca local -> Analizador offline -> TrackMixAnalysis (+ confianza)
                                  |
                                  v
Cola / historial -> PartySetPolicy -> TransitionSelector -> revisión DJ
                                                   |
                                                   v
                                  Scheduler de transición (pendiente)
                                                   |
                                     Deck A / Deck B (ExoPlayer)

Temporizador de sesión -> SetEndCoordinator -> fin de pista -> stop decks
                                                   -> cerrar grabación
                                                   -> guardar estadísticas
```

Los archivos Kotlin añadidos son modelos y políticas puras. No sustituyen el analizador acústico, no ejecutan DSP, no manipulan ExoPlayer y no agregan controles visuales. Las capas host deberán inyectar callbacks reales y almacenamiento.
