# Arquitectura v1.17

```text
MainActivity (Dark Profesional)
  └── SamplerPanel (4 pads)
       ├── PadState / Trim IN-OUT
       ├── WaveformCache ← SamplerWaveformAnalyzer ← PCM Decoder
       ├── SamplerBankRepository (SAF URIs + bancos locales)
       ├── BeatClock ← Deck Analyzer (BPM / phase / downbeat)
       │    └── SamplerBeatGrid → Audio Scheduler
       ├── TempoMatcher → Playback Engine
       ├── Preview Monitor → Monitor/Audio route
       └── Per-pad FX Graph → Sampler Bus → Limiter → Master
```

## Límites entre capas
- UI solo presenta estado y envía comandos; no decodifica ni procesa audio.
- Repository conserva metadatos y grants SAF; nunca almacena audio binario dentro de preferencias.
- El analizador entrega BPM y fase con timestamp monotónico. El scheduler convierte beat target a tiempo de audio.
- Los FX se ejecutan fuera del hilo principal. Evitar asignaciones y bloqueos en callbacks de audio.
- El limiter protege el bus sampler; el master existente sigue siendo la etapa final común.
- El preview debe modelarse como monitor route opcional; Android puede no ofrecer salida independiente.

## Datos persistentes
Namespace nuevo: `modo_fiesta_sampler_banks_v117`.
Cada banco contiene nombre y hasta cuatro URIs SAF. Los parámetros de pad (trim, quantize, tempo, FX) se almacenarán versionados por banco. Se conservará intacto `modo_fiesta_sampler_audio_v116`.
