# MODO FIESTA v1.13 — Plan técnico de desarrollo

**Creada por DJ Lucas Quintana**  
Base de código disponible: v1.11.0.  
Estado de este paquete: base de desarrollo + especificación; no es todavía una APK v1.13 funcional.

## Alcance confirmado

Se seleccionaron las mejoras 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 y 16:

- Loops inteligentes.
- Analizador de espectro.
- Procesamiento Master: compresor, limitador, ganancia y protección de clipping.
- FX Rack con Echo, Reverb, Flanger, Delay y Filter; presets y sincronización BPM.
- Key Lock para variar tempo preservando la tonalidad.
- IA DJ autónoma con límites y supervisión configurables.
- Fiesta Inteligente: objetivos/curvas de energía por etapas.
- Detección musical avanzada: BPM, beatgrid, compás, tonalidad y cambios rítmicos.
- Asistente de transiciones con recomendaciones de entrada/salida y duración.
- Planificador de eventos por etapas.
- Backup/restauración de biblioteca, cues, análisis, listas y aprendizaje local.

## Regla de compatibilidad

No cambiar `applicationId` (`com.imperio.djpromix`), namespace, package Kotlin ni claves existentes de SharedPreferences. No borrar ni sobrescribir archivos de biblioteca. Toda nueva persistencia debe tener versión de esquema, migración idempotente y restauración segura. Los backups deben incluir manifiesto, versión, hashes y archivos de datos; nunca secretos ni permisos Android.

## Arquitectura propuesta

1. **Audio graph (primero):** separar fuente, decks actuales, buses de efectos y salida Master. Mantener los dos ExoPlayer existentes como comportamiento predeterminado. No prometer 4 decks ni captura PCM mezclada hasta validar la arquitectura de audio.
2. **DSP:** procesadores en cadena con bypass individual, parámetros normalizados y límites anti-clipping. Procesamiento fuera del hilo UI; buffers sin asignaciones por bloque.
3. **Loops:** posiciones en frames/tiempo de audio, cuantización a beatgrid y salida segura del loop. Validar cambios de seek y estados de ExoPlayer.
4. **Key Lock:** evaluar motor de time-stretch/pitch-shift compatible con Android y licencias. No simular Key Lock con cambio de velocidad; eso cambia también el tono.
5. **Análisis:** mantener resultados y confianza por separado. Beatgrid y downbeat deben poder corregirse manualmente. Etiquetar géneros/estructura como estimaciones cuando no exista modelo validado.
6. **IA local:** usar el modelo incremental existente como recomendador; autonomía por niveles (sugerir, preparar, ejecutar con confirmación, automático limitado). Reglas duras: no repetir pistas recientes, respetar BPM/tonalidad configurados y evitar transiciones de baja confianza.
7. **Planificador:** eventos y etapas en JSON versionado, con listas y objetivos de energía; exportación/importación independiente.
8. **Backup:** exportación ZIP con `manifest.json`, biblioteca lógica, cue, análisis, playlists, historial/modelo local. Importación en staging, validación de hashes y rollback ante error.

## Orden de implementación

### Fase A — estabilidad de audio
- Medir latencia, consumo, underruns y temperatura.
- Definir interfaz AudioProcessor y audio graph.
- Implementar loop cuantizado y visualización del espectro con FFT.

### Fase B — DSP
- Master gain + peak meter primero.
- Limiter/compresor con bypass y valores seguros.
- FX Rack con un efecto por vez; luego cadenas y presets.
- Key Lock solo después de elegir y validar un motor de time-stretch.

### Fase C — inteligencia
- Refinar beatgrid/downbeat y análisis multi-segmento.
- Añadir detección de cambios de energía y confianza.
- Asistente de transiciones explicable.
- Autonomía escalonada con interruptor de parada y límites configurables.

### Fase D — eventos y datos
- Planificador de eventos.
- Backup/restore con migración y pruebas de corrupción.
- Pruebas de actualización desde los datos de la versión anterior.

## Criterios de aceptación

- Las funciones actuales siguen operativas y la interfaz conserva su identidad.
- No se pierde biblioteca, cues, historial ni pesos locales al actualizar.
- Audio sin clipping añadido por los procesadores; bypass devuelve señal original.
- Loops permanecen estables durante al menos 30 minutos de prueba.
- FFT y DSP no bloquean el hilo principal.
- Key Lock se valida con pruebas auditivas y medición de tono; si no cumple, permanece desactivado.
- IA autónoma nunca ignora límites configurados y ofrece botón de detener/revertir.
- Backup restaurado reproduce listas, cues y preferencias en instalación de prueba.
- APK compilada por CI y probada en dispositivo real antes de declarar release.

## Estado de entrega

Este paquete contiene la base de código v1.11.0 disponible y la especificación v1.13. No se encontró una entrega fuente v1.12 en los archivos recuperables. Por eso no se declara que las mejoras de v1.12 estén integradas ni que las funciones v1.13 ya estén implementadas. No se aumenta el versionCode ni se etiqueta la APK como 1.13 hasta completar e integrar las fases anteriores.
