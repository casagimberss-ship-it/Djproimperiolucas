# Arquitectura objetivo

```text
UI actual MODO FIESTA
        |
Session / Event Planner ---- Local AI Orchestrator
        |                         |
Deck A / Deck B ---- Beatgrid + Transition Advisor
        |
Audio Graph (loop points -> channel processing -> FX bus -> Master bus)
        |                                      |
Spectrum / meters                       Compressor / Limiter
        |
Audio output + internal recording (según políticas Android)

Persistence: Library + Cues + Analysis + AI profile + Events
Backup service: versioned manifest + checksums + staged restore
```

**Restricciones:** no ejecutar DSP en UI thread; no crear buffers continuamente; no aplicar efectos dos veces en la ruta de grabación; respetar políticas de captura de Android; usar bypass seguro; y mantener migraciones compatibles.
