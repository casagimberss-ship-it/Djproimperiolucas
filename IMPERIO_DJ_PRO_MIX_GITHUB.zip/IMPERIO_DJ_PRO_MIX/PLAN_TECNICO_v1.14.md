# MODO FIESTA v1.14 — Plan técnico

**Crédito:** Creada por DJ Lucas Quintana  
**Selección confirmada:** 2, 6, 8 y 10.

## Alcance

1. **Loop Roll y Slicer:** repetición temporal cuantizada y división de una región en slices rítmicos. Debe respetar beatgrid, límites de pista y estado del reproductor. Roll debe volver a la posición musical prevista al soltar; Slicer requiere una fuente de audio con acceso de baja latencia para ser realmente simultáneo.
2. **Detección de voces:** análisis local de segmentos vocales/instrumentales. La primera integración debe producir marcas con confianza y permitir corrección manual; no afirmar separación de stems.
3. **Transiciones predictivas:** proponer varias alternativas con punto de entrada/salida, BPM, tonalidad, energía y confianza. La ejecución automática requiere confirmación o modo autónomo explícitamente activado.
4. **Luces sincronizadas con música:** generar eventos de iluminación a partir de beat, downbeat, energía y bandas espectrales. Salida física DMX requiere interfaz/controlador y protocolo confirmados; incluir simulador y modo seguro sin hardware.

## Compatibilidad y preservación

- Mantener `applicationId`, namespace y package `com.imperio.djpromix`.
- No renombrar ni eliminar claves de preferencias, archivos de biblioteca, Cue, historial o modelo local.
- Mantener reproducción y controles actuales como ruta predeterminada; nuevas funciones deben ser opt-in y tener bypass/desactivación.
- Versionar toda nueva persistencia y migrar de forma idempotente. No cambiar versionCode/versionName hasta que el paquete se integre y compile.
- Mantener el nombre visible **MODO FIESTA** y el crédito **Creada por DJ Lucas Quintana**.

## Arquitectura propuesta

### A. Loop Roll / Slicer
- Usar milisegundos/frames de audio, nunca índices de UI como reloj maestro.
- Cuantización por beatgrid y compás; longitudes iniciales 1/4, 1/2, 1, 2, 4 y 8 beats.
- Controlador de estado independiente de Activity: Idle, Armed, Active, Releasing, Error.
- Validar seeks, buffering, cambio de pista y salida del loop.
- La clase `LoopRollSlicer.kt` de este paquete contiene cálculo determinista de límites y plan de slices; todavía no intercepta el PCM ni está conectada a los reproductores.

### B. Detección vocal
- Pipeline offline por ventanas (p. ej. 2–4 s con solapamiento), resultados `vocalProbability` y `instrumentalProbability` con timestamp y confianza.
- Evaluar modelo on-device y tamaño/latencia en Android API 26+; no agregar modelo ficticio ni dependencia de red.
- Mantener análisis tradicional si el modelo no está disponible. Las marcas se presentan como estimaciones.
- `VocalActivityAnalyzer.kt` define el contrato; requiere seleccionar e incorporar un modelo real antes de producción.

### C. Transiciones predictivas
- Puntuar compatibilidad armónica, diferencia de BPM, energía, intro/outro, vocales superpuestas y confianza del beatgrid.
- Devolver top-N explicable; límites configurables y veto del DJ.
- La ejecución automática debe tener confirmación inicial, botón Stop y fallback a reproducción normal.
- `PredictiveTransitionEngine.kt` implementa una primera capa determinista de ranking; no sustituye el modelo IA existente ni se declara red neuronal nueva.

### D. Luces reactivas
- Normalizar entrada en eventos: Beat, Downbeat, BassHit, EnergyChange, PhraseBoundary.
- Motor de escenas separado del transporte DMX; escenas con límites de intensidad, blackout y botón de parada.
- Simulador visual/registro de eventos primero. La salida física queda bloqueada hasta conocer interfaz, chipset, universo y protocolo.
- `MusicLightSyncEngine.kt` genera eventos lógicos; no controla directamente hardware DMX.

## Secuencia de implementación

1. Integrar y probar Loop Roll (sin Slicer PCM todavía).
2. Incorporar detector vocal real y validar latencia/precisión en dispositivo.
3. Añadir ranking predictivo y vista de alternativas; después habilitar ejecución con confirmación.
4. Añadir motor de eventos de luces, simulador y pruebas; luego driver DMX compatible.
5. Integración de UI respetando el diseño actual, persistencia versionada y pruebas de regresión.

## Criterios de aceptación

- La app compila en CI y se instala sobre una versión anterior sin perder datos.
- Reproducción, biblioteca, Cue, análisis, grabación y aprendizaje local continúan funcionando.
- Loop Roll no deriva más de un beat en una prueba prolongada y recupera posición al soltar.
- Vocales se muestran con nivel de confianza y sin bloquear UI/audio.
- Recomendaciones incluyen explicación y no cambian pista sin autorización.
- Luces pueden probarse en simulador sin hardware; DMX real solo tras validar adaptador y protocolo.
- No se declara función terminada hasta que esté integrada, compilada y probada en dispositivo.
