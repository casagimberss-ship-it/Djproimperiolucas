# Compatibilidad y migración
- Mantener namespace/applicationId `com.imperio.djpromix`.
- No renombrar ni borrar claves SharedPreferences, caché, cues o historial existentes.
- Conservar `imperio_neural_dj` y `LocalNeuralDjModel`.
- Nuevos datos en claves independientes `modo_fiesta_smart_genre_v115`.
- Mantener SAF, ExoPlayer, servicios y grabación actuales.
- No cambiar versionCode/versionName hasta integrar y compilar una release real.
