# MODO FIESTA — Integración visible del sampler

## Cambios aplicados
- Se incorporó el panel **SAMPLER · 4 PADS** a la pantalla principal, entre Control de mezcla y Smart DJ.
- Cada pad puede seleccionar un archivo de audio local mediante el selector de documentos de Android.
- Cada pad usa un reproductor ExoPlayer independiente, separado de los dos reproductores principales de la mezcla.
- Modos One Shot y Loop por pad.
- Volumen independiente por pad, afectado también por Master Volume.
- Persistencia local de URI, nombre, modo y volumen. Se solicita permiso persistente de lectura cuando Android lo permite.
- Botón Detener todo.
- No se requiere Internet ni se agregaron dependencias externas.

## Alcance y límites honestos
- Esta integración hace visibles y reproducibles los cuatro pads.
- El audio del sampler se reproduce mientras la Activity está activa; los reproductores de sampler se liberan al destruir la Activity. No se implementó servicio persistente del sampler en segundo plano.
- No se implementó aún sincronización cuantizada al beat/BPM, bancos múltiples seleccionables, cadenas de efectos DSP por pad, ni preescucha/cue independiente.
- No se altera el motor de mezcla de dos decks ni los identificadores de aplicación/preferencias existentes.

## Pruebas pendientes
- Compilar con Android Gradle Plugin 8.7.3, Kotlin 2.0.21 y SDK 35.
- Probar selección y reproducción de MP3, WAV, M4A y formatos admitidos por el dispositivo.
- Verificar restauración de permisos URI después de cerrar y volver a abrir la app.
- Probar cuatro reproducciones simultáneas y carga de CPU/audio en el dispositivo objetivo.
