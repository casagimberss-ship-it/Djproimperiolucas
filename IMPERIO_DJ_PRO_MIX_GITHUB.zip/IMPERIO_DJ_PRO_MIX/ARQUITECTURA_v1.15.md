# Arquitectura v1.15
UI: Dark Profesional, biblioteca multi-playlist, etiquetas de género, Fiesta Mode y mixer A/B.
Datos: catálogo local, URI SAF, etiquetas corregidas y análisis cacheado.
Análisis: AudioAnalyzer existente más modelos locales de género/vocales a integrar.
DJ: energía, Camelot, frases, tandas y ranking de sugerencias.
Playback: ExoPlayer actual; capa crossfader y scheduling por beats.
Aprendizaje: LocalNeuralDjModel existente y OfflineLearningStore nuevo.
Reglas: ninguna transmisión de datos; no activar automatismos sin consentimiento; confianza insuficiente implica revisión manual.
