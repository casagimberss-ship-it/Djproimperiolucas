# Compatibilidad y migración v1.18

- Se conserva namespace/applicationId `com.imperio.djpromix`, minSdk 26, compileSdk 35, Java 17, Kotlin DSL y dependencias del ZIP base.
- Se preservan clases anteriores, claves de preferencias y estructura de datos; los nuevos modelos no migran ni borran datos.
- No se cambia versionCode 12 ni versionName 1.11.0 porque esta entrega es una base de desarrollo, no una versión Android integrada/compilada.
- Las preferencias nuevas que se integren deben usar claves namespaced `modo_fiesta_v118_*`, con defaults seguros y lectura tolerante a valores ausentes.
- No se requieren permisos nuevos para las políticas puras. Preescucha física independiente dependerá de ruta/dispositivo y debe verificarse antes de declararse disponible.
