# Compatibilidad v1.16
- Mantener `com.imperio.djpromix` como namespace/applicationId.
- No alterar claves de preferencias ni archivos de biblioteca/caché/cues.
- Almacenar sampler y sesión en namespaces nuevos.
- Reusar el servicio de reproducción y el grabador actuales; no duplicarlos.
- Si una función nueva falla, permitir seguir usando decks y biblioteca anteriores.
- Mantener versionCode/versionName hasta integración y compilación real.
