# Matriz de pruebas — MODO FIESTA v1.13

| Área | Prueba | Resultado requerido |
|---|---|---|
| Actualización | Instalar sobre versión anterior con datos | Biblioteca y preferencias intactas |
| Reproducción | Reproducir, pausar, buscar, cambiar pista | Sin bloqueo ni pérdida de estado |
| Loops | 1/2/4/8/16/32 beats, salida y seek | Repetición precisa, sin clicks críticos |
| FFT | Graves/medios/agudos y carga prolongada | Actualización fluida sin bloquear UI |
| Master | Ganancia, compresor, limitador, bypass | Sin clipping digital añadido |
| FX | Activar/desactivar y cambiar preset | Sin ruidos, latencia excesiva ni fuga de recursos |
| Key Lock | Cambiar BPM con tonalidad estable | Tono estable dentro de tolerancia validada |
| Beatgrid | Canciones con tempo constante y variable | Confianza visible y edición posible |
| IA | Recomendación y ejecución supervisada | Respeta límites y permite detener |
| Evento | Crear etapas y asignar listas | Guardado/restauración correctos |
| Backup | Exportar, borrar datos de prueba y restaurar | Cues, playlists y modelo restaurados |
| Estabilidad | Sesión prolongada de 2 horas | Sin crash, underrun sostenido ni sobrecalentamiento anormal |

No marcar una prueba como aprobada sin ejecutarla en dispositivo real o CI correspondiente.
