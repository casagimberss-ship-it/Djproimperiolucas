# QA v1.14 — lista de pruebas

## Regresión de base
- [ ] Instalar actualización sin desinstalar la versión anterior.
- [ ] Verificar biblioteca y acceso a almacenamiento/USB.
- [ ] Abrir y reproducir pistas en ambos reproductores existentes.
- [ ] Verificar BPM, tonalidad, forma de onda y marcadores.
- [ ] Guardar/recuperar Cue y preferencias.
- [ ] Grabar sesión y reproducir el archivo resultante.
- [ ] Confirmar persistencia del aprendizaje local.

## Loop Roll / Slicer
- [ ] Cuantización en 1/4, 1/2, 1, 2, 4 y 8 beats.
- [ ] Soltar roll vuelve a posición esperada.
- [ ] Cambiar de pista/pausar/buffer no deja loop colgado.
- [ ] Medir drift, latencia y consumo.

## Detección vocal
- [ ] Probar canciones vocales, instrumentales y mezclas densas.
- [ ] Verificar marcas temporales y confianza.
- [ ] Confirmar que análisis no bloquea reproducción/UI.
- [ ] Verificar fallback cuando el modelo no está disponible.

## Transiciones
- [ ] Comparar ranking con BPM/tonalidad/energía diferentes.
- [ ] Mostrar explicación y confianza.
- [ ] No ejecutar cambios sin autorización.
- [ ] Botón Stop y retorno al modo manual.

## Luces
- [ ] Simulador sin hardware.
- [ ] Beat/downbeat/energía generan eventos coherentes.
- [ ] Blackout inmediato y límites de intensidad.
- [ ] Hardware real solo con adaptador/protocolo identificados.
