# MODO FIESTA v1.17 — Plan técnico

## Objetivo y alcance seleccionado
Desarrollar el sampler profesional 100 % offline conservando Dark Profesional, el mezclador de dos decks, Smart DJ, biblioteca, grabación y sampler v1.16.1.

Selección confirmada: **2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 17, 18 y 20**.

- (2) Edición de punto inicial/final de cada sample.
- (3) Forma de onda individual por pad.
- (5) Sincronización con BPM medido del deck activo.
- (6) Disparo cuantizado: beat, 1 compás y 2 compases.
- (7) Adaptación automática de tempo del sample.
- (8) Alineación con el primer tiempo del compás.
- (9) Reverb por pad.
- (10) Echo y Delay por pad.
- (11) Filter y Flanger por pad.
- (12) Cadenas de efectos combinados.
- (17) Limitador de protección de picos.
- (18) Preescucha de sample.
- (20) Guardado/recuperación de bancos.

## Arquitectura propuesta

1. **Sampler UI**: panel por pad con waveform, marcadores IN/OUT, selector de cuantización, FX, preview y selector de banco. Mantener la jerarquía y paleta Dark Profesional existente.
2. **SamplerRepository**: SAF URI y permisos persistentes; banco activo y bancos guardados en SharedPreferences namespace `modo_fiesta_sampler_banks_v117`. No renombrar ni borrar claves v1.16.
3. **Waveform pipeline**: decodificar audio local a PCM mono de baja resolución en segundo plano; generar min/max peaks con `SamplerWaveformAnalyzer`; cachear por URI + tamaño/fecha. No cargar PCM completo en memoria para pistas largas.
4. **Cue/trim**: IN/OUT en milisegundos o frames PCM; validar `0 <= IN < OUT <= duration`; preview reproduce solo el rango seleccionado.
5. **Beat clock**: consumir BPM, beat phase y downbeat del analizador/deck principal. La cuantización no debe basarse en el reloj de UI. El audio engine programa la ejecución en su hilo/callback de audio.
6. **Tempo matching**: ratio deckBpm/sampleBpm. Para preservar tono se requiere time-stretch real; sin ese DSP, el fallback cambia velocidad y tono conjuntamente y debe indicarse en UI.
7. **FX graph**: cadena por pad REVERB → ECHO/DELAY → FILTER/FLANGER según orden elegido. Procesamiento en PCM/audio callback, parámetros suavizados para evitar clicks. No aplicar efectos en hilo UI.
8. **Limiter**: limitador look-ahead o equivalente con ataque/liberación medidos, techo configurable y medición de true peak. La función Kotlin entregada es solo política de ganancia, no DSP en tiempo real.
9. **Preview/Cue**: ruta de monitor separada del master cuando el dispositivo/Android lo permita. Android no garantiza salida física independiente en todos los teléfonos; ofrecer fallback de preescucha por salida principal con volumen de preview.
10. **Offline**: sin APIs, streaming, cuentas ni descargas. Todo análisis, FX, bancos y reproducción se realizan localmente.

## Dependencias / compatibilidad
- Mantener `applicationId` y `namespace`: `com.imperio.djpromix`.
- Mantener Kotlin/Java 17, compileSdk 35, minSdk 26, Media3 1.5.1 y dependencias actuales.
- No modificar SharedPreferences existentes de decks, biblioteca, Smart DJ, grabación o sampler v1.16.
- Nuevos datos aislados en `modo_fiesta_sampler_banks_v117`.
- No subir `versionCode`/`versionName` hasta integrar y compilar el producto completo.

## Fases de implementación

### Fase 1 — Datos y waveform
Persistencia de bancos, URI SAF, lectura metadata/duración, generación y cache de waveform, selección IN/OUT. Pruebas con MP3/WAV/M4A.

### Fase 2 — Beat clock
Exponer BPM/beat phase/downbeat del deck al sampler; scheduler de cuantización y disparo en el reloj de audio; compensación de latencia del dispositivo.

### Fase 3 — Tempo y transporte
Tempo match; loop estable; comportamiento al cambiar BPM, pausar, buscar o cambiar deck activo. Definir fallback si el formato no admite time-stretch.

### Fase 4 — FX y limitador
Motor DSP por pad, cadenas reordenables, automatización/smoothing, limitador de bus de sampler y protección de clipping. Medir latencia y consumo.

### Fase 5 — Preview, UI e integración
Preescucha, controles por pad, bancos, restauración tras reinicio y diseño Dark Profesional. Conectar a Activity/servicio sin bloquear UI.

### Fase 6 — QA y release
Pruebas funcionales, simultaneidad de cuatro pads, memoria, batería, latencia, permisos SAF y regresión de todas las funciones previas. Solo después actualizar versión y generar APK.

## Criterios de aceptación
- Cuatro pads continúan funcionando y los bancos no borran la configuración v1.16.
- Trim IN/OUT y waveform representan la misma región audible.
- Cuantización se alinea al beat/downbeat real; error medido objetivo menor a 30 ms en dispositivo de referencia.
- Tempo matching no produce saltos al actualizar BPM.
- FX/limiter no provocan clipping audible ni bloquean la interfaz.
- Preview y master respetan sus ganancias y rutas disponibles.
- Todo funciona en modo avión y sin permisos de red.
- No se rompe reproducción principal, crossfade, grabación ni Smart DJ.

## Estado de entrega
Este paquete aporta documentación y módulos Kotlin iniciales de cálculo/modelado. **No equivale a la integración completa**: waveform aún requiere decodificador PCM/UI; beat clock necesita conexión con deck; FX y limiter requieren motor DSP real; preview requiere ruta de monitor. No se afirma compilación ni APK generado.
