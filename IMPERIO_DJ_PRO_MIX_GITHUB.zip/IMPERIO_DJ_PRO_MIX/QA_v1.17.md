# QA v1.17 — Matriz de pruebas

| Área | Prueba | Resultado esperado |
|---|---|---|
| Bancos | Guardar/cargar banco con 0–4 muestras | Recupera nombre y URIs válidas |
| Migración | Instalar sobre v1.16.1 | Mantiene los cuatro pads existentes |
| SAF | Reiniciar app y reabrir URI | Permiso persistente o aviso recuperable |
| Waveform | MP3/WAV/M4A, mono/estéreo | Peaks normalizados y duración coherente |
| Trim | IN/OUT límites y duración cero | Rechaza rangos inválidos |
| BPM | 40–240 BPM y BPM inválido | Rechaza valores fuera de rango |
| Quantize | OFF/beat/1 bar/2 bars | Disparo en el siguiente límite correcto |
| Downbeat | Cambio de deck y reentrada | Fase se reinicia correctamente |
| Tempo | BPM cambia durante sample | Sin salto de reproducción no controlado |
| FX | Reverb/Echo/Delay/Filter/Flanger | Sin clicks ni saturación; CPU estable |
| Cadenas | 1–5 efectos | Orden respetado y parámetros suavizados |
| Limiter | Picos por encima del techo | Salida limitada sin clipping sostenido |
| Preview | Auriculares/salida no separada | Ruta independiente o fallback claro |
| Regresión | Mezcla, crossfade, Smart DJ, grabación | Comportamiento previo sin cambios |
| Offline | Modo avión | Todas las funciones locales disponibles |

Pruebas instrumentales pendientes en dispositivo Android real. La validación del ZIP no sustituye compilación ni pruebas de audio.
