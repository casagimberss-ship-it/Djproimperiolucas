# Compatibilidad y migración v1.14

- Se conserva `applicationId = com.imperio.djpromix`.
- Se conserva `namespace = com.imperio.djpromix`.
- No se modifica el esquema de datos existente en este paquete.
- Los módulos nuevos no escriben preferencias ni migran datos todavía.
- Las opciones nuevas deben tener valores predeterminados desactivados hasta completar pruebas.
- Para una actualización real, instalar sobre copia de prueba de la versión anterior y verificar biblioteca, Cue, historial, grabaciones y pesos de IA.
- No usar `clear()` sobre SharedPreferences ni borrar carpetas de usuario durante migraciones.
