# Changelog de desarrollo v1.14

- Selección confirmada: Loop Roll/Slicer, detección de voces, transiciones predictivas y luces sincronizadas.
- Añadidos contratos y prototipos Kotlin independientes para esos cuatro módulos.
- Añadida documentación de arquitectura, compatibilidad, migración y QA.
- Se conserva el proyecto base v1.11.0 y su identidad de paquete.
- No se declara integración de UI, DSP/PCM, modelo vocal ni salida DMX física.
