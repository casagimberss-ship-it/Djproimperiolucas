# MODO FIESTA v1.18 — Plan técnico

## Objetivo
Ampliar la planificación de mezclas automáticas y asistidas manteniendo operación completamente local, diseño Dark Profesional, compatibilidad con instalaciones previas y funciones de las versiones anteriores.

## Selección aprobada
7 Beatmatch automático; 8 Harmonic Mix; 9 Phrase Mix; 10 Intro Mix; 11 Outro Mix; 14 Bass Swap; 15 Vocal Mix; 17 Drop Mix; 18 Loop Transition; 19 Fiesta explosiva; 20 Fiesta progresiva; 22 Pista llena; 23 Sin repetición; 24 Cambios de ritmo; 27 Mix por energía; 28 Cierre de fiesta; 29 Selector de transición; 30 Control de duración; 33 Corrección de volumen; 35 Detección de silencio; 36 Mezcla manual asistida; 37 Vista previa.

## Arquitectura propuesta
- **Análisis local:** BPM/beatgrid, tonalidad Camelot, estructura de frases, intro/outro, intervalos vocales/instrumentales, drops, energía, loudness y silencios. Cada detección debe llevar confianza y permitir estado desconocido.
- **Selector:** genera candidatos de transición, aplica límites de tempo y puntúa compatibilidad armónica, de frase y vocal. El usuario puede aceptar, editar o cancelar.
- **Motor de reproducción:** dos decks ExoPlayer existentes; la integración futura debe programar seeks, velocidad, volumen y crossfade con reloj monotónico y callbacks reales.
- **Seguridad:** compensación de ganancia limitada, techo de pico, no amplificar detecciones inciertas, no saltar silencios dentro de voz/música útil.
- **Modo fiesta:** ranking local por energía/puntuación de baile, control de repetición por historial persistente, progresión de energía, puentes rítmicos y cierre.
- **Vista previa:** deck/canal independiente o salida de preescucha elegida por el usuario; no asumir que el dispositivo Android ofrece salida cue separada.
- **Final de set:** al llegar a cero se bloquean nuevas cargas automáticas y se espera el evento real de fin del tema actual. Luego se detienen ambos decks, se cierra/flush la grabación, se guardan estadísticas y se muestra SET FINALIZADO. Si no llega el callback de fin, ofrecer un timeout recuperable y botón de detener; no truncar silenciosamente.

## Parámetros iniciales configurables
- Cambio máximo de tempo sugerido: ±8% (editable).
- Transición inicial: 16 beats (4–64 beats).
- Compensación de loudness: objetivo inicial -14 LUFS, boost máximo +6 dB y corte máximo -9 dB; valores conservadores y ajustables.
- Detector de silencio: umbral temporal inicial 1,8 s; debe considerar voz, transitorios y confianza.
- Ventana sin repetición: 12 pistas por defecto, configurable.

## Fases de integración
1. Verificar extracción de BPM/tonalidad/estructura sobre archivos reales y corpus de prueba local.
2. Conectar análisis al catálogo de pistas y persistir resultados/versionado del analizador.
3. Integrar selector con ambos ExoPlayer y un scheduler de transición; validar drift y callbacks.
4. Añadir ganancia/crossfade con medición de picos y pruebas auditivas; el plan actual no implementa DSP.
5. Añadir historial/energía y modos de fiesta a la cola de reproducción.
6. Conectar preescucha a ruta de audio soportada y documentar limitaciones de hardware.
7. Integrar la máquina de estados de cierre con el servicio de reproducción y SessionRecorder.
8. UI Dark Profesional, controles manuales, accesibilidad y QA offline.

## Restricciones
Sin nube, APIs remotas, streaming de análisis, telemetría ni descarga de modelos. Modelos acústicos nuevos, si se incorporan, deben empaquetarse localmente y contar con licencia/huella verificada. No modificar applicationId, namespace, SharedPreferences existentes ni datos del usuario. No incrementar versión Android hasta integrar y compilar el conjunto.
