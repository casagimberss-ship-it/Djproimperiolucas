# Arquitectura v1.16
## Audio graph conceptual
Deck A + Deck B + Sampler voices (4) -> channel gain/FX -> master limiter/headroom -> output.
Grabación toma el bus master pre/post limiter según decisión de producto documentada.

## Persistencia nueva
- `modo_fiesta_sampler_v116`: bancos, URIs SAF, último banco, modo, volumen, quantize y syncBpm.
- `modo_fiesta_session_v116`: duración objetivo y preferencias de cierre.
No renombrar preferencias existentes.

## Background
El temporizador de sesión se aloja en servicio de reproducción/foreground service existente o en un componente coordinado con él. No depender de temporizadores visuales para contar tiempo real.

## Riesgos
- ExoPlayer estándar no ofrece una cadena DSP multicanal universal para todos los efectos; puede requerirse AudioProcessor personalizado o motor de audio dedicado.
- Cuatro pads simultáneos, timestretch, FX y grabación pueden elevar CPU/batería.
- URIs SAF requieren persistable URI permissions; una URI guardada no garantiza que el archivo siga existiendo.
