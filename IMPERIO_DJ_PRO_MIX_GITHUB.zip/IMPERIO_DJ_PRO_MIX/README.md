# IMPERIO DJ PRO MIX

Proyecto Android nativo Kotlin para teléfonos y tablets. Es una reconstrucción independiente inspirada en los elementos observados en el APK y el video DJLabPro suministrados; no incluye código, marca ni recursos extraídos del producto original.

## Qué incluye esta primera entrega funcional

- Dos decks de audio independientes mediante AndroidX Media3 / ExoPlayer.
- Selector de archivos de audio del dispositivo (SAF).
- Play/Pause y Stop por deck.
- Seek bar y tiempo de reproducción.
- Crossfader A/B y volumen Master.
- Pitch básico por cambio de velocidad de reproducción.
- CUE y ocho Hot Cues por deck.
- Pantalla Modo Fiesta inicial.
- Interfaz oscura adaptable al ancho disponible de móviles y tablets.
- Compilación APK debug mediante GitHub Actions.

## Limitaciones conocidas de esta entrega

Esta es la base funcional inicial, no una réplica terminada de todas las funciones que aparecen nombradas o sugeridas por el APK original. No están implementados todavía: detección real de BPM/beatgrid, sincronización de beats, Key Lock independiente, EQ DSP real de tres bandas, stems, MIDI mapping, grabador de mezcla, sampler con archivos de efectos, automix inteligente, waveform decodificada y servicio persistente de reproducción. Los controles visuales marcados como prueba o pendientes no deben considerarse funciones terminadas.

La función Loop de esta entrega es una demostración temporal y debe sustituirse por un loop de límites exactos antes de una versión de producción.

## Requisitos

- Android Studio reciente o GitHub Actions.
- JDK 17.
- Android SDK Platform 35.
- Gradle 8.9 o compatible con Android Gradle Plugin 8.7.3.
- Conexión a Internet durante la primera compilación para descargar dependencias.

## Compilar en GitHub manualmente

1. Crea un repositorio nuevo en GitHub, por ejemplo `IMPERIO-DJ-PRO-MIX`.
2. Descomprime este ZIP.
3. Sube **el contenido** de la carpeta al nivel raíz del repositorio (debe quedar `settings.gradle.kts` en la raíz).
4. En GitHub abre **Actions**.
5. Selecciona **Build Android APK** y pulsa **Run workflow**. También se ejecuta al subir cambios a `main` o `master`.
6. Al finalizar, abre la ejecución y descarga el artefacto `imperio-dj-pro-mix-debug`.
7. Descomprime el artefacto e instala el APK debug en Android.

## Compilación local

```bash
gradle assembleDebug
```

Salida:
`app/build/outputs/apk/debug/app-debug.apk`

## Paquete

`com.imperio.djpromix`

## Próximas etapas recomendadas

1. Verificar mezcla simultánea en dispositivos reales y latencia.
2. Implementar EQ DSP, limitador y control de ganancia sin clipping.
3. Añadir waveform y análisis BPM.
4. Construir beatmatch/sync, loops cuantizados y pitch bend.
5. Añadir MIDI, sampler, grabación y automix.
6. Implementar servicio multimedia persistente y controles de notificación.
7. Pruebas de compatibilidad en distintos teléfonos y tablets.
