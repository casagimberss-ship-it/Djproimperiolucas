# IMPERIO DJ PRO MIX — Stage 4

Android app focused on Party Mode (no visible DJ decks).

## Stage 4: audio analysis
- Decodes supported local audio using Android MediaExtractor/MediaCodec.
- Estimates BPM from an onset-strength envelope and autocorrelation.
- Estimates musical key from spectral chroma and maps it to Camelot notation.
- Processes the imported library in a background worker and persists results.
- Keeps manual BPM/key editing available as a correction tool.
- Automatic selection and assisted next-track selection remain available.

## Important limitations
- Analysis uses an excerpt of up to 75 seconds; estimates can be uncertain for ambient, sparse, live, or rhythmically complex recordings.
- BPM/key detection is an estimate, not guaranteed ground truth. Check and correct results when needed.
- Smart phrase transition is still approximate; this stage does not yet perform beat-grid phase alignment, time-stretch, or professional beatmatching.
- Analysis requires the app to remain open while it runs. Background playback service is a separate future stage.

## Build
Open this project with Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17, compileSdk 35. Or use the repository GitHub Actions workflow.
