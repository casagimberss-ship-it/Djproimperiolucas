# IMPERIO DJ PRO MIX — Party Mode

Aplicación Android nativa enfocada exclusivamente en reproducción automática tipo fiesta. No incluye decks visibles ni controles tradicionales de DJ.

## Funciones
- Importar recursivamente archivos de audio desde una carpeta y sus subcarpetas usando el selector de documentos de Android.
- Biblioteca de música y reproducción de una pista seleccionada.
- Reproducción continua y selección de siguiente pista.
- Selección inteligente heurística por BPM y tonalidad Camelot cuando esos datos fueron introducidos por el usuario.
- Dos reproductores internos ocultos para realizar crossfade automático configurable (8, 12 o sin transición).
- Controles de reproducir/pausar, anterior, siguiente, volumen y modo aleatorio inteligente.

## Limitaciones actuales
- BPM y tonalidad no se detectan automáticamente todavía: se pueden cargar manualmente desde el botón ♫ de cada canción. La selección armónica sólo puede ser fiable cuando esos datos están disponibles.
- No incluye aún análisis de beats, key detection, time-stretch sincronizado ni persistencia de la biblioteca después de cerrar la app.
- El crossfade cambia el volumen entre dos reproductores; no alinea beats ni garantiza una mezcla musicalmente sincronizada.

## Compilar
Proyecto Android Gradle Kotlin DSL. Requiere JDK 17, Android SDK 35 y Gradle 8.9.

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.
