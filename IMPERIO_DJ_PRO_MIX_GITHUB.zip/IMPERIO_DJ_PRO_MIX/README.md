# IMPERIO DJ PRO MIX — v1.10.0

Android nativo · Kotlin · Media3 ExoPlayer · Android API 26+.

## Cambios de esta versión
- **Análisis de pista completa:** el decodificador ya no se detiene a los 75 segundos. BPM y estructura recorren el PCM completo; la tonalidad toma hasta 300 ventanas distribuidas a lo largo de toda la canción.
- **Forma de onda completa:** los 240 picos representan la pista decodificada completa, no solo su introducción.
- **Grabación MP3 320 kbps:** salida estéreo a 48 kHz mediante LAME. La captura es Audio Playback Capture de Android (audio multimedia interno permitido por el sistema), no una grabación acústica del micrófono. Requiere Android 10+, permiso RECORD_AUDIO y consentimiento MediaProjection; algunas fuentes pueden bloquear la captura.
- **Red neuronal local:** MLP pequeño ejecutado en el dispositivo, sin servicio remoto ni conexión para inferencia. Comienza con un modelo sin preferencias entrenadas; cuando el DJ elige manualmente una próxima pista distinta de la sugerencia, registra esa preferencia frente a la sugerencia y guarda los pesos localmente. A partir de tres comparaciones empieza a influir en la clasificación.
- Versión Android: `1.10.0`, `versionCode 11`.

## Compilar en GitHub Actions
1. Sube el contenido de esta carpeta a la raíz de un repositorio GitHub.
2. Abre **Actions** y ejecuta **Build Android APK**, o haz un push a `main`/`master`.
3. Al terminar, descarga el artefacto `imperio-dj-pro-mix-debug`.

Requisitos: JDK 17, Android Gradle Plugin 8.7.3 y Gradle 8.9. Este proyecto no incluye Gradle Wrapper; el workflow instala/configura Gradle 8.9.

## Pruebas recomendadas
1. Analizar canciones de 3, 5 y 10 minutos y comprobar que la forma de onda cubre el tema entero.
2. Comparar BPM y tonalidad con una referencia fiable; son estimaciones musicales, no valores garantizados.
3. Elegir manualmente una próxima canción diferente de la sugerencia; comprobar que el contador de preferencias aprendidas aumenta. Cerrar y abrir la app para verificar persistencia.
4. Grabar una sesión de prueba y comprobar duración, estéreo y bitrate reportado por un analizador MP3. Android puede impedir capturar audio de ciertas aplicaciones o dispositivos.
5. Probar en Android 10+ y en los dispositivos de destino.

## Limitaciones y licencias
- El modelo neuronal es pequeño y aprende preferencias de forma incremental; no es un modelo preentrenado ni un sistema de reconocimiento de géneros. La calidad mejora con más elecciones explícitas.
- La captura del sistema depende de las políticas de captura de Android y de cada fuente de audio. No equivale a tomar el PCM del mezclador interno de ExoPlayer.
- TAndroidLame se distribuye bajo GPL-3.0; revisar obligaciones de licencia antes de distribuir comercialmente.
- La compilación y ejecución en hardware deben considerarse pendientes hasta que GitHub Actions y las pruebas en dispositivos finalicen correctamente.
