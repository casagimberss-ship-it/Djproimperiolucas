# IMPERIO DJ PRO MIX — Stage 11: AI Assisted + Real Waveform + MP3 (v1.9.0)

Android nativo · Kotlin · Media3 ExoPlayer · Android API 26+.

## Decisiones de esta etapa
- Modo de trabajo: DJ asistido. El motor recomienda/prepara la siguiente pista y el usuario conserva la selección manual.
- Prioridad de desarrollo: selección musical inteligente en el motor AI DJ.
- Visualización: forma de onda calculada a partir de muestras PCM decodificadas; deja de ser un patrón decorativo.
- Grabación: MP3 estéreo a 48 kHz / 192 kbps mediante LAME.

## Cambios de Stage 11
- El analizador genera 240 picos normalizados del fragmento PCM inicial (hasta 75 segundos).
- La forma de onda se guarda en la caché lateral `imperio_dj_analysis_cache.json` y en la biblioteca privada.
- El panel NOW PLAYING dibuja los picos de audio reales y un cursor de reproducción.
- El botón de grabación crea un archivo `.mp3` con MIME `audio/mpeg`.
- La grabación captura audio multimedia de la aplicación mediante Audio Playback Capture y codifica PCM estéreo con LAME a 192 kbps.
- Se conserva la selección AI y el control manual de próxima pista.
- Versión Android: `1.9.0`, `versionCode 10`.

## Límites conocidos
- La forma de onda corresponde al fragmento analizado, limitado a los primeros 75 segundos; no representa todavía la canción completa.
- El cursor se limita a la duración cubierta por ese fragmento.
- El motor AI DJ sigue siendo un sistema local basado en reglas y metadatos (BPM, Camelot, energía, historial y marcadores), no un modelo neuronal ni una clasificación automática fiable de géneros.
- El BPM, tonalidad, intro y entrada siguen siendo estimaciones y deben validarse con música real.
- La grabación requiere Android 10+, permiso de micrófono/audio y autorización MediaProjection del sistema. Solo puede capturar audio de reproducción que Android permita capturar.
- El encoder TAndroidLame utilizado se distribuye bajo GPL-3.0. Revisar las obligaciones de licencia antes de distribuir una versión cerrada/comercial.
- La dependencia nativa debe probarse en los ABI y dispositivos de destino, especialmente en Android recientes con requisito de alineación de páginas de 16 KB.

## Compilar

El proyecto utiliza JDK 17, Android Gradle Plugin 8.7.3 y Gradle Kotlin DSL. El workflow de GitHub Actions ejecuta `gradle assembleDebug`.

Este ZIP no incluye Gradle Wrapper. Ejecutar el workflow en GitHub Actions o compilar con una instalación local compatible. La compilación y la ejecución en hardware deben considerarse pendientes hasta obtener un resultado exitoso.

## Pruebas manuales obligatorias
1. Importar una carpeta con MP3, WAV, FLAC y M4A.
2. Ejecutar ANALIZAR y comprobar que aparece una forma de onda distinta para cada pista.
3. Cerrar y abrir la app y verificar que la forma de onda se recupera de la caché.
4. Reproducir, pausar, saltar y probar selección manual de próxima pista.
5. Grabar 1 minuto y comprobar el archivo `.mp3` en otro reproductor, incluidos inicio, final y canales estéreo.
6. Probar con Android 10, Android 13/14 y Android 15/16 si están disponibles.
