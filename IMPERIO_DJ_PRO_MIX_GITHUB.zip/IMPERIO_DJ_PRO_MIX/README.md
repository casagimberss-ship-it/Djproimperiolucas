# IMPERIO DJ PRO MIX — Stage 7: IMPERIO AI DJ ENGINE

Android app nativa, Modo Fiesta sin decks visibles. Versión 1.5.0.

## Novedades de Stage 7
- Motor local de decisión musical híbrida (`AiDjEngine`).
- Cuatro perfiles: Progresiva, Energía constante, Éxitos y Armónica.
- Ranking de próxima pista por proximidad de BPM (incluye relación half/double-time), compatibilidad Camelot y energía.
- Penalización de pistas reproducidas recientemente para reducir repeticiones.
- Recomendación explicada en pantalla; el usuario conserva el control y puede fijar otra canción.
- Campo opcional de energía musical 1–5 editable por pista.
- Persistencia de energía junto a BPM y tonalidad.

## Alcance honesto
Este motor es una inteligencia musical heurística, determinista y ejecutada en el dispositivo. No es un modelo neuronal entrenado ni un servicio de IA en la nube. La calidad de la recomendación depende de la disponibilidad y precisión de BPM, Camelot y energía. La energía se carga manualmente; no se afirma que esté detectada automáticamente. La detección de secciones, downbeats, separación vocal y análisis de contenido musical avanzado quedan para etapas posteriores.

La sincronización de BPM existente aplica un ajuste limitado y no equivale a beatmatching profesional ni garantiza alineación de fase. No se garantiza compilación hasta que GitHub Actions termine correctamente.

## Compilar
Subir el contenido del ZIP al repositorio siguiendo el flujo de GitHub Actions existente y ejecutar el workflow Android.
