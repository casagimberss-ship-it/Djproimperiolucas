# IMPERIO DJ PRO MIX — Stage 10: Futuristic Red Interface

Android nativo · Modo Fiesta sin decks · Versión 1.6.0.

## Novedades
- Análisis local del fragmento inicial de audio: BPM y tonalidad Camelot (etapa previa), más envolvente RMS por ventanas.
- Estimación de silencio/intro inicial y punto de entrada sugerido dentro del fragmento analizado.
- Curva de energía aproximada de ocho segmentos, guardada por pista.
- Indicador experimental de regularidad rítmica; no equivale a una detección de beat-grid o downbeat fiable.
- El motor híbrido incorpora una preferencia leve por pistas con marcadores y pulso analizados.
- Durante el crossfade, si existe punto de entrada sugerido, el reproductor entrante busca ese punto; si no, comienza desde cero.
- Los nuevos datos se guardan en la biblioteca y las bibliotecas de etapas anteriores siguen siendo compatibles.

## Límites importantes
El análisis decodifica hasta 75 segundos desde el comienzo del archivo. Por eso no estima el outro real de la canción ni conoce su estructura completa. Intro, entrada, curva y regularidad son aproximaciones basadas en RMS, no detección semántica de estrofas/estribillos, downbeats o separación vocal. La entrada automática puede omitir parte del comienzo; se recomienda probar con música real y corregir manualmente si hace falta. No es un modelo neuronal ni utiliza Internet.

El ajuste de tempo y crossfade existente no garantiza beatmatching profesional ni alineación de fase. No se ha validado todavía en un dispositivo Android ni se afirma que compile hasta que GitHub Actions termine correctamente.

## Compilar
Reemplazar el contenido del proyecto en el repositorio por el contenido de este ZIP y ejecutar el workflow Android de GitHub Actions. Si falla, compartir el log completo de la tarea que marque error.


## Stage 9 — Grabación y caché persistente (v1.7.0)

- Botón para grabar la salida multimedia de IMPERIO DJ PRO MIX y guardar una sesión en WAV estéreo PCM 48 kHz.
- Android solicita permiso de audio y autorización del sistema para capturar reproducción. La grabación captura el audio multimedia de la app, no micrófono ni sonidos de otras aplicaciones.
- La captura corre en un servicio en primer plano con notificación persistente y control para detener la grabación, compatible con las restricciones modernas de Android.
- WAV es un formato sin compresión y puede ocupar bastante espacio (aprox. 11 MB por minuto). Mantener IMPERIO abierto durante la captura.
- Al importar una carpeta, la app lee `imperio_dj_analysis_cache.json` dentro de esa carpeta.
- El archivo lateral guarda BPM, Camelot, energía, intro, entrada, curva de energía y confianza rítmica, junto con tamaño y fecha de modificación para invalidar análisis de pistas modificadas.
- Las pistas nuevas o modificadas se analizan; las que mantienen su huella reutilizan el análisis anterior. La biblioteca privada de la app continúa guardando una copia.

### Limitaciones de la grabación

La captura de audio interno requiere Android 10 o superior y que el dispositivo permita Audio Playback Capture. Android muestra un permiso de captura del sistema. Algunos fabricantes, políticas de audio o configuraciones del dispositivo pueden impedir capturar la reproducción. La grabación se finaliza y se copia al archivo WAV al pulsar detener.


## Stage 10 — Interfaz FUTURISTIC RED (v1.8.0)

- Rediseño compacto para Android: panel oscuro tecnológico, acentos rojo neón y jerarquía visual más clara.
- Panel principal de reproducción con canción actual, BPM, tonalidad, progreso y visual gráfico decorativo.
- Controles de transporte grandes y acceso rápido a importar, analizar y grabar sesión.
- Paneles compactos para crossfade, volumen, perfil del AI DJ y próxima selección.
- Biblioteca y cola siguen utilizando los datos, el análisis persistente y el motor de audio de etapas anteriores.
- Se actualizó el tema Android para usar la paleta roja.

Esta etapa es un rediseño visual de la Activity existente; no agrega decks ni reemplaza el motor de reproducción. La forma de onda dibujada es decorativa y no representa una señal de audio en tiempo real. No se ejecutó una compilación Gradle en este entorno: verificar el APK mediante GitHub Actions y probar reproducción, grabación e importación en el dispositivo.
