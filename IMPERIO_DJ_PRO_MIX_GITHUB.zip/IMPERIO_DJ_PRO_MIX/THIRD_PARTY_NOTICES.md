# Third-party notices

## TAndroidLame / LAME MP3 encoder

The MP3 session recorder integrates `com.github.kaushik-naik:TAndroidLame:a485052f28`, an Android wrapper around the LAME MP3 encoder.

- Upstream project: https://github.com/kaushik-naik/TAndroidLame
- License reported by the upstream package: GNU General Public License v3.0 (GPL-3.0)
- The encoder is fetched from JitPack during Gradle dependency resolution; its source and license are not vendored in this ZIP.

Before distributing IMPERIO DJ PRO MIX, review GPL-3.0 compatibility and provide the required license/source notices. Validate native library page alignment and ABI support on target Android versions.
