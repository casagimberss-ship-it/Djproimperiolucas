# v1.15 Smart Genre Mix
- Plan de análisis offline de géneros y subgéneros bailables.
- Diseño multi-playlist y deduplicación.
- Motores auxiliares de energía, Camelot, frases y tandas.
- Especificación de crossfader, automatización DJ, protección vocal y aprendizaje local.
- QA offline y compatibilidad hacia atrás.
