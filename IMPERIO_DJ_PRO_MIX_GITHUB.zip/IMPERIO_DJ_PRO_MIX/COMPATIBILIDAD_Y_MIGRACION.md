# Compatibilidad y migración

- Mantener `applicationId = com.imperio.djpromix`.
- Mantener namespace y paquetes Kotlin actuales.
- Mantener las claves actuales de preferencias y los nombres/formatos existentes de biblioteca.
- Añadir nuevos campos con valores por defecto; no renombrar ni eliminar campos heredados.
- Versionar los nuevos documentos de eventos y backup (`schemaVersion`).
- Importar backups primero en carpeta temporal; validar manifest y SHA-256; luego confirmar reemplazo.
- Si falla la importación, conservar intactos los datos previos.
- Hacer backup automático antes de migraciones destructivas.
- No incluir credenciales, permisos ni tokens en el backup.
