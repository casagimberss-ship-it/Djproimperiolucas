# MODO FIESTA v1.14 — Interfaz Dark Profesional

## Decisión visual
Diseño 3: Dark Profesional, sin mezcla de otros estilos.

- Fondo grafito casi negro (#090B0F).
- Paneles carbón (#15191F) y superficies secundarias (#1C222A).
- Acento ámbar (#FFA62B) para acciones y estados destacados.
- Azul hielo (#69C9E8) para información técnica de audio.
- Bordes acero discretos (#343D48), botones sólidos y esquinas moderadas.
- Marca MODO FIESTA y crédito “Creada por DJ Lucas Quintana”.

## Alcance aplicado
Se actualizó la capa visual de `MainActivity.kt`: paleta, tarjetas, botones, estado, biblioteca y textos de cabecera. Se conservan las acciones y sus callbacks existentes: importar carpeta, analizar biblioteca, grabar/detener MP3, reproducción, anterior/siguiente, selección manual, AI DJ, shuffle, crossfade, volumen, edición de BPM/tonalidad/energía y cola.

## Compatibilidad
No se modificaron `applicationId`, namespace, claves de SharedPreferences, formato de caché, motor ExoPlayer ni servicios. No se cambia el versionCode/versionName en este paquete.

## Verificación
Este paquete contiene el código fuente actualizado. La integridad del ZIP se verifica al generarlo; la compilación Android debe ejecutarse en Android Studio o GitHub Actions con SDK instalado.
