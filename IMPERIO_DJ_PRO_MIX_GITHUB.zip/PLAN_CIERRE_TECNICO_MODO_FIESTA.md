# MODO FIESTA — Plan de cierre técnico

## Objetivo
Preparar una versión candidata verificable sin sacrificar reproducción estable, datos existentes ni operación offline.

## Bloque 1 — Motor de audio en tiempo real
- Conectar procesadores PCM al pipeline de salida de ambos decks.
- Reverb, Echo, Delay, Filter y Flanger con controles wet/dry, feedback y límites anti-clipping.
- Brake y Backspin como automatizaciones temporales de transporte/velocidad, con cancelación segura y restauración de estado.
- Bass Swap con cruce de bandas y limitación de ganancia para evitar picos.
- Criterio: cada efecto debe alterar audio real, ser automatizable y no dejar el deck en estado alterado tras cancelar la transición.

## Bloque 2 — Protección vocal
- Incorporar un detector vocal offline real, con modelo/runtime y licencia incluidos en el paquete.
- Analizar ventanas PCM fuera del hilo de audio; publicar probabilidades y confianza con marcas de tiempo.
- VocalOverlapGuard solo debe actuar con inferencia validada; ante baja confianza debe volver al crossfade seguro.
- Criterio: falsos positivos/negativos medidos sobre un conjunto de pistas de prueba; no anunciar aislamiento vocal si solo se atenúa el solapamiento.

## Bloque 3 — Beatgrid y frases
- Detectar BPM, fase del primer beat, rejilla y confianza; corregir fase usando audio decodificado, no solo posición temporal modulo.
- Estimar frases y entradas/salidas con intervalos de confianza.
- Ajustar tempo con pitch preservation si la calidad y latencia del motor lo permiten; mantener límites conservadores.
- Criterio: validar deriva de beat y error de fase contra referencias etiquetadas a varios BPM.

## Bloque 4 — Loop y sampler
- Loop Transition con captura/lectura de región, cuantización real al beatgrid, crossfade de loop y liberación sincronizada.
- Sampler: recorte in/out, waveform, preescucha, one-shot/loop, cuantización, sincronía BPM, pitch seguro, volumen y FX.
- Criterio: no clicks audibles, límites de región válidos, loop estable y persistencia de los cuatro pads después de cerrar/reabrir la app.

## Bloque 5 — Estilos y reglas
- Conectar cada perfil de GenreCatalog/MixModeCatalog a una política de ranking efectiva.
- Reglas explícitas para energía progresiva/explosiva/cierre, no repetición, artista repetido, cambio rítmico con puente, compatibilidad armónica y protección vocal.
- “Pista llena” no se debe inferir sin sensor/entrada real; usar nombre honesto como objetivo de energía/baile estimado.
- Criterio: pruebas unitarias de ranking deterministas con historial, empates y biblioteca pequeña.

## Bloque 6 — QA de lanzamiento
- Build debug y release en CI; lint, pruebas unitarias e instrumentadas.
- Reproducción: pausa/reanudar, cambio de pista, crossfade, pérdida de foco, pantalla apagada, auriculares/Bluetooth y reconexión.
- Grabación: duración, MP3 reproducible, archivo completo al finalizar, interrupción, espacio insuficiente y cierre inesperado.
- Temporizador: detener al final de pista, corte inmediato y finalización correcta de grabación.
- Audio: clipping, latencia, CPU, memoria, temperatura y coexistencia de FX en Android API 26–35.
- Persistencia: biblioteca, CUE, historial, preferencias, bancos sampler y permisos SAF.
- Offline: prueba en modo avión; confirmar ausencia de INTERNET en Manifest y que no haya dependencias runtime remotas.

## v1.19.0 — Cierre DSP incorporado

El Bloque 1 ya fue conectado al código: cada deck utiliza un `DjAudioFxProcessor` propio mediante `DefaultAudioSink`. Filter, Delay, Echo, Reverb, Flanger, Bass Swap, Brake y Backspin ahora tienen rutas de audio reales. La automatización de transición modifica estos procesadores y se restaura al finalizar.

La protección vocal no se declara terminada porque el plan exige un modelo/runtime offline validado y medición de falsos positivos/negativos.

## Estado y límites
La base v1.18.2 ya contiene selector inteligente, dos decks, crossfade, cuatro reproductores sampler y grabación/temporizador según el código existente. Los efectos listados, Bass Swap, detección vocal validada, beatgrid profesional y Loop Transition DSP no están certificados como funcionales. No se debe publicar como final hasta completar los criterios anteriores y probar en dispositivos reales.
