package com.imperio.djpromix

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.core.view.setPadding
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val tracks = mutableListOf<Track>()
    private lateinit var root: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var nowMeta: TextView
    private lateinit var status: TextView
    private lateinit var progress: SeekBar
    private lateinit var waveformView: WaveformView
    private lateinit var playButton: Button
    private lateinit var queueBox: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var analysisRunning = false
    private var players = arrayOfNulls<ExoPlayer>(2)
    // Sampler local: cuatro reproductores independientes, sin depender de Internet.
    private lateinit var samplerPlayers: Array<ExoPlayer>
    private val samplerUris = arrayOfNulls<Uri>(4)
    private val samplerNames = Array(4) { "Sin sample" }
    private val samplerLoop = BooleanArray(4)
    private val samplerVolumes = FloatArray(4) { 0.85f }
    private var pendingSamplerIndex = -1
    private lateinit var samplerBox: LinearLayout
    private fun samplerPrefs() = getSharedPreferences("imperio_sampler", MODE_PRIVATE)

    private fun queryDisplayName(uri: Uri): String? {
        return contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }

    private fun restoreSampler() {
        val prefs = samplerPrefs()
        for (i in 0..3) {
            val uriString = prefs.getString("uri_$i", null)
            samplerUris[i] = uriString?.let { runCatching { Uri.parse(it) }.getOrNull() }
            samplerNames[i] = prefs.getString("name_$i", null)
                ?: samplerUris[i]?.let { queryDisplayName(it) }
                ?: "Sin sample"
            samplerLoop[i] = prefs.getBoolean("loop_$i", false)
            samplerVolumes[i] = prefs.getFloat("volume_$i", 0.85f).coerceIn(0f, 1f)
            samplerPlayers[i].repeatMode = if (samplerLoop[i]) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            samplerPlayers[i].volume = samplerVolumes[i] * masterVolume
            samplerUris[i]?.let { uri ->
                runCatching {
                    samplerPlayers[i].setMediaItem(MediaItem.fromUri(uri))
                    samplerPlayers[i].prepare()
                }
            }
        }
    }

    private val samplerPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val index = pendingSamplerIndex
        if (uri != null && index in 0..3) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            samplerUris[index] = uri
            samplerNames[index] = queryDisplayName(uri) ?: "Sample ${index + 1}"
            samplerPrefs().edit().putString("uri_$index", uri.toString()).putString("name_$index", samplerNames[index]).apply()
            samplerPlayers[index].stop(); samplerPlayers[index].clearMediaItems()
            renderSampler()
            status.text = "Sample ${index + 1} cargado: ${samplerNames[index]}"
        }
        pendingSamplerIndex = -1
    }
    private var playbackService: PartyPlaybackService? = null
    private var serviceBound = false
    private val playbackConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val service = (binder as? PartyPlaybackService.LocalBinder)?.getService() ?: return
            playbackService = service
            players = service.players
            attachPlayerListeners()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            playbackService = null
            players = arrayOfNulls(2)
        }
    }
    private var active = 0
    private var currentIndex = -1
    private var nextIndex = -1
    private var userSelectedNext = false
    private var aiSuggestedNextIndex = -1
    private lateinit var neuralDjModel: LocalNeuralDjModel
    private val smartTransitionEngine = SmartTransitionEngine()
    private enum class OperationMode { AUTOMATIC, ASSISTED }
    private var operationMode = OperationMode.AUTOMATIC
    private var partyOn = false
    private var crossfading = false
    private var masterVolume = 0.85f
    private var shuffle = true
    private var fadeSeconds = 8
    private var aiStyle = AiDjEngine.Style.PROGRESSIVE
    private val recentHistory = ArrayDeque<Int>()
    private var lastAiReason = "La IA elegirá según BPM, tonalidad y energía"
    private var libraryFolderUri: Uri? = null
    private var recordingActive = false
    private var setDeadlineWallMs = 0L
    private var setStartedWallMs = 0L
    private var waitingForSongEnd = false
    private var setFinalizing = false
    private var projectionResultCode = 0
    private var projectionResultData: Intent? = null
    private val recordingFinishedReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            recordingActive = false
            val success = intent?.getBooleanExtra(SessionRecordingService.EXTRA_SUCCESS, false) == true
            val error = intent?.getStringExtra(SessionRecordingService.EXTRA_ERROR).orEmpty()
            if (::status.isInitialized) status.text = if (success) "Sesión grabada y guardada correctamente" else "Error al grabar: $error"
            renderRecordingControls()
        }
    }
    private val audioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) requestProjectionPermission() else Toast.makeText(this, "Se necesita el permiso de audio para grabar la salida de IMPERIO", Toast.LENGTH_LONG).show()
    }
    private val projectionPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            projectionResultCode = result.resultCode
            projectionResultData = result.data
            createRecordingFile.launch("MODO_FIESTA_SESION_${System.currentTimeMillis()}.mp3")
        } else Toast.makeText(this, "Permiso de captura cancelado", Toast.LENGTH_SHORT).show()
    }
    private val createRecordingFile = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")) { uri ->
        val data = projectionResultData
        if (uri != null && data != null) {
            val serviceIntent = Intent(this, SessionRecordingService::class.java).apply {
                action = SessionRecordingService.ACTION_START
                putExtra(SessionRecordingService.EXTRA_RESULT_CODE, projectionResultCode)
                putExtra(SessionRecordingService.EXTRA_DATA, data)
                setData(uri)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            recordingActive = true
            status.text = "Iniciando grabación de sesión…"
            renderRecordingControls()
        } else { status.text = "Grabación cancelada"; renderRecordingControls() }
        projectionResultData = null
    }
    private val tick = object : Runnable {
        override fun run() {
            val p = players[active]
            if (p != null && p.duration > 0) {
                progress.max = p.duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                progress.progress = p.currentPosition.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                if (::waveformView.isInitialized) waveformView.setPlayhead(p.currentPosition.toFloat() / p.duration.coerceAtLeast(1L).toFloat())
                if (partyOn && setDeadlineWallMs > 0L && System.currentTimeMillis() >= setDeadlineWallMs) {
                    waitingForSongEnd = true
                    if (::status.isInitialized) status.text = "TIEMPO CUMPLIDO · esperando que termine la canción actual"
                }
                if (operationMode == OperationMode.AUTOMATIC && partyOn && !waitingForSongEnd && !crossfading && nextIndex >= 0 && shouldStartSmartTransition(p)) beginCrossfade()
            }
            handler.postDelayed(this, 400)
        }
    }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let { importFolder(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        neuralDjModel = LocalNeuralDjModel(this)
        operationMode = runCatching {
            OperationMode.valueOf(getSharedPreferences("modo_fiesta_operation", MODE_PRIVATE)
                .getString("mode", OperationMode.AUTOMATIC.name) ?: OperationMode.AUTOMATIC.name)
        }.getOrDefault(OperationMode.AUTOMATIC)
        samplerPlayers = Array(4) { index ->
            ExoPlayer.Builder(this).build().apply {
                addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { if (::samplerBox.isInitialized) renderSampler() }
                    override fun onPlaybackStateChanged(playbackState: Int) { if (::samplerBox.isInitialized) renderSampler() }
                })
            }
        }
        restoreSampler()
        window.statusBarColor = BG
        window.navigationBarColor = BG
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        restoreLibrary()
        recordingActive = getSharedPreferences("imperio_party", MODE_PRIVATE).getBoolean("recordingActive", false)
        setDeadlineWallMs = getSharedPreferences("imperio_party", MODE_PRIVATE).getLong("setDeadlineWallMs", 0L)
        waitingForSongEnd = setDeadlineWallMs > 0L && System.currentTimeMillis() >= setDeadlineWallMs
        androidx.core.content.ContextCompat.registerReceiver(this, recordingFinishedReceiver, android.content.IntentFilter(SessionRecordingService.ACTION_FINISHED), androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED)
        bindService(Intent(this, PartyPlaybackService::class.java), playbackConnection, BIND_AUTO_CREATE)
        serviceBound = true
        render()
        handler.post(tick)
    }

    private fun attachPlayerListeners() {
        players.forEachIndexed { i, p -> p?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && i == active && partyOn && !crossfading) {
                    if (waitingForSongEnd || (setDeadlineWallMs > 0L && System.currentTimeMillis() >= setDeadlineWallMs)) finishTimedSet()
                    else startNextImmediately()
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { updatePlayButton() }
        }) }
    }

    private fun rerenderPreservingStatus() {
        val message = if (::status.isInitialized) status.text?.toString().orEmpty() else "SISTEMA LISTO"
        render()
        status.text = message
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(18))
        }
        scroll.addView(root)

        // FUTURISTIC / RED compact dashboard
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("MODO FIESTA", 23, WHITE, true).apply { setPadding(0, 0, 0, 0); letterSpacing = 0.06f })
        brand.addView(label("Creada por DJ Lucas Quintana", 10, ACCENT, true).apply { setPadding(0, dp(2), 0, 0) })
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("● LIVE", 10, ACCENT, true).apply {
            background = rounded(PANEL, 12); setPadding(dp(10), dp(6), dp(10), dp(6))
        })
        root.addView(header)
        root.addView(label("PRO DJ SYSTEM   ·   SMART MIX   ·   CONTROL TOTAL", 9, MUTED, true).apply { letterSpacing = 0.10f })
        root.addView(space(8))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14))
            background = rounded(PANEL, 18)
        }
        val heroTop = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        heroTop.addView(label("NOW PLAYING", 10, ACCENT, true), LinearLayout.LayoutParams(0, -2, 1f))
        heroTop.addView(label("PARTY MODE", 9, MUTED, true))
        hero.addView(heroTop)
        nowTitle = label("Cargá tu música para comenzar", 19, WHITE, true).apply { maxLines = 2; setPadding(dp(2), dp(8), dp(2), dp(2)) }
        hero.addView(nowTitle)
        nowMeta = label("BPM --   ·   KEY --   ·   --:--", 10, MUTED)
        hero.addView(nowMeta)
        waveformView = WaveformView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(78))
            setWaveform(tracks.getOrNull(currentIndex)?.waveform)
            setStructureMarkers(tracks.getOrNull(currentIndex)?.structureMarkers)
        }
        hero.addView(waveformView)
        hero.addView(label("FORMA DE ONDA · PINZÁ PARA ZOOM · ARRASTRÁ PARA BUSCAR", 8, MUTED).apply { gravity = Gravity.CENTER; letterSpacing = 0.03f })
        progress = SeekBar(this).apply { max = 1000; progress = 0; isEnabled = false }
        hero.addView(progress)
        root.addView(hero)
        root.addView(space(9))

        val transport = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        transport.addView(action("⏮") { previousTrack() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        playButton = action("▶  INICIAR FIESTA") { toggleParty() }.apply {
            backgroundTintList = android.content.res.ColorStateList.valueOf(ACCENT)
            setTextColor(Color.WHITE); textSize = 12f
        }
        val playParams = LinearLayout.LayoutParams(0, dp(52), 2.4f).apply { setMargins(dp(5), 0, dp(5), 0) }
        transport.addView(playButton, playParams)
        transport.addView(action("⏭") { skipTrack() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(transport)
        root.addView(space(9))

        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quick.addView(action("＋  IMPORTAR MÚSICA") { folderPicker.launch(null) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        quick.addView(action("⌁  ANALIZAR") { analyzeLibrary() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(quick)
        root.addView(space(6))

        val recordButton = action(if (recordingActive) "■  DETENER GRABACIÓN" else "●  GRABAR SESIÓN MP3") { toggleSessionRecording() }.apply {
            setTextColor(if (recordingActive) Color.WHITE else ACCENT)
            if (recordingActive) backgroundTintList = android.content.res.ColorStateList.valueOf(ACCENT)
        }
        root.addView(recordButton, LinearLayout.LayoutParams(-1, dp(44)))
        root.addView(action(if (setDeadlineWallMs > 0L) "⏱  PROGRAMACIÓN ACTIVA · ${remainingSetTime()}" else "⏱  PROGRAMAR DURACIÓN DEL SET") { showSetDurationDialog() }, LinearLayout.LayoutParams(-1, dp(44)))
        root.addView(label("MP3 estéreo · 320 kbps · audio interno · Android 10 o superior.", 9, MUTED))
        root.addView(space(7))

        val settingsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12)); background = rounded(PANEL, 16)
        }
        settingsCard.addView(label("CONTROL DE MEZCLA", 10, ACCENT, true))
        val options = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        options.addView(action(if (shuffle) "AI SHUFFLE  ON" else "AI SHUFFLE  OFF") { shuffle = !shuffle; render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
        options.addView(action("CROSSFADE  ${fadeSeconds}s") { fadeSeconds = if (fadeSeconds == 8) 12 else if (fadeSeconds == 12) 0 else 8; render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
        settingsCard.addView(options)
        settingsCard.addView(label("MASTER VOLUME", 9, MUTED, true))
        settingsCard.addView(SeekBar(this).apply { max = 100; progress = (masterVolume * 100).roundToInt(); setOnSeekBarChangeListener(listener { masterVolume = it / 100f; players.forEach { p -> p?.volume = masterVolume }; if (::samplerPlayers.isInitialized) samplerPlayers.forEachIndexed { i, p -> p.volume = samplerVolumes[i] * masterVolume } }) })
        root.addView(settingsCard)
        root.addView(space(8))

        // SAMPLER visible en pantalla principal, entre mezcla y Smart DJ.
        samplerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12)); background = rounded(PANEL, 16) }
        root.addView(samplerBox)
        renderSampler()
        root.addView(space(8))

        val aiCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12)); background = rounded(PANEL, 16) }
        aiCard.addView(label("MODO FIESTA AI  /  SMART DJ", 10, ACCENT, true).apply { letterSpacing = 0.06f })
        aiCard.addView(label("MODO DE OPERACIÓN", 9, MUTED, true))
        val operationChoices = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        operationChoices.addView(action(if (operationMode == OperationMode.AUTOMATIC) "✓ AUTOMÁTICO" else "AUTOMÁTICO") {
            setOperationMode(OperationMode.AUTOMATIC)
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        operationChoices.addView(action(if (operationMode == OperationMode.ASSISTED) "✓ ASISTIDO" else "ASISTIDO") {
            setOperationMode(OperationMode.ASSISTED)
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        aiCard.addView(operationChoices)
        aiCard.addView(action("PROFILE  ${aiStyle.label.uppercase(Locale.US)}   ↻") {
            aiStyle = AiDjEngine.Style.values()[(aiStyle.ordinal + 1) % AiDjEngine.Style.values().size]
            if (currentIndex in tracks.indices) { nextIndex = chooseNext(currentIndex); userSelectedNext = false }
            render()
        })
        aiCard.addView(label("NEXT PICK", 9, MUTED, true))
        val upcoming = tracks.getOrNull(nextIndex)
        aiCard.addView(label(upcoming?.let { "${it.title}  ·  ${it.bpm?.let { b -> "$b BPM" } ?: "BPM --"}  ·  ${if (userSelectedNext) "ELEGIDA POR DJ" else "RECOMENDADA POR IA"}" } ?: "La IA preparará la próxima pista al iniciar", 11, WHITE, true))
        aiCard.addView(label(lastAiReason, 9, MUTED))
        val recommendation = currentTransitionRecommendation()
        if (recommendation != null) {
            aiCard.addView(label("TÉCNICA RECOMENDADA", 9, ACCENT, true))
            aiCard.addView(label(recommendation.label, 12, WHITE, true))
            aiCard.addView(label(recommendation.explanation, 9, MUTED))
            aiCard.addView(label(recommendation.reasons.joinToString("  ·  "), 8, MUTED))
        } else {
            aiCard.addView(label("La técnica se calculará cuando haya una pista actual y otra preparada.", 9, MUTED))
        }
        if (operationMode == OperationMode.ASSISTED) {
            aiCard.addView(action("✓  ACEPTAR Y EJECUTAR TRANSICIÓN COMPLETA") {
                acceptAssistedTransition()
            }.apply {
                backgroundTintList = android.content.res.ColorStateList.valueOf(ACCENT)
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(-1, dp(48)))
            aiCard.addView(label("Al aceptar, MODO FIESTA inicia y completa automáticamente el crossfade. No requiere controlar los decks.", 9, MUTED))
        } else {
            aiCard.addView(label("La IA selecciona y ejecuta las transiciones automáticamente.", 9, MUTED))
        }
        root.addView(aiCard)
        root.addView(space(8))

        status = label("SISTEMA LISTO  ·  importá una carpeta para comenzar", 10, ACCENT, true).apply {
            background = rounded(PANEL_ALT, 10); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        root.addView(status)
        root.addView(space(8))
        root.addView(label("BIBLIOTECA MUSICAL  /  ${tracks.size} PISTAS", 13, WHITE, true).apply { letterSpacing = 0.04f })
        root.addView(label("BPM · KEY · ENERGY · INTRO · ENTRY POINT", 9, MUTED))
        queueBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(queueBox)
        renderQueue()
        setContentView(scroll)
        updatePlayButton()
    }

    private fun renderSampler() {
        if (!::samplerBox.isInitialized || !::samplerPlayers.isInitialized) return
        samplerBox.removeAllViews()
        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heading.addView(label("SAMPLER  ·  4 PADS", 11, ACCENT, true), LinearLayout.LayoutParams(0, -2, 1f))
        heading.addView(action("DETENER TODO") { samplerPlayers.forEach { it.pause(); it.seekTo(0) } })
        samplerBox.addView(heading)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (rowIndex in 0..1) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (col in 0..1) {
                val i = rowIndex * 2 + col
                val cell = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(dp(7)); background = rounded(BUTTON, 12)
                }
                cell.addView(label("PAD ${i + 1}", 10, GOLD, true))
                cell.addView(label(samplerNames[i], 9, WHITE, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
                cell.addView(action(if (samplerPlayers[i].isPlaying) "Ⅱ  PAUSAR" else "▶  DISPARAR") { playSampler(i) }, LinearLayout.LayoutParams(-1, dp(38)))
                val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                controls.addView(action("CARGAR") { pendingSamplerIndex = i; samplerPicker.launch(arrayOf("audio/*")) }, LinearLayout.LayoutParams(0, dp(34), 1f))
                controls.addView(action(if (samplerLoop[i]) "LOOP" else "ONE SHOT") { samplerLoop[i] = !samplerLoop[i]; samplerPrefs().edit().putBoolean("loop_$i", samplerLoop[i]).apply(); samplerPlayers[i].repeatMode = if (samplerLoop[i]) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF; renderSampler() }, LinearLayout.LayoutParams(0, dp(34), 1f))
                cell.addView(controls)
                cell.addView(SeekBar(this).apply {
                    max = 100; progress = (samplerVolumes[i] * 100).roundToInt()
                    setOnSeekBarChangeListener(listener { value -> samplerVolumes[i] = value / 100f; samplerPrefs().edit().putFloat("volume_$i", samplerVolumes[i]).apply(); samplerPlayers[i].volume = samplerVolumes[i] * masterVolume })
                })
                val params = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
                row.addView(cell, params)
            }
            grid.addView(row)
        }
        samplerBox.addView(grid)
        samplerBox.addView(label("CARGÁ UN AUDIO · ONE SHOT / LOOP · VOLUMEN INDEPENDIENTE", 8, MUTED))
    }

    private fun playSampler(index: Int) {
        if (index !in 0..3) return
        val uri = samplerUris[index]
        if (uri == null) {
            pendingSamplerIndex = index
            samplerPicker.launch(arrayOf("audio/*"))
            return
        }
        val player = samplerPlayers[index]
        try {
            if (player.isPlaying) {
                player.pause()
            } else {
                player.repeatMode = if (samplerLoop[index]) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                if (player.mediaItemCount == 0 || player.playbackState == Player.STATE_ENDED) {
                    player.setMediaItem(MediaItem.fromUri(uri)); player.prepare()
                }
                player.volume = samplerVolumes[index] * masterVolume
                player.play()
            }
            renderSampler()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo reproducir el sample: ${e.message ?: "archivo no disponible"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderQueue() {
        queueBox.removeAllViews()
        if (tracks.isEmpty()) { queueBox.addView(label("Todavía no hay canciones importadas.", 12, MUTED)); return }
        tracks.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(5)); background = rounded(if (i % 2 == 0) PANEL else BG, 10) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label("${i + 1}. ${t.title}", 12, if (i == currentIndex) GOLD else WHITE, true))
            info.addView(label("${t.bpm?.let { "$it BPM" } ?: "BPM --"}  ·  ${t.key ?: "Tonalidad --"}  ·  ${t.energy?.let { "ENERGÍA $it/5" } ?: "ENERGÍA --"}", 10, MUTED))
            info.addView(label("${t.introSeconds?.let { "INTRO aprox. ${it}s" } ?: "INTRO --"}  ·  ${t.entrySeconds?.let { "ENTRADA sugerida ${it}s" } ?: "ENTRADA --"}  ·  ${t.beatConfidence?.let { "RITMO ${(it * 100).roundToInt()}%" } ?: "RITMO --"}", 9, CYAN))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(action("▶") { playTrack(i) })
            row.addView(action(if (i == nextIndex) "✓" else "SIG.") { setNextTrack(i) })
            row.addView(action("♫") { editAnalysis(t) })
            queueBox.addView(row)
        }
    }

    private fun importFolder(uri: android.net.Uri) {
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val folder = DocumentFile.fromTreeUri(this, uri) ?: return
        libraryFolderUri = uri
        val found = mutableListOf<Track>()
        fun scan(dir: DocumentFile) { dir.listFiles().forEach { f ->
            if (f.isDirectory) scan(f)
            else if (f.isFile && (f.type?.startsWith("audio/") == true || f.name.orEmpty().matches(Regex("(?i).+\\.(mp3|wav|flac|m4a|aac|ogg|opus|wma)$")))) {
                if (found.none { it.uri == f.uri }) found.add(Track(f.uri, f.name ?: "Audio"))
            }
        } }
        scan(folder)
        val sorted = found.sortedBy { it.title.lowercase(Locale.getDefault()) }
        loadFolderCache(folder, sorted.toMutableList())
        tracks.clear(); tracks.addAll(sorted)
        currentIndex = -1; nextIndex = -1; userSelectedNext = false
        persistLibrary()
        status.text = "Importadas ${tracks.size} canciones · ${tracks.count { it.cacheValid }} análisis reutilizados"
        render()
    }

    private fun analyzeLibrary() {
        if (analysisRunning) { Toast.makeText(this, "El análisis ya está en curso", Toast.LENGTH_SHORT).show(); return }
        if (tracks.isEmpty()) { Toast.makeText(this, "Primero importá una carpeta", Toast.LENGTH_SHORT).show(); return }
        tracks.forEach { track ->
            // Older 1.8.0 cache entries have no PCM waveform; force one refresh for the new visualizer.
            if (track.waveform.isNullOrBlank() || track.structureMarkers.isNullOrBlank()) track.cacheValid = false
            if (track.cacheValid && track.fileSize >= 0L && track.fileModified >= 0L) {
                val file = DocumentFile.fromSingleUri(this, track.uri)
                if (file == null || !file.exists() || file.length() != track.fileSize || file.lastModified() != track.fileModified) {
                    track.cacheValid = false
                    track.bpm = null; track.key = null
                    track.introSeconds = null; track.entrySeconds = null
                    track.energyCurve = null; track.beatConfidence = null; track.waveform = null; track.structureMarkers = null
                }
            }
        }
        val pending = tracks.filter { !it.cacheValid }
        if (pending.isEmpty()) {
            status.text = "Biblioteca analizada · podés corregir datos manualmente"
            if (!partyOn) showAnalysisCompletedDialog(tracks.size, tracks.size)
            return
        }
        analysisRunning = true
        status.text = "Analizando audio real: 0/${pending.size} · no cierres la aplicación"
        analysisExecutor.execute {
            var completed = 0
            for (track in pending) {
                try {
                    val result = AudioAnalyzer.analyze(this, track.uri)
                    if (track.bpm == null) track.bpm = result.bpm
                    if (track.key == null) track.key = result.camelot
                    track.introSeconds = result.introSeconds
                    track.entrySeconds = result.entrySeconds
                    track.energyCurve = result.energyCurve
                    track.beatConfidence = result.beatConfidence
                    track.waveform = result.waveform
                    track.structureMarkers = result.structureMarkers
                    track.cacheValid = true
                } catch (_: Exception) { /* archivo no compatible o sin permiso: continuar */ }
                completed++
                val count = completed
                handler.post {
                    if (!isFinishing && ::status.isInitialized) status.text = "Analizando audio real: $count/${pending.size}"
                }
            }
            handler.post {
                analysisRunning = false
                persistFolderCache()
                persistLibrary()
                if (!isFinishing) {
                    status.text = "Análisis finalizado · $completed pistas procesadas · datos guardados"
                    if (!partyOn && completed > 0) {
                        showAnalysisCompletedDialog(completed, pending.size)
                    }
                    updateNowPlayingIfReady()
                    renderQueue()
                    if (currentIndex >= 0) { nextIndex = chooseNext(currentIndex); updateNowPlayingIfReady() }
                }
            }
        }
    }

    private fun showAnalysisCompletedDialog(completed: Int, total: Int) {
        if (isFinishing || isDestroyed) return
        val message = if (completed == total) {
            "Se analizaron $completed pistas correctamente.\n\nLa biblioteca está preparada para iniciar la sesión."
        } else {
            "El análisis terminó. Se procesaron $completed de $total pistas.\n\nLas pistas analizadas quedaron guardadas y listas para la sesión."
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("ANÁLISIS COMPLETADO")
            .setMessage(message)
            .setPositiveButton("INICIAR SESIÓN") { _, _ ->
                if (tracks.isNotEmpty()) toggleParty()
            }
            .setNegativeButton("MÁS TARDE", null)
            .show()
    }

    private fun updateNowPlayingIfReady() {
        if (currentIndex in tracks.indices) updateNowPlaying()
    }

    private fun editAnalysis(track: Track) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16)) }
        val bpm = EditText(this).apply { hint = "BPM (ej. 124)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(track.bpm?.toString() ?: "") }
        val key = EditText(this).apply { hint = "Camelot (ej. 8A o 9B)"; setText(track.key ?: "") }
        val energy = EditText(this).apply { hint = "Energía 1 a 5 (opcional)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(track.energy?.toString() ?: "") }
        box.addView(bpm); box.addView(key); box.addView(energy)
        android.app.AlertDialog.Builder(this).setTitle(track.title).setMessage("Corregí BPM y tonalidad Camelot para mejorar la selección y sincronización de mezclas.").setView(box)
            .setPositiveButton("GUARDAR") { _, _ -> track.bpm = bpm.text.toString().toIntOrNull()?.takeIf { it in 50..220 }; track.key = key.text.toString().trim().uppercase(Locale.US).takeIf { it.matches(Regex("(1[0-2]|[1-9])[AB]")) }; track.energy = energy.text.toString().toIntOrNull()?.takeIf { it in 1..5 }; persistFolderCache(); persistLibrary(); renderQueue(); status.text = "Datos musicales guardados" }
            .setNegativeButton("CANCELAR", null).show()
    }

    private fun showSetDurationDialog() {
        val choices = arrayOf("30 minutos", "1 hora", "2 horas", "3 horas", "Duración personalizada", "Desactivar programación")
        android.app.AlertDialog.Builder(this).setTitle("DURACIÓN DEL SET")
            .setItems(choices) { _, which ->
                if (which == 4) { showCustomSetDurationDialog(); return@setItems }
                val minutes = when (which) { 0 -> 30; 1 -> 60; 2 -> 120; 3 -> 180; else -> 0 }
                setStartedWallMs = System.currentTimeMillis()
                setDeadlineWallMs = if (minutes == 0) 0L else System.currentTimeMillis() + minutes * 60_000L
                waitingForSongEnd = false
                getSharedPreferences("imperio_party", MODE_PRIVATE).edit().putLong("setDeadlineWallMs", setDeadlineWallMs).apply()
                status.text = if (minutes == 0) "Programación de set desactivada" else "Set programado · ${choices[which]} · al finalizar espera el final de la canción"
                render()
            }.show()
    }

    private fun showCustomSetDurationDialog() {
        val field = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; hint = "Minutos (1–720)" }
        android.app.AlertDialog.Builder(this).setTitle("DURACIÓN PERSONALIZADA").setView(field)
            .setPositiveButton("PROGRAMAR") { _, _ ->
                val minutes = field.text.toString().toIntOrNull()?.coerceIn(1, 720)
                if (minutes == null) Toast.makeText(this, "Ingresá entre 1 y 720 minutos", Toast.LENGTH_LONG).show()
                else {
                    setStartedWallMs = System.currentTimeMillis()
                    setDeadlineWallMs = setStartedWallMs + minutes * 60_000L
                    waitingForSongEnd = false
                    getSharedPreferences("imperio_party", MODE_PRIVATE).edit().putLong("setDeadlineWallMs", setDeadlineWallMs).apply()
                    status.text = "Set programado · $minutes minutos · espera final de canción"
                    render()
                }
            }.setNegativeButton("CANCELAR", null).show()
    }

    private fun remainingSetTime(): String {
        val ms = (setDeadlineWallMs - System.currentTimeMillis()).coerceAtLeast(0L)
        return String.format(Locale.US, "%02d:%02d", ms / 3_600_000L, (ms / 60_000L) % 60L)
    }

    private fun finishTimedSet() {
        if (setFinalizing) return
        setFinalizing = true
        partyOn = false
        waitingForSongEnd = false
        setDeadlineWallMs = 0L
        getSharedPreferences("imperio_party", MODE_PRIVATE).edit().putLong("setDeadlineWallMs", 0L).putLong("lastSetFinishedAt", System.currentTimeMillis()).putLong("lastSetDurationMs", if (setStartedWallMs > 0L) System.currentTimeMillis() - setStartedWallMs else 0L).apply()
        players.forEach { it?.run { pause(); stop(); clearMediaItems() } }
        playbackService?.setPartyActive(false)
        if (recordingActive) {
            startService(Intent(this, SessionRecordingService::class.java).setAction(SessionRecordingService.ACTION_STOP))
            status.text = "SET FINALIZADO · cerrando y guardando grabación MP3…"
        } else status.text = "SET FINALIZADO · reproducción detenida · estadísticas guardadas"
        updatePlayButton()
        android.app.AlertDialog.Builder(this).setTitle("SET FINALIZADO")
            .setMessage(if (recordingActive) "Terminó la última canción. Se está cerrando correctamente la grabación." else "Terminó la última canción. La reproducción se detuvo y se guardó el cierre de sesión.")
            .setPositiveButton("ACEPTAR", null).show()
        setFinalizing = false
    }

    private fun toggleParty() {
        if (tracks.isEmpty()) { Toast.makeText(this, "Primero importá una carpeta de música", Toast.LENGTH_SHORT).show(); return }
        if (partyOn) { partyOn = false; players.forEach { it?.pause() }; playbackService?.setPartyActive(false); status.text = "Fiesta pausada" }
        else if (currentIndex >= 0) { partyOn = true; ContextCompat.startForegroundService(this, Intent(this, PartyPlaybackService::class.java)); playbackService?.startParty(); players[active]?.play(); playbackService?.setPartyActive(true); status.text = "Modo Fiesta activo" }
        else { partyOn = true; ContextCompat.startForegroundService(this, Intent(this, PartyPlaybackService::class.java)); playbackService?.startParty(); playTrack(selectFirst()) }
        updatePlayButton()
    }

    private fun selectFirst(): Int = if (nextIndex in tracks.indices) nextIndex else if (shuffle) tracks.indices.random() else 0
    private fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        if (players[active] == null) { Toast.makeText(this, "Preparando motor de audio… intentá nuevamente en un segundo", Toast.LENGTH_SHORT).show(); return }
        partyOn = true; ContextCompat.startForegroundService(this, Intent(this, PartyPlaybackService::class.java)); playbackService?.startParty(); playbackService?.setPartyActive(true); crossfading = false; currentIndex = index; recentHistory.addLast(index); while (recentHistory.size > 5) recentHistory.removeFirst(); nextIndex = chooseNext(index); userSelectedNext = false
        val p = players[active] ?: return
        p.stop(); p.clearMediaItems(); p.setMediaItem(MediaItem.fromUri(tracks[index].uri)); p.volume = masterVolume; p.prepare(); p.play()
        players[1 - active]?.pause(); players[1 - active]?.clearMediaItems()
        updateNowPlaying(); render(); status.text = "Reproduciendo · ${tracks[index].title}"; updatePlayButton()
    }

    private fun setOperationMode(mode: OperationMode) {
        if (operationMode == mode) return
        operationMode = mode
        getSharedPreferences("modo_fiesta_operation", MODE_PRIVATE).edit()
            .putString("mode", mode.name).apply()
        status.text = if (mode == OperationMode.AUTOMATIC)
            "Modo Automático · la IA selecciona y ejecuta las transiciones"
        else "Modo Asistido · acepta la recomendación para ejecutar la transición completa"
        rerenderPreservingStatus()
    }

    private fun acceptAssistedTransition() {
        if (operationMode != OperationMode.ASSISTED) return
        if (currentIndex !in tracks.indices || nextIndex !in tracks.indices || nextIndex == currentIndex) {
            Toast.makeText(this, "No hay una próxima canción preparada", Toast.LENGTH_SHORT).show()
            return
        }
        val outgoing = players[active]
        if (outgoing == null || !outgoing.isPlaying) {
            Toast.makeText(this, "Iniciá la reproducción antes de aceptar la transición", Toast.LENGTH_LONG).show()
            return
        }
        if (crossfading) {
            Toast.makeText(this, "Ya hay una transición en ejecución", Toast.LENGTH_SHORT).show()
            return
        }
        beginCrossfade()
    }

    private fun transitionData(track: Track): SmartTransitionEngine.TrackData = SmartTransitionEngine.TrackData(
        bpm = track.bpm,
        camelot = track.key,
        energy = track.energy,
        introSeconds = track.introSeconds,
        entrySeconds = track.entrySeconds,
        beatConfidence = track.beatConfidence
    )

    private fun currentTransitionRecommendation(): SmartTransitionEngine.Recommendation? {
        val outgoing = tracks.getOrNull(currentIndex) ?: return null
        val incoming = tracks.getOrNull(nextIndex) ?: return null
        if (currentIndex == nextIndex) return null
        return smartTransitionEngine.recommend(transitionData(outgoing), transitionData(incoming))
    }

    private fun chooseNext(from: Int): Int {
        if (tracks.size <= 1) return from
        val options = tracks.indices.filter { it != from }
        if (!shuffle) {
            val sequential = (from + 1) % tracks.size
            aiSuggestedNextIndex = sequential
            lastAiReason = "Orden de biblioteca · ${tracks[sequential].title}"
            return sequential
        }
        val current = tracks[from]
        val currentCandidate = AiDjEngine.Candidate(from, current.bpm, current.key, current.energy, false, current.entrySeconds, current.beatConfidence)
        // La compatibilidad de transición pesa más que la preferencia general de playlist.
        // La IA local desempata por energía, historial y aprendizaje del usuario.
        val ranked = options.map { index ->
            val track = tracks[index]
            val recommendation = smartTransitionEngine.recommend(transitionData(current), transitionData(track))
            val candidate = AiDjEngine.Candidate(index, track.bpm, track.key, track.energy,
                recentHistory.contains(index), track.entrySeconds, track.beatConfidence)
            val aiDecision = neuralDjModel.choose(currentCandidate, listOf(candidate), aiStyle)
            val repeatPenalty = if (recentHistory.contains(index)) 1000.0 else 0.0
            val combined = smartTransitionEngine.rankScore(recommendation) * 100.0 -
                repeatPenalty - ((aiDecision?.score ?: 100) * 0.10)
            Triple(index, combined, recommendation)
        }.sortedByDescending { it.second }
        val best = ranked.firstOrNull() ?: return options.random()
        aiSuggestedNextIndex = best.first
        lastAiReason = "${tracks[best.first].title} · selector de transición ${best.third.label} · compatibilidad ${(best.third.score * 100).toInt()}%"
        return best.first
    }

    private fun compatibilityScore(a: Track, b: Track): Int {
        val tempo = if (a.bpm != null && b.bpm != null) {
            val direct = abs(a.bpm!! - b.bpm!!)
            val halfDouble = minOf(abs(a.bpm!! - b.bpm!! * 2), abs(a.bpm!! * 2 - b.bpm!!))
            minOf(direct, halfDouble) * 2
        } else 25
        val key = if (a.key != null && b.key != null) camelotDistance(a.key!!, b.key!!) * 15 else 25
        val speedPenalty = if (a.bpm != null && b.bpm != null) {
            val ratio = a.bpm!!.toFloat() / b.bpm!!.toFloat()
            if (ratio in 0.94f..1.06f) 0 else 18
        } else 0
        return tempo + key + speedPenalty
    }

    private fun camelotDistance(a: String, b: String): Int {
        val x = Regex("(1[0-2]|[1-9])([AB])").matchEntire(a) ?: return 6
        val y = Regex("(1[0-2]|[1-9])([AB])").matchEntire(b) ?: return 6
        val n = x.groupValues[1].toInt(); val m = y.groupValues[1].toInt()
        return minOf(abs(n - m), 12 - abs(n - m)) + if (x.groupValues[2] == y.groupValues[2]) 0 else 1
    }

    // Alineación aproximada a una frase de 4 compases usando el BPM conocido.
    // Si no hay BPM, se utiliza el crossfade estándar como alternativa segura.
    private fun shouldStartSmartTransition(player: ExoPlayer): Boolean {
        val remaining = player.duration - player.currentPosition
        val fadeWindow = if (fadeSeconds == 0) 0L else fadeSeconds * 1000L
        if (remaining > fadeWindow) return false
        if (waitingForSongEnd) return false
        if (fadeSeconds == 0) return true
        val recommendation = currentTransitionRecommendation()
        if (recommendation?.phraseAligned != true) return true
        val bpm = tracks.getOrNull(currentIndex)?.bpm ?: return true
        val fourBarsMs = (16.0 * 60000.0 / bpm.toDouble()).toLong().coerceAtLeast(1000L)
        val positionInPhrase = player.currentPosition % fourBarsMs
        val nearBoundary = positionInPhrase <= 450L || fourBarsMs - positionInPhrase <= 450L
        return nearBoundary || remaining <= 900L
    }

    private fun beginCrossfade() {
        val next = nextIndex
        if (next !in tracks.indices) { startNextImmediately(); return }
        val incomingIndex = 1 - active
        val incoming = players[incomingIndex] ?: return
        val outgoing = players[active] ?: return
        if (crossfading) return
        val outgoingTrack = tracks.getOrNull(currentIndex) ?: return
        val incomingTrack = tracks.getOrNull(next) ?: return
        val recommendation = smartTransitionEngine.recommend(transitionData(outgoingTrack), transitionData(incomingTrack))
        val outgoingBpm = outgoingTrack.bpm
        val incomingBpm = incomingTrack.bpm
        val speed = recommendation.tempoRatio
        val bpmDataReliable = outgoingBpm != null && incomingBpm != null &&
            (outgoingTrack.beatConfidence ?: 0f) >= 0.20f && (incomingTrack.beatConfidence ?: 0f) >= 0.20f
        crossfading = true
        incoming.stop(); incoming.clearMediaItems(); incoming.setMediaItem(MediaItem.fromUri(incomingTrack.uri))
        incoming.setPlaybackSpeed(speed)
        // The analyzer's entry marker is an estimate, but it is used consistently in both modes.
        if (recommendation.incomingStartMs > 0L) incoming.seekTo(recommendation.incomingStartMs)
        incoming.volume = 0f; incoming.prepare(); incoming.play()
        val duration = if (fadeSeconds == 0) 1 else fadeSeconds * 1000L
        val started = System.currentTimeMillis()
        val fade = object : Runnable {
            override fun run() {
                if (!partyOn) { incoming.pause(); crossfading = false; return }
                val fraction = ((System.currentTimeMillis() - started).toFloat() / duration).coerceIn(0f, 1f)
                outgoing.volume = masterVolume * (1f - fraction)
                incoming.volume = masterVolume * fraction
                if (fraction < 1f) handler.postDelayed(this, 80) else {
                    outgoing.pause(); outgoing.clearMediaItems();
                                active = incomingIndex; currentIndex = next; recentHistory.addLast(currentIndex); while (recentHistory.size > 5) recentHistory.removeFirst(); nextIndex = chooseNext(currentIndex); userSelectedNext = false; crossfading = false
                    updateNowPlaying(); renderQueue()
                    val syncText = when {
                        speed != 1f -> " · tempo ${(incomingBpm!! * speed).roundToInt()} BPM"
                        bpmDataReliable && recommendation.tempoCompatible -> " · BPM compatible"
                        bpmDataReliable -> " · diferencia BPM mayor al 6%, sin corrección"
                        else -> " · BPM sin confianza suficiente"
                    }
                    status.text = "${recommendation.label} · ${tracks[currentIndex].title}$syncText"
                    rerenderPreservingStatus()
                }
            }
        }
        handler.post(fade)
    }

    private fun setNextTrack(index: Int) {
        if (index !in tracks.indices || index == currentIndex) return
        val current = tracks.getOrNull(currentIndex)
        val chosen = tracks.getOrNull(index)
        val rejected = tracks.getOrNull(aiSuggestedNextIndex)
        if (current != null && chosen != null && rejected != null && chosen !== rejected) {
            fun candidate(i: Int, t: Track) = AiDjEngine.Candidate(i, t.bpm, t.key, t.energy, recentHistory.contains(i), t.entrySeconds, t.beatConfidence)
            neuralDjModel.learn(candidate(currentIndex, current), candidate(index, chosen), candidate(aiSuggestedNextIndex, rejected), aiStyle)
            status.text = "Preferencia aprendida localmente · ${neuralDjModel.learnedComparisons} ejemplos"
        }
        nextIndex = index
        userSelectedNext = true
        status.text = "Próxima canción elegida: ${tracks[index].title} · aceptá la transición para ejecutarla"
        rerenderPreservingStatus()
    }

    private fun loadFolderCache(folder: DocumentFile, imported: MutableList<Track>) {
        val cache = folder.findFile(CACHE_FILE) ?: return
        try {
            val raw = contentResolver.openInputStream(cache.uri)?.bufferedReader()?.use { it.readText() } ?: return
            val array = JSONArray(raw)
            val records = HashMap<String, JSONObject>()
            for (i in 0 until array.length()) { val item = array.getJSONObject(i); records[item.optString("uri")] = item }
            imported.forEach { track ->
                val file = DocumentFile.fromSingleUri(this, track.uri)
                val record = records[track.uri.toString()] ?: return@forEach
                val size = file?.length() ?: -1L
                val modified = file?.lastModified() ?: -1L
                if (record.optLong("size", -2L) == size && record.optLong("modified", -2L) == modified && size >= 0L && modified >= 0L) {
                    track.bpm = if (record.isNull("bpm")) null else record.optInt("bpm")
                    track.key = if (record.isNull("key")) null else record.optString("key")
                    track.energy = if (record.isNull("energy")) null else record.optInt("energy")
                    track.introSeconds = if (record.isNull("introSeconds")) null else record.optInt("introSeconds")
                    track.entrySeconds = if (record.isNull("entrySeconds")) null else record.optInt("entrySeconds")
                    track.energyCurve = if (record.isNull("energyCurve")) null else record.optString("energyCurve")
                    track.beatConfidence = if (record.isNull("beatConfidence")) null else record.optDouble("beatConfidence").toFloat()
                    track.waveform = if (record.isNull("waveform")) null else record.optString("waveform")
                    track.structureMarkers = if (record.isNull("structureMarkers")) null else record.optString("structureMarkers")
                    track.fileSize = size; track.fileModified = modified
                    track.cacheValid = !track.waveform.isNullOrBlank()
                }
            }
        } catch (_: Exception) { /* cache dañada: se vuelve a analizar */ }
    }

    private fun persistFolderCache() {
        val folderUri = libraryFolderUri ?: return
        try {
            val folder = DocumentFile.fromTreeUri(this, folderUri) ?: return
            val cache = folder.findFile(CACHE_FILE) ?: folder.createFile("application/json", CACHE_FILE) ?: return
            val array = JSONArray()
            tracks.forEach { t ->
                val file = DocumentFile.fromSingleUri(this, t.uri)
                val size = file?.length() ?: t.fileSize
                val modified = file?.lastModified() ?: t.fileModified
                t.fileSize = size; t.fileModified = modified
                array.put(JSONObject().apply {
                    put("uri", t.uri.toString()); put("size", size); put("modified", modified)
                    put("bpm", t.bpm ?: JSONObject.NULL); put("key", t.key ?: JSONObject.NULL); put("energy", t.energy ?: JSONObject.NULL)
                    put("introSeconds", t.introSeconds ?: JSONObject.NULL); put("entrySeconds", t.entrySeconds ?: JSONObject.NULL)
                    put("energyCurve", t.energyCurve ?: JSONObject.NULL); put("beatConfidence", t.beatConfidence ?: JSONObject.NULL); put("waveform", t.waveform ?: JSONObject.NULL); put("structureMarkers", t.structureMarkers ?: JSONObject.NULL)
                })
            }
            contentResolver.openOutputStream(cache.uri, "wt")?.bufferedWriter()?.use { it.write(array.toString()) }
        } catch (_: Exception) { /* se conserva también la biblioteca privada */ }
    }

    private fun toggleSessionRecording() {
        if (recordingActive) {
            startService(Intent(this, SessionRecordingService::class.java).setAction(SessionRecordingService.ACTION_STOP))
            status.text = "Finalizando archivo MP3…"
            return
        }
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) {
            Toast.makeText(this, "La grabación de audio interno requiere Android 10 o superior", Toast.LENGTH_LONG).show(); return
        }
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) requestProjectionPermission()
        else audioPermission.launch(android.Manifest.permission.RECORD_AUDIO)
    }

    private fun requestProjectionPermission() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionPermission.launch(manager.createScreenCaptureIntent())
    }

    private fun renderRecordingControls() {
        if (!isFinishing) render()
    }

    private fun persistLibrary() {
        val array = JSONArray()
        tracks.forEach { t ->
            array.put(JSONObject().apply {
                put("uri", t.uri.toString()); put("title", t.title)
                put("fileSize", t.fileSize); put("fileModified", t.fileModified); put("cacheValid", t.cacheValid)
                put("bpm", t.bpm ?: JSONObject.NULL); put("key", t.key ?: JSONObject.NULL); put("energy", t.energy ?: JSONObject.NULL)
                put("introSeconds", t.introSeconds ?: JSONObject.NULL); put("entrySeconds", t.entrySeconds ?: JSONObject.NULL)
                put("energyCurve", t.energyCurve ?: JSONObject.NULL); put("beatConfidence", t.beatConfidence ?: JSONObject.NULL); put("waveform", t.waveform ?: JSONObject.NULL); put("structureMarkers", t.structureMarkers ?: JSONObject.NULL)
            })
        }
        getSharedPreferences("imperio_party", MODE_PRIVATE).edit()
            .putString("library", array.toString())
            .putString("libraryFolderUri", libraryFolderUri?.toString())
            .apply()
    }

    private fun restoreLibrary() {
        val prefs = getSharedPreferences("imperio_party", MODE_PRIVATE)
        libraryFolderUri = prefs.getString("libraryFolderUri", null)?.let { Uri.parse(it) }
        val raw = prefs.getString("library", null) ?: return
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val uri = android.net.Uri.parse(item.getString("uri"))
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val bpm = if (item.isNull("bpm")) null else item.optInt("bpm").takeIf { it in 50..220 }
                val key = if (item.isNull("key")) null else item.optString("key")
                val energy = if (item.isNull("energy")) null else item.optInt("energy").takeIf { it in 1..5 }
                val track = Track(uri, item.optString("title", "Audio"), bpm, key, energy)
                track.fileSize = item.optLong("fileSize", -1L)
                track.fileModified = item.optLong("fileModified", -1L)
                track.cacheValid = item.optBoolean("cacheValid", false)
                track.introSeconds = if (item.isNull("introSeconds")) null else item.optInt("introSeconds")
                track.entrySeconds = if (item.isNull("entrySeconds")) null else item.optInt("entrySeconds")
                track.energyCurve = if (item.isNull("energyCurve")) null else item.optString("energyCurve")
                track.beatConfidence = if (item.isNull("beatConfidence")) null else item.optDouble("beatConfidence").toFloat()
                track.waveform = if (item.isNull("waveform")) null else item.optString("waveform")
                track.structureMarkers = if (item.isNull("structureMarkers")) null else item.optString("structureMarkers")
                tracks.add(track)
            }
        } catch (_: Exception) { tracks.clear() }
    }

    private fun startNextImmediately() {
        if (tracks.isEmpty()) return
        val n = if (nextIndex in tracks.indices) nextIndex else chooseNext(currentIndex.coerceAtLeast(0))
        playTrack(n)
    }
    private fun skipTrack() { if (tracks.isNotEmpty()) { val n = if (nextIndex in tracks.indices) nextIndex else chooseNext(currentIndex.coerceAtLeast(0)); playTrack(n); userSelectedNext = false; nextIndex = chooseNext(n); renderQueue() } }
    private fun previousTrack() { if (tracks.isNotEmpty()) { val n = if (currentIndex > 0) currentIndex - 1 else tracks.lastIndex; playTrack(n); nextIndex = chooseNext(n); userSelectedNext = false; renderQueue() } }
    private fun updateNowPlaying() {
        val t = tracks.getOrNull(currentIndex) ?: return
        nowTitle.text = t.title
        nowMeta.text = "${t.bpm?.let { "$it BPM" } ?: "BPM --"}  ·  ${t.key ?: "KEY --"}  ·  ${durationText(players[active]?.duration ?: 0)}"
        if (::waveformView.isInitialized) { waveformView.setWaveform(t.waveform); waveformView.setStructureMarkers(t.structureMarkers) }
    }
    private fun updatePlayButton() { if (::playButton.isInitialized) playButton.text = if (partyOn && players[active]?.isPlaying == true) "Ⅱ  PAUSAR FIESTA" else "▶  INICIAR FIESTA" }
    private fun durationText(ms: Long) = if (ms <= 0) "--:--" else String.format(Locale.US, "%02d:%02d", ms / 60000, ms / 1000 % 60)
    private fun listener(block: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { if (user) block(p) }; override fun onStartTrackingTouch(s: SeekBar) {}; override fun onStopTrackingTouch(s: SeekBar) {} }
    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(dp(5), dp(6), dp(5), dp(6)) }
    private fun action(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 10f
        isAllCaps = false
        letterSpacing = 0.025f
        minHeight = dp(42)
        setPadding(dp(8), dp(4), dp(8), dp(4))
        setTextColor(ACCENT)
        background = rounded(BUTTON, 10)
        stateListAnimator = null
        setOnClickListener { click() }
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), BORDER)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(recordingFinishedReceiver) } catch (_: Exception) {}
        analysisExecutor.shutdownNow()
        if (::samplerPlayers.isInitialized) samplerPlayers.forEach { it.release() }
        if (serviceBound) { try { unbindService(playbackConnection) } catch (_: Exception) {}; serviceBound = false }
        // El servicio es propietario de los reproductores: no se liberan al cerrar la Activity.
        super.onDestroy()
    }
    data class Track(val uri: android.net.Uri, val title: String, var bpm: Int? = null, var key: String? = null, var energy: Int? = null) {
        var fileSize: Long = -1L
        var fileModified: Long = -1L
        var cacheValid: Boolean = false
        var introSeconds: Int? = null
        var entrySeconds: Int? = null
        var energyCurve: String? = null
        var beatConfidence: Float? = null
        var waveform: String? = null
        var structureMarkers: String? = null
    }
    companion object {
        const val CACHE_FILE = "imperio_dj_analysis_cache.json"
        // Dark Profesional: grafito, acero y acento ámbar; sin alterar la lógica de audio.
        const val BG = 0xFF090B0F.toInt()
        const val PANEL = 0xFF15191F.toInt()
        const val PANEL_ALT = 0xFF1C222A.toInt()
        const val BUTTON = 0xFF20262E.toInt()
        const val BORDER = 0xFF343D48.toInt()
        const val GOLD = 0xFFFFB547.toInt()
        const val CYAN = 0xFF69C9E8.toInt()
        const val ACCENT = 0xFFFFA62B.toInt()
        const val WHITE = 0xFFF4F6F8.toInt()
        const val MUTED = 0xFF9AA4B1.toInt()
    }
}
