@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package com.imperio.djpromix

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.sin

/**
 * Real-time PCM FX processor used by one ExoPlayer deck.
 *
 * IMPORTANT: this processor intentionally keeps the input/output PCM format identical.
 * DefaultAudioSink therefore inserts it in the PCM processing chain and every control
 * changes the samples that reach AudioTrack; no visual/simulated FX are involved.
 */
class DjAudioFxProcessor : BaseAudioProcessor() {
    data class State(
        val filterWet: Float = 0f,
        val filterCutoffHz: Float = 20_000f,
        val filterHighPass: Boolean = false,
        val delayWet: Float = 0f,
        val delayMs: Float = 280f,
        val delayFeedback: Float = 0.25f,
        val reverbWet: Float = 0f,
        val echoWet: Float = 0f,
        val echoFeedback: Float = 0.28f,
        val flangerWet: Float = 0f,
        val bassGain: Float = 1f,
        val masterGain: Float = 1f,
        val reverseFrames: Int = 0
    )

    private val state = AtomicReference(State())
    private var sampleRate = 48_000
    private var channels = 2
    private var encoding = C.ENCODING_PCM_16BIT

    // Circular PCM memories. They are allocated only on stream flush, never on the audio thread.
    private var delayBuffer = FloatArray(0)
    private var reverbBuffer = FloatArray(0)
    private var flangerBuffer = FloatArray(0)
    private var reverseBuffer = FloatArray(0)
    private var delayIndex = 0
    private var reverbIndex = 0
    private var flangerIndex = 0
    private var reverseWrite = 0
    private var reverseFramesLeft = 0

    // Separate filter state: bass control must not corrupt the musical filter state.
    private var bassLp = FloatArray(2)
    private var filterLp = FloatArray(2)
    private var phase = 0.0

    fun setState(newState: State) {
        state.set(newState.copy(
            filterWet = newState.filterWet.coerceIn(0f, 1f),
            filterCutoffHz = newState.filterCutoffHz.coerceIn(20f, 20_000f),
            delayWet = newState.delayWet.coerceIn(0f, .9f),
            delayMs = newState.delayMs.coerceIn(20f, 1_200f),
            delayFeedback = newState.delayFeedback.coerceIn(0f, .82f),
            reverbWet = newState.reverbWet.coerceIn(0f, .75f),
            echoWet = newState.echoWet.coerceIn(0f, .85f),
            echoFeedback = newState.echoFeedback.coerceIn(0f, .82f),
            flangerWet = newState.flangerWet.coerceIn(0f, .75f),
            bassGain = newState.bassGain.coerceIn(0f, 1.5f),
            masterGain = newState.masterGain.coerceIn(0f, 1.15f),
            reverseFrames = newState.reverseFrames.coerceAtLeast(0)
        ))
    }

    fun snapshot(): State = state.get()
    fun resetFx() = setState(State())

    fun triggerBackspin(durationMs: Long = 450L) {
        reverseFramesLeft = ((durationMs.coerceIn(80L, 1_500L) * sampleRate) / 1000L).toInt()
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT && inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        sampleRate = inputAudioFormat.sampleRate.coerceAtLeast(8_000)
        channels = inputAudioFormat.channelCount.coerceIn(1, 2)
        encoding = inputAudioFormat.encoding
        // Returning the SAME format is intentional: BaseAudioProcessor marks this processor active.
        return inputAudioFormat
    }

    /** Media3 1.5.x-compatible flush hook. */
    @Suppress("DEPRECATION")
    override fun onFlush() {
        val maxDelayFrames = (sampleRate * 1.25f).toInt().coerceAtLeast(512)
        delayBuffer = FloatArray(maxDelayFrames * channels)
        // Three short reverb taps are contained in this 120 ms memory.
        reverbBuffer = FloatArray((sampleRate * .12f).toInt().coerceAtLeast(512) * channels)
        // 2..12 ms flanger range.
        flangerBuffer = FloatArray((sampleRate * .015f).toInt().coerceAtLeast(256) * channels)
        // 750 ms of real PCM history for Backspin.
        reverseBuffer = FloatArray((sampleRate * .75f).toInt().coerceAtLeast(1024) * channels)
        delayIndex = 0
        reverbIndex = 0
        flangerIndex = 0
        reverseWrite = 0
        reverseFramesLeft = 0
        bassLp = FloatArray(channels)
        filterLp = FloatArray(channels)
        phase = 0.0
    }

    override fun onReset() {
        delayBuffer = FloatArray(0)
        reverbBuffer = FloatArray(0)
        flangerBuffer = FloatArray(0)
        reverseBuffer = FloatArray(0)
        bassLp = FloatArray(2)
        filterLp = FloatArray(2)
        resetFx()
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val bytes = inputBuffer.remaining()
        if (bytes <= 0) return
        val frameBytes = if (encoding == C.ENCODING_PCM_FLOAT) 4 * channels else 2 * channels
        val frames = bytes / frameBytes
        if (frames <= 0) return

        val output = replaceOutputBuffer(frames * frameBytes)
        val src = inputBuffer.duplicate().order(ByteOrder.nativeOrder())
        val s = state.get()

        repeat(frames) {
            // Avoid per-frame allocations on the realtime audio thread.
            val left = readSample(src)
            val right = if (channels == 2) readSample(src) else left
            var outL = processSample(0, left, s)
            var outR = if (channels == 2) processSample(1, right, s) else outL

            if (reverseFramesLeft > 0 && reverseBuffer.isNotEmpty()) {
                val historyFrames = reverseBuffer.size / channels
                val back = ((reverseFramesLeft * 2L) % historyFrames).toInt()
                val start = (reverseWrite - 1 + historyFrames) % historyFrames
                val idx = (start - back + historyFrames) % historyFrames
                outL = reverseBuffer[idx * channels]
                if (channels == 2) outR = reverseBuffer[idx * channels + 1]
            }

            writeSample(output, outL)
            if (channels == 2) writeSample(output, outR)

            // Store the ORIGINAL PCM for a clean Backspin source.
            if (reverseBuffer.isNotEmpty()) {
                reverseBuffer[reverseWrite * channels] = left
                if (channels == 2) reverseBuffer[reverseWrite * channels + 1] = right
                reverseWrite = (reverseWrite + 1) % (reverseBuffer.size / channels)
            }
            if (reverseFramesLeft > 0) reverseFramesLeft--
        }

        inputBuffer.position(inputBuffer.position() + frames * frameBytes)
        output.flip()
    }

    private fun processSample(ch: Int, input: Float, s: State): Float {
        val ringFrames = delayBuffer.size / channels
        if (ringFrames < 4) return input

        // Bass Swap: low-shelf style attenuation/boost, independent from Filter.
        val bass = bassLp[ch] + .055f * (input - bassLp[ch])
        bassLp[ch] = bass
        var y = input + bass * (s.bassGain - 1f)

        // Filter: strong one-pole LP/HP with dry/wet mix.
        if (s.filterWet > .0001f) {
            val cutoff = s.filterCutoffHz.coerceIn(20f, sampleRate * .45f)
            val a = (2f * PI.toFloat() * cutoff / sampleRate).coerceIn(.001f, .98f)
            val low = filterLp[ch] + a * (input - filterLp[ch])
            filterLp[ch] = low
            val high = input - low
            val filtered = if (s.filterHighPass) high else low
            y = y * (1f - s.filterWet) + filtered * s.filterWet
        }

        val delayFrames = (s.delayMs * sampleRate / 1000f).toInt().coerceIn(1, ringFrames - 1)
        val echoFrames = (s.delayMs * 1.5f * sampleRate / 1000f).toInt().coerceIn(1, ringFrames - 1)
        val delayed = delayBuffer[((delayIndex - delayFrames + ringFrames) % ringFrames) * channels + ch]
        val echoed = delayBuffer[((delayIndex - echoFrames + ringFrames) % ringFrames) * channels + ch]
        val writeIndex = delayIndex * channels + ch

        // Delay and Echo are deliberately audible at the UI defaults.
        y += delayed * s.delayWet
        y += echoed * s.echoWet
        delayBuffer[writeIndex] = (input + delayed * s.delayFeedback + echoed * s.echoFeedback).coerceIn(-1f, 1f)

        // Reverb: three real short taps with feedback/diffusion.
        if (s.reverbWet > .0001f && reverbBuffer.isNotEmpty()) {
            val rf = reverbBuffer.size / channels
            val t1 = (sampleRate * .029f).toInt().coerceIn(1, rf - 1)
            val t2 = (sampleRate * .043f).toInt().coerceIn(1, rf - 1)
            val t3 = (sampleRate * .071f).toInt().coerceIn(1, rf - 1)
            val r1 = reverbBuffer[((reverbIndex - t1 + rf) % rf) * channels + ch]
            val r2 = reverbBuffer[((reverbIndex - t2 + rf) % rf) * channels + ch]
            val r3 = reverbBuffer[((reverbIndex - t3 + rf) % rf) * channels + ch]
            val wet = (r1 * .45f + r2 * .35f + r3 * .20f)
            y = y * (1f - s.reverbWet) + (y + wet) * s.reverbWet
            reverbBuffer[reverbIndex * channels + ch] = (input + wet * .72f).coerceIn(-1f, 1f)
        }

        // Flanger: 2..12 ms modulated real PCM delay.
        if (s.flangerWet > .0001f && flangerBuffer.isNotEmpty()) {
            val ff = flangerBuffer.size / channels
            val mod = .5f + .5f * sin(phase).toFloat()
            val fd = (sampleRate * (.002f + .010f * mod)).toInt().coerceIn(1, ff - 1)
            val fv = flangerBuffer[((flangerIndex - fd + ff) % ff) * channels + ch]
            y = y * (1f - s.flangerWet) + (y * .72f + fv * .28f) * s.flangerWet
            flangerBuffer[flangerIndex * channels + ch] = y.coerceIn(-1f, 1f)
        }

        if (ch == channels - 1) {
            delayIndex = (delayIndex + 1) % ringFrames
            if (reverbBuffer.isNotEmpty()) reverbIndex = (reverbIndex + 1) % (reverbBuffer.size / channels)
            if (flangerBuffer.isNotEmpty()) flangerIndex = (flangerIndex + 1) % (flangerBuffer.size / channels)
            phase += 2.0 * PI * .18 / sampleRate
            if (phase >= 2.0 * PI) phase -= 2.0 * PI
        }

        // Soft safety limiter. Prevents FX stacking from hard clipping.
        return softClip(y * s.masterGain)
    }

    private fun softClip(value: Float): Float {
        val x = value.coerceIn(-2f, 2f)
        return (x / (1f + kotlin.math.abs(x))).coerceIn(-.98f, .98f)
    }

    private fun readSample(buffer: ByteBuffer): Float = if (encoding == C.ENCODING_PCM_FLOAT) {
        buffer.float
    } else {
        buffer.short / 32768f
    }

    private fun writeSample(buffer: ByteBuffer, value: Float) {
        val v = value.coerceIn(-1f, 1f)
        if (encoding == C.ENCODING_PCM_FLOAT) buffer.putFloat(v) else buffer.putShort((v * 32767f).toInt().toShort())
    }
}
