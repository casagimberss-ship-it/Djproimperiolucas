@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package com.imperio.djpromix

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media3.exoplayer.ExoPlayer

/** Owns the two hidden players so audio can outlive MainActivity. */
class PartyPlaybackService : Service() {
    inner class LocalBinder : Binder() { fun getService(): PartyPlaybackService = this@PartyPlaybackService }
    private val binder = LocalBinder()
    lateinit var players: Array<ExoPlayer?>
        private set
    private var partyActive = false

    override fun onCreate() {
        super.onCreate()
        players = arrayOf(
            ExoPlayer.Builder(this).build(),
            ExoPlayer.Builder(this).build()
        )
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> setPartyActive(false)
            ACTION_RESUME -> setPartyActive(true)
            ACTION_STOP -> { setPartyActive(false); return START_STICKY }
            else -> startParty()
        }
        return START_STICKY
    }

    fun startParty() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(NOTIFICATION_ID, buildNotification())
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
    }


    fun setPartyActive(active: Boolean) {
        partyActive = active
        players.forEach { player ->
            if (active) player?.play() else player?.pause()
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val content = PendingIntent.getActivity(this, 10, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val action = if (partyActive) ACTION_PAUSE else ACTION_RESUME
        val actionLabel = if (partyActive) "Pausar" else "Reanudar"
        val control = PendingIntent.getService(this, 11, Intent(this, PartyPlaybackService::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 12, Intent(this, PartyPlaybackService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("MODO FIESTA")
            .setContentText(if (partyActive) "Modo Fiesta · reproducción activa" else "Modo Fiesta · en pausa")
            .setContentIntent(content)
            .setOngoing(partyActive)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, actionLabel, control)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stop)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Reproducción MODO FIESTA", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Controles de reproducción del Modo Fiesta"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        players.forEach { it?.release() }
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "imperio_party_playback"
        private const val NOTIFICATION_ID = 6201
        const val ACTION_PAUSE = "com.imperio.djpromix.PAUSE"
        const val ACTION_RESUME = "com.imperio.djpromix.RESUME"
        const val ACTION_STOP = "com.imperio.djpromix.STOP"
    }
}
