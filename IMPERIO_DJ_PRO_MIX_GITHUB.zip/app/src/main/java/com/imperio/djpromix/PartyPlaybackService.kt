@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package com.imperio.djpromix

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.media3.exoplayer.ExoPlayer

/** Owns the two hidden players so audio can outlive MainActivity. */
class PartyPlaybackService : Service() {
    inner class LocalBinder : Binder() { fun getService(): PartyPlaybackService = this@PartyPlaybackService }
    private val binder = LocalBinder()
    lateinit var players: Array<ExoPlayer?>
        private set
    private var partyActive = false
    private val fxHandler = Handler(Looper.getMainLooper())
    val deckFx: Array<DjAudioFxProcessor> = arrayOf(DjAudioFxProcessor(), DjAudioFxProcessor())

    override fun onCreate() {
        super.onCreate()
        players = arrayOf(
            ExoPlayer.Builder(this).setRenderersFactory(DjRenderersFactory(this, deckFx[0])).build(),
            ExoPlayer.Builder(this).setRenderersFactory(DjRenderersFactory(this, deckFx[1])).build()
        )
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> setPartyActive(false)
            ACTION_RESUME -> setPartyActive(true)
            ACTION_STOP -> { setPartyActive(false); return START_STICKY }
            else -> startParty()
        }
        return START_STICKY
    }

    fun startParty() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(NOTIFICATION_ID, buildNotification())
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
    }


    fun fx(deck: Int): DjAudioFxProcessor? = deckFx.getOrNull(deck)

    fun resetDeckFx(deck: Int) { deckFx.getOrNull(deck)?.resetFx() }

    fun setFilter(deck: Int, wet: Float, cutoffHz: Float, highPass: Boolean = false) {
        val fx = deckFx.getOrNull(deck) ?: return
        fx.setState(fx.snapshot().copy(filterWet = wet, filterCutoffHz = cutoffHz, filterHighPass = highPass))
    }

    fun setEcho(deck: Int, wet: Float, feedback: Float = 0.28f, delayMs: Float = 360f) {
        val fx = deckFx.getOrNull(deck) ?: return
        fx.setState(fx.snapshot().copy(echoWet = wet, echoFeedback = feedback, delayMs = delayMs))
    }

    fun setDelay(deck: Int, wet: Float, feedback: Float = 0.25f, delayMs: Float = 280f) {
        val fx = deckFx.getOrNull(deck) ?: return
        fx.setState(fx.snapshot().copy(delayWet = wet, delayFeedback = feedback, delayMs = delayMs))
    }

    fun setReverb(deck: Int, wet: Float) {
        val fx = deckFx.getOrNull(deck) ?: return
        fx.setState(fx.snapshot().copy(reverbWet = wet))
    }

    fun setFlanger(deck: Int, wet: Float) {
        val fx = deckFx.getOrNull(deck) ?: return
        fx.setState(fx.snapshot().copy(flangerWet = wet))
    }

    fun setBassGain(deck: Int, gain: Float) {
        val fx = deckFx.getOrNull(deck) ?: return
        fx.setState(fx.snapshot().copy(bassGain = gain))
    }

    fun triggerBackspin(deck: Int, durationMs: Long = 450L) {
        deckFx.getOrNull(deck)?.triggerBackspin(durationMs)
    }

    fun triggerBrake(deck: Int, durationMs: Long = 700L) {
        val player = players.getOrNull(deck) ?: return
        val start = player.playbackParameters.speed.coerceIn(.5f, 1.5f)
        val started = System.currentTimeMillis()
        val task = object : Runnable {
            override fun run() {
                val f = ((System.currentTimeMillis() - started).toFloat() / durationMs.coerceAtLeast(120L)).coerceIn(0f, 1f)
                player.setPlaybackSpeed(start * (1f - .65f * f))
                if (f < 1f) fxHandler.postDelayed(this, 25L) else {
                    player.setPlaybackSpeed(1f)
                    player.play()
                }
            }
        }
        fxHandler.post(task)
    }

    fun setPartyActive(active: Boolean) {
        partyActive = active
        players.forEach { player ->
            if (active) player?.play() else player?.pause()
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val content = PendingIntent.getActivity(this, 10, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val action = if (partyActive) ACTION_PAUSE else ACTION_RESUME
        val actionLabel = if (partyActive) "Pausar" else "Reanudar"
        val control = PendingIntent.getService(this, 11, Intent(this, PartyPlaybackService::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 12, Intent(this, PartyPlaybackService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("MODO FIESTA")
            .setContentText(if (partyActive) "Modo Fiesta · reproducción activa" else "Modo Fiesta · en pausa")
            .setContentIntent(content)
            .setOngoing(partyActive)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, actionLabel, control)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stop)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Reproducción MODO FIESTA", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Controles de reproducción del Modo Fiesta"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        players.forEach { it?.release() }
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "imperio_party_playback"
        private const val NOTIFICATION_ID = 6201
        const val ACTION_PAUSE = "com.imperio.djpromix.PAUSE"
        const val ACTION_RESUME = "com.imperio.djpromix.RESUME"
        const val ACTION_STOP = "com.imperio.djpromix.STOP"
    }
}
