package com.imperio.djpromix

import kotlin.math.abs
import kotlin.math.min

/**
 * Offline transition recommender. It only selects techniques that the current
 * playback graph can actually execute (tempo correction + cue seek + crossfade).
 * Effects that need unavailable DSP (bass swap, echo, vocal isolation, loop DSP,
 * drop detection) are deliberately never advertised as executable.
 */
class SmartTransitionEngine {
    enum class Technique {
        HARMONIC_BEATMATCH,
        PHRASE_BEATMATCH,
        INTRO_BEATMATCH,
        BEATMATCH_CROSSFADE,
        INTRO_CROSSFADE,
        STANDARD_CROSSFADE
    }

    data class TrackData(
        val bpm: Int?,
        val camelot: String?,
        val energy: Int?,
        val introSeconds: Int?,
        val entrySeconds: Int?,
        val beatConfidence: Float?
    )

    data class Recommendation(
        val technique: Technique,
        val label: String,
        val explanation: String,
        val tempoRatio: Float,
        val tempoCompatible: Boolean,
        val incomingStartMs: Long,
        val phraseAligned: Boolean,
        val score: Double,
        val reasons: List<String>
    )

    fun recommend(outgoing: TrackData, incoming: TrackData): Recommendation {
        val bpmA = outgoing.bpm?.takeIf { it in 50..220 }
        val bpmB = incoming.bpm?.takeIf { it in 50..220 }
        val confidenceA = outgoing.beatConfidence ?: 0f
        val confidenceB = incoming.beatConfidence ?: 0f
        val bpmReliable = bpmA != null && bpmB != null && confidenceA >= 0.20f && confidenceB >= 0.20f
        val rawRatio = if (bpmReliable) bpmA!!.toFloat() / bpmB!!.toFloat() else 1f
        val tempoCompatible = bpmReliable && rawRatio in 0.94f..1.06f
        val keyDistance = camelotDistance(outgoing.camelot, incoming.camelot)
        val harmonic = keyDistance != null && keyDistance <= 1
        val phrase = tempoCompatible && confidenceA >= 0.45f && confidenceB >= 0.45f
        val entryMs = ((incoming.entrySeconds ?: incoming.introSeconds ?: 0).coerceAtLeast(0) * 1000L)
        val hasEntry = entryMs > 0L

        val reasons = mutableListOf<String>()
        if (tempoCompatible) reasons += "BPM compatibles (${bpmA} → ${bpmB})"
        else if (bpmReliable) reasons += "Diferencia de tempo superior al 6%; no se fuerza sincronización"
        else reasons += "BPM sin confianza suficiente; se conserva velocidad original"
        if (harmonic) reasons += "Tonalidades Camelot compatibles"
        if (phrase) reasons += "Pulso con confianza suficiente para alinear aproximadamente la frase"
        if (hasEntry) reasons += "Entrada sugerida a ${entryMs / 1000}s"
        if (outgoing.energy != null && incoming.energy != null) {
            reasons += "Energía ${outgoing.energy}/5 → ${incoming.energy}/5"
        }

        val technique = when {
            tempoCompatible && harmonic -> Technique.HARMONIC_BEATMATCH
            phrase -> Technique.PHRASE_BEATMATCH
            tempoCompatible && hasEntry -> Technique.INTRO_BEATMATCH
            tempoCompatible -> Technique.BEATMATCH_CROSSFADE
            hasEntry -> Technique.INTRO_CROSSFADE
            else -> Technique.STANDARD_CROSSFADE
        }
        val label = when (technique) {
            Technique.HARMONIC_BEATMATCH -> "HARMONIC + BEATMATCH + CROSSFADE"
            Technique.PHRASE_BEATMATCH -> "PHRASE MIX + BEATMATCH + CROSSFADE"
            Technique.INTRO_BEATMATCH -> "INTRO MIX + BEATMATCH + CROSSFADE"
            Technique.BEATMATCH_CROSSFADE -> "BEATMATCH + CROSSFADE"
            Technique.INTRO_CROSSFADE -> "INTRO MIX + CROSSFADE"
            Technique.STANDARD_CROSSFADE -> "CROSSFADE ESTÁNDAR"
        }
        val score = (if (tempoCompatible) 0.35 else 0.0) +
            (if (harmonic) 0.25 else 0.0) +
            (if (phrase) 0.20 else 0.0) +
            (if (hasEntry) 0.10 else 0.0) +
            (min(confidenceA, confidenceB).coerceIn(0f, 1f) * 0.10)
        val explanation = when (technique) {
            Technique.HARMONIC_BEATMATCH -> "Coinciden tempo y compatibilidad tonal; es la opción prioritaria."
            Technique.PHRASE_BEATMATCH -> "El tempo y la confianza del pulso permiten buscar un cambio de frase."
            Technique.INTRO_BEATMATCH -> "Se puede sincronizar el tempo y entrar desde el punto sugerido."
            Technique.BEATMATCH_CROSSFADE -> "Se iguala el tempo dentro del margen seguro y se realiza el fundido."
            Technique.INTRO_CROSSFADE -> "Se utiliza el punto de entrada estimado y se realiza el fundido sin forzar BPM."
            Technique.STANDARD_CROSSFADE -> "No hay datos suficientes para técnicas avanzadas; se utiliza un fundido seguro."
        }
        return Recommendation(technique, label, explanation, if (tempoCompatible) rawRatio else 1f,
            tempoCompatible, entryMs, phrase, score, reasons)
    }

    /** Higher is better; used to rank next-track candidates before the AI tie-breaker. */
    fun rankScore(recommendation: Recommendation): Double = recommendation.score

    private fun camelotDistance(a: String?, b: String?): Int? {
        if (a == null || b == null) return null
        val x = Regex("(1[0-2]|[1-9])([AB])").matchEntire(a.uppercase()) ?: return null
        val y = Regex("(1[0-2]|[1-9])([AB])").matchEntire(b.uppercase()) ?: return null
        val n = x.groupValues[1].toInt()
        val m = y.groupValues[1].toInt()
        val wheel = min(abs(n - m), 12 - abs(n - m))
        return wheel + if (x.groupValues[2] == y.groupValues[2]) 0 else 1
    }
}
