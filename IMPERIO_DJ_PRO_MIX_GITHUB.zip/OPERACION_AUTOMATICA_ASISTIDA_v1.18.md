# MODO FIESTA — Operación Automática y Asistida

## Decisión funcional confirmada
La aplicación ofrece exclusivamente dos modos de operación. No existe modo Manual.

### Automático
- El motor local selecciona la siguiente pista según el perfil de sesión y los datos disponibles.
- La aplicación decide cuándo iniciar la transición y ejecuta el crossfade completo.
- El modo de operación se guarda localmente.

### Asistido
- La aplicación prepara una recomendación de siguiente pista.
- El usuario puede cambiar la siguiente pista desde la biblioteca/cola.
- Al pulsar **Aceptar y ejecutar transición completa**, la aplicación inicia y termina el crossfade con la duración configurada.
- El usuario no necesita mover un crossfader ni controlar manualmente los decks.
- La aceptación se rechaza si no hay una pista siguiente válida, si la pista actual no está reproduciéndose o si ya hay una transición activa.
- La operación asistida no dispara transiciones automáticamente por el temporizador de fin de pista.

## Persistencia
Se guarda el modo en SharedPreferences `modo_fiesta_operation`, clave `mode`. Es un espacio nuevo y no altera claves previas de biblioteca, sampler, sesión o análisis.

## Alcance de esta integración
Esta entrega conecta el selector Automático/Asistido y el flujo de aceptación al crossfade existente. No convierte por sí misma los algoritmos aproximados de BPM/frase en beatmatching profesional ni implementa los DSP pendientes. Esos trabajos permanecen en la lista de integración y pruebas.
