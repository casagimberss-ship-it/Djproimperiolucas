# MODO FIESTA v1.18.2 — Selector inteligente de transiciones

## Flujo integrado
1. `chooseNext()` obtiene candidatas de la biblioteca.
2. `SmartTransitionEngine` evalúa tempo, confianza de beat, Camelot, energía y cue de entrada disponible.
3. La calidad de transición pesa en el ranking; `LocalNeuralDjModel` desempata con preferencias/estilo e historial local.
4. `MainActivity.render()` muestra la técnica recomendada en ambos modos.
5. Automático inicia el crossfade al alcanzar la ventana de transición. Asistido espera la acción “ACEPTAR Y EJECUTAR TRANSICIÓN COMPLETA”.
6. `beginCrossfade()` vuelve a calcular el mismo plan, aplica el punto de entrada sugerido y corrige velocidad solo si el BPM tiene confianza suficiente y la relación queda dentro de 0.94–1.06. Después ejecuta el crossfade.

## Técnicas actualmente ejecutables
- Harmonic + Beatmatch + Crossfade: tempo compatible y Camelot igual/adyacente.
- Phrase Mix + Beatmatch + Crossfade: tempo compatible y confianza de pulso alta; la alineación de frase es aproximada.
- Intro Mix + Beatmatch + Crossfade: usa el punto de entrada estimado.
- Beatmatch + Crossfade.
- Intro Mix + Crossfade sin forzar BPM.
- Crossfade estándar como fallback seguro.

## Límites explícitos
- No existe time-stretch de calidad DJ ni beat-grid warp: `setPlaybackSpeed` ofrece corrección limitada de velocidad.
- La tonalidad Camelot es una estimación y no se hace key-shift.
- El punto de entrada es un cue estimado.
- No se recomienda Bass Swap, vocal isolation, Drop Mix semántico, Loop Transition DSP ni efectos que no estén conectados al grafo de audio.
- No hay detección de público/pista llena; la energía musical no equivale a respuesta real de pista.

## Modos de operación
Solo AUTOMÁTICO y ASISTIDO. No hay modo Manual. Ambos usan el mismo selector y el mismo crossfade; la diferencia es quién autoriza su inicio.

## Pruebas pendientes
Compilar con GitHub Actions/Gradle 8.9, instalar en Android real, probar varias bibliotecas y revisar a oído transiciones con BPM fiables, incompatibles, Camelot adyacente, cue de entrada y ausencia de análisis.
