# MODO FIESTA v1.18 — Integración funcional inicial

## Objetivo
Conservar Dark Profesional, identificadores y datos existentes, trabajar localmente y completar tres integraciones prioritarias: programación de duración, análisis PCM de archivos y cierre coordinado con la grabación.

## Cambios realizados
- Programación del set: 30 min, 1 h, 2 h, 3 h o duración personalizada de 1 a 720 minutos; opción para desactivar.
- Persistencia del vencimiento en `SharedPreferences` (`imperio_party/setDeadlineWallMs`). El vencimiento se compara con reloj de pared, por lo que el tiempo transcurrido se recupera tras recrear Activity/proceso.
- Al cumplirse el tiempo, el sistema deja de iniciar transiciones automáticas y espera el evento `STATE_ENDED` del deck activo. Si el vencimiento ocurre durante un crossfade ya iniciado, deja que la transición concluya y espera el final del tema que quede activo.
- Al terminar la canción: pausa/detiene ambos decks, detiene el servicio de reproducción y solicita al servicio de grabación que cierre el MP3. El encoder existente ejecuta `flush`, vacía el stream y cierra el archivo antes de emitir `ACTION_FINISHED`.
- Guarda fecha y duración de la sesión en preferencias; muestra estado de finalización.
- Análisis local con `MediaExtractor` + `MediaCodec`: decodifica PCM, estima BPM/tonalidad, estructura aproximada, energía, confianza de beat y forma de onda. El análisis existente se conserva y se ejecuta desde la acción ANALIZAR; resultados se guardan en la caché local.
- Icono de launcher derivado de la imagen proporcionada: recursos legacy por densidad y adaptive icon para Android 8+.
- Se elimina permiso `INTERNET` del manifiesto: no se declara acceso de red.
- Notificación de reproducción actualizada a MODO FIESTA.

## Límites que deben conocerse
- El análisis es DSP heurístico local, no un modelo neuronal entrenado. BPM, tonalidad, detección de frase y energía son estimaciones y deben validarse con bibliotecas musicales reales.
- El vencimiento no fuerza un despertar exacto del dispositivo en Doze. Se evalúa en el ciclo de UI y también al recibir `STATE_ENDED`; por eso no corta la canción al segundo exacto, sino que respeta su final. La pantalla puede estar apagada.
- Si Android mata el proceso y el servicio de reproducción no permanece vivo, no se puede garantizar la continuidad de reproducción; el estado del plazo queda persistido para recuperación.
- El cierre del MP3 es asíncrono. La confirmación definitiva de guardado llega por `ACTION_FINISHED`; la pantalla muestra mientras tanto que está cerrando el archivo.
- No se ha implementado todavía DSP real de Bass Swap, reverb, echo, filter o flanger, ni sincronización de rejilla/warp de precisión. Los modos y selectores previos siguen siendo modelos/planificación donde no exista integración explícita.

## Compatibilidad
- Se mantienen `applicationId` y namespace `com.imperio.djpromix`.
- No se cambian `versionCode=12`, `versionName=1.11.0`, claves históricas de preferencias ni formato de caché.
- Se mantienen AndroidX/Media3 existentes y minSdk 26.
- No se elimina ninguna clase previa del ZIP base.

## Validación realizada
- ZIP de origen íntegro antes de modificar.
- XML de manifiesto y recursos validables estructuralmente.
- Recursos de launcher generados en cinco densidades y adaptive icon.
- No se pudo ejecutar `assembleDebug`: este entorno no tiene Gradle/Android SDK configurados ni wrapper incluido. No se entrega APK ni se afirma compilación Android exitosa.

## Pruebas necesarias en dispositivo
1. Programar 1 minuto y confirmar que la pista actual termina completa antes de detenerse.
2. Repetir con grabación MP3 activa; verificar reproducción detenida, `ACTION_FINISHED`, MP3 reproducible y tamaño no cero.
3. Apagar pantalla y repetir; probar además Doze/ahorro de batería.
4. Probar pausa manual, cambio manual de canción y vencimiento durante crossfade.
5. Analizar MP3, AAC, M4A y WAV; comparar BPM/tonalidad con referencia y verificar permisos SAF tras reinicio.
6. Instalar sobre versión anterior para confirmar que biblioteca, bancos sampler y cachés permanecen.
