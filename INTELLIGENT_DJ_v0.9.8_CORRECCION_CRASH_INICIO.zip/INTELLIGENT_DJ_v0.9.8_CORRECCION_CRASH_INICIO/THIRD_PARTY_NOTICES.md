# Third-party notices — INTELLIGENT DJ v0.8.0

## TAndroidLame 1.1 / LAME

This project uses TAndroidLame, an Android/Java wrapper around the LAME MP3 encoder. The upstream project declares GPL-3.0-or-later.

Upstream: https://github.com/naman14/TAndroidLame
License: GNU General Public License v3.0 or later.

Review GPL compliance and source-code distribution obligations before distributing this application. This notice is not legal advice.
