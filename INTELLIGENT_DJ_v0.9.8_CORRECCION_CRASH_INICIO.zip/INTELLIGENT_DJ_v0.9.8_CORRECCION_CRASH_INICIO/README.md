# INTELLIGENT DJ v0.9.1

Esta versión corrige la reutilización de análisis mediante huella SHA-256 por archivo y mejora la selección de pistas de Smart Mix con criterios de BPM, Camelot, energía, confianza e intro/frase.

- `versionCode`: 17
- `versionName`: 0.9.1
- Room schema: 3 (migraciones 1→2→3)

Ver `LEEME_v0.9.1_CACHE_SMART_MIX.txt` para cambios y pruebas recomendadas.

## v0.9.7 — Smart Mix Engine

La versión 0.9.7 añade un planificador por transición que combina BPM local, beat offset, frases, compatibilidad Camelot, energía, duración restante e intro/outro. El crossfade pasa a tener duración adaptativa y aplica un perfil de ecualización opcional por deck cuando Android lo soporta. Los marcadores de estructura siguen siendo estimaciones basadas en energía y deben validarse con música real.
