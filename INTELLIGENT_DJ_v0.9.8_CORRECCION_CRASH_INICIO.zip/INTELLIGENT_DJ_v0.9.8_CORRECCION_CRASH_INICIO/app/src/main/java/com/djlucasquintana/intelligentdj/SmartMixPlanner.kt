package com.djlucasquintana.intelligentdj

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** A per-transition decision built only from persisted full-track analysis. */
data class MixTransitionPlan(
    val playbackSpeed: Float,
    val phraseWaitMs: Long,
    val fadeDurationMs: Long,
    val incomingStartMs: Long,
    val outgoingCueMs: Long?,
    val harmonicCompatibility: Int,
    val energyDelta: Double?,
    val reason: String
)

/** Deterministic, conservative transition planner. It always has safe fallbacks for missing analysis. */
object SmartMixPlanner {
    fun plan(
        outgoing: TrackAnalysis?,
        incoming: TrackAnalysis?,
        outgoingPositionMs: Long,
        outgoingDurationMs: Long,
        incomingDurationMs: Long,
        maxTempoChange: Double = 0.06
    ): MixTransitionPlan {
        val outBpm = localBpm(outgoing, outgoingPositionMs / 1000.0)
        val inBpm = localBpm(incoming, incoming?.beatOffsetSeconds ?: 0.0)
        val speed = tempoRatio(outBpm, inBpm, maxTempoChange)
        val phraseWait = nextPhraseDelay(outgoing, outgoingPositionMs)
        val remaining = if (outgoingDurationMs > 0L) (outgoingDurationMs - outgoingPositionMs).coerceAtLeast(0L) else 0L
        val energyDelta = if (outgoing?.energy != null && incoming?.energy != null) incoming.energy - outgoing.energy else null
        val intro = incoming?.introEndSeconds?.takeIf { it in 4.0..90.0 }
        val outro = outgoing?.outroStartSeconds?.takeIf { it >= 0.0 }
        val phrase = listOfNotNull(outgoing?.phraseLengthSeconds, incoming?.phraseLengthSeconds)
            .filter { it in 2.0..120.0 }.minOrNull()
        var fade = when {
            phrase != null -> (phrase * 1000.0 * if (energyDelta != null && abs(energyDelta) > 0.25) 0.5 else 1.0).toLong()
            else -> 6_000L
        }
        if (intro != null && incomingDurationMs > 0L) {
            val usableIntro = (intro * 1000.0).toLong().coerceIn(0L, incomingDurationMs)
            // Do not consume the whole intro: leave a short overlap for the incoming track to establish itself.
            fade = min(fade, max(4_000L, usableIntro.coerceAtMost(12_000L)))
        }
        if (energyDelta != null && energyDelta < -0.25) fade = (fade * 0.8).toLong()
        if (energyDelta != null && energyDelta > 0.25) fade = (fade * 1.15).toLong()
        fade = fade.coerceIn(3_000L, 12_000L)
        if (remaining > 0L) fade = min(fade, remaining.coerceAtLeast(600L))
        val safePhraseWait = if (remaining > 0L) min(phraseWait, (remaining - fade - 500L).coerceAtLeast(0L)) else 0L
        val incomingStart = incoming?.beatOffsetSeconds?.takeIf { it >= 0.0 }?.times(1000.0)?.toLong()
            ?.coerceIn(0L, (incomingDurationMs - 1L).coerceAtLeast(0L)) ?: 0L
        val harmonic = harmonicCompatibility(outgoing?.camelot, incoming?.camelot)
        val reason = buildString {
            append(if (outBpm != null && inBpm != null) "BPM adaptativo" else "BPM sin análisis completo")
            append(" · ")
            append(if (harmonic > 0) "tonalidad compatible" else "tonalidad no confirmada")
            append(" · ")
            append(if (outro != null) "outro detectado" else "salida de seguridad")
        }
        return MixTransitionPlan(speed, safePhraseWait.coerceIn(0L, 2_000L), fade, incomingStart, outro?.times(1000.0)?.toLong(), harmonic, energyDelta, reason)
    }

    fun localBpm(analysis: TrackAnalysis?, positionSeconds: Double): Double? {
        analysis ?: return null
        val window = (positionSeconds / 30.0).toInt().coerceAtLeast(0)
        return analysis.bpmTimeline.getOrNull(window)?.takeIf { it.isFinite() && it in 60.0..200.0 }
            ?: analysis.bpm?.takeIf { it in 60.0..200.0 }
    }

    fun tempoRatio(currentBpm: Double?, incomingBpm: Double?, maxChange: Double = 0.06): Float {
        if (currentBpm == null || incomingBpm == null || currentBpm <= 0.0 || incomingBpm <= 0.0) return 1f
        val targetVariants = listOf(incomingBpm / 2.0, incomingBpm, incomingBpm * 2.0)
        val matched = targetVariants.minByOrNull { abs(it - currentBpm) } ?: incomingBpm
        return (currentBpm / matched).coerceIn(1.0 - maxChange, 1.0 + maxChange).toFloat()
    }

    fun nextPhraseDelay(analysis: TrackAnalysis?, positionMs: Long): Long {
        val offset = analysis?.beatOffsetSeconds?.takeIf { it >= 0.0 } ?: return 0L
        val phrase = analysis.phraseLengthSeconds?.takeIf { it in 2.0..120.0 } ?: return 0L
        val elapsed = (positionMs / 1000.0 - offset).coerceAtLeast(0.0)
        val remainder = elapsed % phrase
        return (if (remainder < 0.08) 0.0 else phrase - remainder).times(1000.0).toLong().coerceIn(0L, 8_000L)
    }

    fun harmonicCompatibility(a: String?, b: String?): Int {
        val first = parseCamelot(a) ?: return 0
        val second = parseCamelot(b) ?: return 0
        val (na, la) = first
        val (nb, lb) = second
        return when {
            na == nb && la == lb -> 100
            na == nb && la != lb -> 88
            la == lb && (na - nb).mod(12) in setOf(1, 11) -> 82
            la != lb && (na - nb).mod(12) in setOf(1, 11) -> 58
            else -> 0
        }
    }

    private fun parseCamelot(value: String?): Pair<Int, Char>? {
        val v = value?.trim()?.uppercase() ?: return null
        if (v.length !in 2..3) return null
        val number = v.dropLast(1).toIntOrNull() ?: return null
        val letter = v.last()
        return if (number in 1..12 && letter in setOf('A', 'B')) number to letter else null
    }
}
