package com.djlucasquintana.intelligentdj

import android.content.Context
import android.net.Uri
import java.security.MessageDigest
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.Index
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Persisted analysis for one audio document. URI is the stable SAF document identifier. */
@Entity(tableName = "tracks", indices = [Index(value = ["contentFingerprint", "analysisStatus"])])
data class TrackEntity(
    @PrimaryKey val uri: String,
    val name: String,
    val sizeBytes: Long,
    val modifiedAt: Long,
    val durationSeconds: Double?,
    val analyzedDurationSeconds: Double?,
    val bpm: Double?,
    val camelot: String?,
    val energy: Double?,
    val beatOffsetSeconds: Double?,
    val beatIntervalSeconds: Double?,
    val phraseLengthSeconds: Double?,
    val introEndSeconds: Double?,
    val outroStartSeconds: Double?,
    val analysisConfidence: Double?,
    val energyTimeline: String,
    val bpmTimeline: String,
    val analyzedAt: Long,
    @ColumnInfo(defaultValue = "'PENDIENTE'") val analysisStatus: String = "PENDIENTE",
    @ColumnInfo(defaultValue = "''") val sourceFolderUri: String = "",
    @ColumnInfo(defaultValue = "''") val contentFingerprint: String = "",
)

@Entity(tableName = "library_folders")
data class LibraryFolderEntity(
    @PrimaryKey val treeUri: String,
    val displayName: String,
    val scannedAt: Long,
)

@Dao
interface TrackDao {
    @Query("SELECT * FROM tracks WHERE uri = :uri LIMIT 1")
    suspend fun findByUri(uri: String): TrackEntity?

    @Query("SELECT * FROM tracks ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<TrackEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(track: TrackEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(tracks: List<TrackEntity>)

    @Query("DELETE FROM tracks WHERE uri = :uri")
    suspend fun deleteByUri(uri: String)

    @Query("SELECT COUNT(*) FROM tracks")
    suspend fun count(): Int

    @Query("SELECT * FROM library_folders ORDER BY displayName COLLATE NOCASE")
    suspend fun getLibraryFolders(): List<LibraryFolderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLibraryFolder(folder: LibraryFolderEntity)

    @Query("SELECT * FROM tracks WHERE contentFingerprint = :fingerprint AND analysisStatus = 'OK' ORDER BY analyzedAt DESC LIMIT 1")
    suspend fun findByFingerprint(fingerprint: String): TrackEntity?

    @Query("DELETE FROM tracks")
    suspend fun clearTracks()

    @Transaction
    suspend fun appendLibrary(folder: LibraryFolderEntity, tracks: List<TrackEntity>) {
        upsertAll(tracks)
        saveLibraryFolder(folder)
    }
}

@Database(entities = [TrackEntity::class, LibraryFolderEntity::class], version = 4, exportSchema = false)
abstract class DjDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao

    companion object {
        @Volatile private var INSTANCE: DjDatabase? = null
        fun get(context: Context): DjDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                DjDatabase::class.java,
                "intelligent_dj_library.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build().also { INSTANCE = it }
        }

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tracks ADD COLUMN analysisStatus TEXT NOT NULL DEFAULT 'PENDIENTE'")
                db.execSQL("ALTER TABLE tracks ADD COLUMN sourceFolderUri TEXT NOT NULL DEFAULT ''")
                db.execSQL("CREATE TABLE IF NOT EXISTS library_folders (id INTEGER NOT NULL, treeUri TEXT NOT NULL, displayName TEXT NOT NULL, scannedAt INTEGER NOT NULL, PRIMARY KEY(id))")
                db.execSQL("UPDATE tracks SET analysisStatus = CASE WHEN bpm IS NOT NULL AND camelot IS NOT NULL AND durationSeconds IS NOT NULL AND analyzedDurationSeconds IS NOT NULL AND analyzedDurationSeconds + 1.0 >= durationSeconds THEN 'OK' ELSE 'ERROR' END")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE tracks ADD COLUMN contentFingerprint TEXT NOT NULL DEFAULT ''")
                db.execSQL("UPDATE tracks SET analysisStatus = 'OK' WHERE durationSeconds IS NOT NULL AND analyzedDurationSeconds IS NOT NULL AND analyzedDurationSeconds + 1.0 >= durationSeconds")
            }
        }
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS library_folders_new (treeUri TEXT NOT NULL, displayName TEXT NOT NULL, scannedAt INTEGER NOT NULL, PRIMARY KEY(treeUri))")
                db.execSQL("INSERT OR IGNORE INTO library_folders_new (treeUri, displayName, scannedAt) SELECT treeUri, displayName, scannedAt FROM library_folders")
                db.execSQL("DROP TABLE library_folders")
                db.execSQL("ALTER TABLE library_folders_new RENAME TO library_folders")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tracks_contentFingerprint_analysisStatus ON tracks (contentFingerprint, analysisStatus)")
            }
        }
    }
}

/** Converts analyzer output into a Room row without losing the complete timelines. */
fun TrackEntity.toAnalysis(): TrackAnalysis = TrackAnalysis(
    bpm = bpm,
    camelot = camelot,
    energy = energy,
    beatOffsetSeconds = beatOffsetSeconds,
    beatIntervalSeconds = beatIntervalSeconds,
    phraseLengthSeconds = phraseLengthSeconds,
    introEndSeconds = introEndSeconds,
    outroStartSeconds = outroStartSeconds,
    analysisConfidence = analysisConfidence,
    durationSeconds = durationSeconds,
    analyzedDurationSeconds = analyzedDurationSeconds,
    energyTimeline = decodeDoubles(energyTimeline),
    bpmTimeline = decodeDoubles(bpmTimeline)
)

fun Track.toEntity(sourceFolderUri: String = "", analysisStatus: String = "OK"): TrackEntity = TrackEntity(
    uri = uri.toString(), name = name, sizeBytes = sizeBytes, modifiedAt = modifiedAt,
    durationSeconds = analysis.durationSeconds,
    analyzedDurationSeconds = analysis.analyzedDurationSeconds,
    bpm = analysis.bpm, camelot = analysis.camelot, energy = analysis.energy,
    beatOffsetSeconds = analysis.beatOffsetSeconds,
    beatIntervalSeconds = analysis.beatIntervalSeconds,
    phraseLengthSeconds = analysis.phraseLengthSeconds,
    introEndSeconds = analysis.introEndSeconds,
    outroStartSeconds = analysis.outroStartSeconds,
    analysisConfidence = analysis.analysisConfidence,
    energyTimeline = encodeDoubles(analysis.energyTimeline),
    bpmTimeline = encodeDoubles(analysis.bpmTimeline),
    analyzedAt = System.currentTimeMillis(),
    analysisStatus = analysisStatus,
    sourceFolderUri = sourceFolderUri
)

private fun encodeDoubles(values: List<Double>): String = values.joinToString(",") {
    if (it.isFinite()) it.toString() else "NaN"
}

private fun decodeDoubles(value: String): List<Double> = if (value.isBlank()) emptyList() else
    value.split(',').mapNotNull { token -> token.toDoubleOrNull() }

/** Cache validity depends on the SAF document's size and modification timestamp. */
suspend fun TrackDao.getCachedAnalysis(track: Track, fingerprint: String?): TrackAnalysis? = withContext(Dispatchers.IO) {
    val uriRow = findByUri(track.uri.toString())
    val fingerprintRow = fingerprint?.takeIf { it.isNotBlank() }?.let { findByFingerprint(it) }
    val uriFingerprintMatches = uriRow != null && !fingerprint.isNullOrBlank() &&
        uriRow.contentFingerprint.isNotBlank() && fingerprint.equals(uriRow.contentFingerprint, ignoreCase = true)
    val row = when {
        uriRow == null -> fingerprintRow
        fingerprintRow != null && !uriFingerprintMatches -> fingerprintRow
        else -> uriRow
    } ?: return@withContext null
    val fingerprintMatches = !fingerprint.isNullOrBlank() && row.contentFingerprint.isNotBlank() &&
        fingerprint.equals(row.contentFingerprint, ignoreCase = true)
    // SAF providers sometimes return zero for size/lastModified. In that case, only a
    // content hash is strong enough to reuse an existing analysis safely.
    val hasComparableMetadata = track.sizeBytes > 0L || track.modifiedAt > 0L
    val metadataMatches = hasComparableMetadata &&
        (track.sizeBytes <= 0L || row.sizeBytes == track.sizeBytes) &&
        (track.modifiedAt <= 0L || row.modifiedAt == track.modifiedAt)
    val legacyMetadataMatches = fingerprint.isNullOrBlank() && metadataMatches
    // One-time compatibility path for v0.9.0 rows whose SAF provider exposed neither size nor date.
    val legacyUnknownMetadata = row.contentFingerprint.isBlank() && track.sizeBytes == 0L && track.modifiedAt == 0L &&
        row.sizeBytes == 0L && row.modifiedAt == 0L
    val contentMatchFromFingerprint = !fingerprint.isNullOrBlank() && fingerprintMatches
    if (row.analysisStatus != "OK" || (!contentMatchFromFingerprint && !legacyMetadataMatches && !legacyUnknownMetadata) ||
        row.analyzedDurationSeconds == null || row.durationSeconds == null ||
        row.analyzedDurationSeconds + 1.0 < row.durationSeconds) return@withContext null
    row.toAnalysis()
}

/** SHA-256 of the source bytes, calculated off the UI thread; stable even when SAF metadata is unavailable. */
suspend fun calculateAudioFingerprint(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
    val digest = MessageDigest.getInstance("SHA-256")
    val input = context.contentResolver.openInputStream(uri) ?: return@withContext null
    input.use { stream ->
        val buffer = ByteArray(1024 * 1024)
        while (true) {
            currentCoroutineContext().ensureActive()
            val count = stream.read(buffer)
            if (count < 0) break
            if (count > 0) digest.update(buffer, 0, count)
        }
    }
    digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
}
