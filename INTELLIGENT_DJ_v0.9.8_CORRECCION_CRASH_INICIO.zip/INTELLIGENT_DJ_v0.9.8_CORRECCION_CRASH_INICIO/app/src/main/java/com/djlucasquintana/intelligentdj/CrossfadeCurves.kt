package com.djlucasquintana.intelligentdj

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Pure gain curves for two-deck crossfades. Input is clamped to 0..1. */
enum class CrossfadeCurve(val storageKey: String, val label: String) {
    LINEAR("LINEAR", "LINEAL"),
    EQUAL_POWER("EQUAL_POWER", "POTENCIA"),
    SMOOTH("SMOOTH", "SUAVE");

    companion object {
        fun fromStorage(value: String?): CrossfadeCurve = entries.firstOrNull { it.storageKey == value } ?: EQUAL_POWER
    }
}

data class CrossfadeGains(val outgoing: Float, val incoming: Float)

object CrossfadeCurves {
    fun gains(curve: CrossfadeCurve, progress: Float): CrossfadeGains {
        val t = progress.coerceIn(0f, 1f).toDouble()
        val pair = when (curve) {
            CrossfadeCurve.LINEAR -> (1.0 - t) to t
            CrossfadeCurve.EQUAL_POWER -> cos(t * PI / 2.0) to sin(t * PI / 2.0)
            CrossfadeCurve.SMOOTH -> {
                val smooth = t * t * (3.0 - 2.0 * t)
                (1.0 - smooth) to smooth
            }
        }
        return CrossfadeGains(pair.first.toFloat().coerceIn(0f, 1f), pair.second.toFloat().coerceIn(0f, 1f))
    }
}
