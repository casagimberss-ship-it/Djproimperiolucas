package com.djlucasquintana.intelligentdj

/** JNI bridge for the native DSP/audio engine scaffold. */
object AudioNative {
    init { System.loadLibrary("intelligent_dj_audio") }
    external fun setMasterGain(gain: Float)
    external fun getMasterGain(): Float
}
