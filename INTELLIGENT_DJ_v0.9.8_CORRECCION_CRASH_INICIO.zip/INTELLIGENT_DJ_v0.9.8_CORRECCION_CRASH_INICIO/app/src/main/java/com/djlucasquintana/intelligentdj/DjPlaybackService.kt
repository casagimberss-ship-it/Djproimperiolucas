package com.djlucasquintana.intelligentdj

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.Context
import android.os.Build
import android.os.IBinder
import android.media.AudioFocusRequest
import android.media.AudioManager
import androidx.core.app.NotificationCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Keeps both mix decks and all independent sampler voices alive beyond MainActivity. */
class DjPlaybackService : Service() {
    private lateinit var audioManager: AudioManager
    private var focusRequest: AudioFocusRequest? = null
    private var resumeAfterTransientLoss = false
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeAfterTransientLoss = false
                pauseAllPlayers()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeAfterTransientLoss = (primaryPlayer?.isPlaying == true || secondaryPlayer?.isPlaying == true || samplerPlayers.any { it.isPlaying })
                pauseAllPlayers()
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                if (resumeAfterTransientLoss) {
                    // Restore only players that were active before a temporary interruption.
                    if (resumePrimary) primaryPlayer?.play()
                    if (resumeSecondary) secondaryPlayer?.play()
                    samplerPlayers.forEachIndexed { index, player -> if (resumeSamplers.getOrNull(index) == true) player.play() }
                    resumeAfterTransientLoss = false
                }
            }
        }
    }
    private var resumePrimary = false
    private var resumeSecondary = false
    private val resumeSamplers = MutableList(4) { false }

    override fun onCreate() {
        super.onCreate()
        instance = this
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        createNotificationChannel()
        // Players may already have been initialized synchronously by MainActivity.
        // This makes service startup idempotent and avoids a race with Activity.onCreate.
        ensurePlayers(applicationContext)
        primaryPlayer?.addListener(notificationListener)
        secondaryPlayer?.addListener(notificationListener)
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> {
                val active = activePlayer()
                if (active?.isPlaying == true) active.pause() else if (requestAudioFocus()) active?.play()
                updateNotification()
            }
            ACTION_STOP -> {
                pauseAllPlayers()
                abandonAudioFocus()
                // Keep the foreground service and player instances alive; only stop audio.
            }
        }
        updateNotification()
        return START_STICKY
    }

    private fun requestAudioFocus(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val request = focusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build())
                .setOnAudioFocusChangeListener(focusListener)
                .setAcceptsDelayedFocusGain(false)
                .setWillPauseWhenDucked(false)
                .build().also { focusRequest = it }
            return audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        @Suppress("DEPRECATION")
        return audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        } else {
            abandonLegacyAudioFocus()
        }
    }

    @Suppress("DEPRECATION")
    private fun abandonLegacyAudioFocus() {
        audioManager.abandonAudioFocus(focusListener)
    }

    private fun pauseAllPlayers() {
        resumePrimary = primaryPlayer?.isPlaying == true
        resumeSecondary = secondaryPlayer?.isPlaying == true
        samplerPlayers.forEachIndexed { index, player -> resumeSamplers[index] = player.isPlaying }
        primaryPlayer?.pause()
        secondaryPlayer?.pause()
        samplerPlayers.forEach { it.pause() }
    }

    private fun activePlayer(): ExoPlayer? =
        if (activeDeck == 0) primaryPlayer else secondaryPlayer

    private val notificationListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = updateNotification()
        override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) = updateNotification()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "INTELLIGENT DJ · Reproducción", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Reproducción continua del set DJ" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun actionPendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, DjPlaybackService::class.java).setAction(action)
        return PendingIntent.getService(
            this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildNotification(): Notification {
        val playing = activePlayer()?.isPlaying == true
        val title = activePlayer()?.currentMediaItem?.mediaMetadata?.title
            ?.toString()?.takeIf { it.isNotBlank() } ?: "INTELLIGENT DJ"
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentIntent = openIntent?.let {
            PendingIntent.getActivity(this, 10, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(if (playing) "Reproduciendo en segundo plano" else "INTELLIGENT DJ · En espera")
            .setContentIntent(contentIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (playing) "Pausar" else "Reproducir",
                actionPendingIntent(ACTION_PLAY_PAUSE, 11)
            )
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", actionPendingIntent(ACTION_STOP, 12))
            .build()
    }

    private fun updateNotification() {
        if (isCreated) {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification())
        }
    }

    private val isCreated: Boolean get() = primaryPlayer != null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        // Release only when the user explicitly stops the playback service.
        primaryPlayer?.removeListener(notificationListener)
        secondaryPlayer?.removeListener(notificationListener)
        primaryPlayer?.release(); primaryPlayer = null
        secondaryPlayer?.release(); secondaryPlayer = null
        samplerPlayers.forEach { it.release() }
        samplerPlayers.clear()
        abandonAudioFocus()
        instance = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY_PAUSE = "com.djlucasquintana.intelligentdj.PLAY_PAUSE"
        const val ACTION_STOP = "com.djlucasquintana.intelligentdj.STOP_PLAYBACK"
        private const val CHANNEL_ID = "intelligent_dj_playback"
        private const val NOTIFICATION_ID = 9501
        @Volatile private var instance: DjPlaybackService? = null
        @Volatile private var activeDeck: Int = 0
        @Volatile var primaryPlayer: ExoPlayer? = null
            private set
        @Volatile var secondaryPlayer: ExoPlayer? = null
            private set
        val samplerPlayers: MutableList<ExoPlayer> = mutableListOf()
        val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

        /**
         * Create the two mix decks and four sampler voices before MainActivity
         * reads the static player references. startForegroundService() schedules
         * Service.onCreate asynchronously, so relying on it here can leave the
         * sampler list empty and crash a cold launch with IndexOutOfBoundsException.
         */
        @Synchronized
        fun ensurePlayers(context: Context) {
            val appContext = context.applicationContext
            val attributes = AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build()

            @androidx.media3.common.util.UnstableApi
            fun buildPlayer(): ExoPlayer = ExoPlayer.Builder(appContext)
                .setWakeMode(C.WAKE_MODE_LOCAL)
                .setAudioAttributes(attributes, false)
                .setHandleAudioBecomingNoisy(true)
                .build()

            if (primaryPlayer == null) primaryPlayer = buildPlayer()
            if (secondaryPlayer == null) secondaryPlayer = buildPlayer()
            while (samplerPlayers.size < 4) samplerPlayers.add(buildPlayer())
        }

        val activeDeckIndex: Int get() = activeDeck
        fun requestAudioFocus(): Boolean = instance?.requestAudioFocus() ?: false
        fun setActiveDeck(index: Int) { activeDeck = if (index == 0) 0 else 1; instance?.updateNotification() }
    }
}
