package com.djlucasquintana.intelligentdj

import android.media.audiofx.Equalizer
import androidx.media3.exoplayer.ExoPlayer

/** Optional device Equalizer bridge. Unsupported effects are ignored without affecting playback. */
object MixAudioEffects {
    private val effects = mutableMapOf<Int, Equalizer>()

    @Synchronized
    fun applyTransitionProfile(player: ExoPlayer, incoming: Boolean, progress: Float, energyDelta: Double?) {
        val session = runCatching { player.audioSessionId }.getOrDefault(0)
        if (session <= 0) return
        val eq = effects[session] ?: runCatching { Equalizer(0, session) }.getOrNull()?.also { effects[session] = it } ?: return
        runCatching {
            eq.enabled = true
            val t = progress.coerceIn(0f, 1f)
            val minLevel = eq.bandLevelRange[0].toInt()
            val maxLevel = eq.bandLevelRange[1].toInt()
            for (band in 0 until eq.numberOfBands.toInt()) {
                val range = eq.getBandFreqRange(band.toShort())
                val centerHz = (range[0].toInt() + range[1].toInt()) / 2 / 1000
                val db = when {
                    centerHz <= 180 -> if (incoming) (-450.0 + 450.0 * t) else (-150.0 - 450.0 * t)
                    centerHz <= 4_000 -> if (incoming) (-120.0 + 120.0 * t) else (-60.0 - 120.0 * t)
                    else -> if (incoming) (-60.0 + 60.0 * t) else (-30.0 - 60.0 * t)
                }
                val energyAdjustment = ((energyDelta ?: 0.0).coerceIn(-0.4, 0.4) * if (incoming) -180.0 else 180.0)
                val level = (db + energyAdjustment).toInt().coerceIn(minLevel, maxLevel).toShort()
                eq.setBandLevel(band.toShort(), level)
            }
        }
    }

    @Synchronized
    fun reset(player: ExoPlayer) {
        val session = runCatching { player.audioSessionId }.getOrDefault(0)
        effects[session]?.let { effect -> runCatching {
            for (band in 0 until effect.numberOfBands.toInt()) effect.setBandLevel(band.toShort(), 0)
        } }
    }
}
