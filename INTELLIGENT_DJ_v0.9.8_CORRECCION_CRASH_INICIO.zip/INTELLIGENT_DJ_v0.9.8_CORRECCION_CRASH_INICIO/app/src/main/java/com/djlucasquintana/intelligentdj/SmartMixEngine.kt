package com.djlucasquintana.intelligentdj

import kotlin.math.abs

/** Metadata produced by the future audio-analysis stage. Null means not analysed yet. */
data class TrackAnalysis(
    val bpm: Double? = null,
    /** Camelot notation, e.g. "8A" or "2B". */
    val camelot: String? = null,
    /** Normalized energy from 0.0 (calm) to 1.0 (intense). */
    val energy: Double? = null,
    /** Estimated first beat position in seconds from the start of the file. */
    val beatOffsetSeconds: Double? = null,
    /** Estimated duration between beats. */
    val beatIntervalSeconds: Double? = null,
    /** Approximate 8-bar phrase duration. */
    val phraseLengthSeconds: Double? = null,
    /** Estimated end of intro / start of main section. */
    val introEndSeconds: Double? = null,
    /** Estimated start of outro, suitable as an automatic transition cue. */
    val outroStartSeconds: Double? = null,
    /** Heuristic confidence from 0.0 to 1.0, not a guaranteed correctness probability. */
    val analysisConfidence: Double? = null,
    /** Full media duration reported by the decoded stream, in seconds. */
    val durationSeconds: Double? = null,
    /** Duration actually decoded and analyzed; equals durationSeconds on a complete pass. */
    val analyzedDurationSeconds: Double? = null,
    /** RMS energy for consecutive five-second buckets across the entire track. */
    val energyTimeline: List<Double> = emptyList(),
    /** Estimated BPM for consecutive thirty-second windows; NaN means no reliable estimate. */
    val bpmTimeline: List<Double> = emptyList(),
)

data class SmartMixSettings(
    val adaptiveBpm: Boolean = true,
    val progressiveEnergy: Boolean = true,
    val preferHarmonicMixing: Boolean = true,
)

/** Deterministic candidate ranking for Smart Automix. It never repeats a track until a cycle ends. */
object SmartMixEngine {
    /** Chooses a gentle opening track; falls back to the first library item when analysis is unavailable. */
    fun selectInitial(analyses: List<TrackAnalysis>): Int? {
        if (analyses.isEmpty()) return null
        val hasEnergy = analyses.any { it.energy != null }
        if (!hasEnergy) return 0
        return analyses.indices.minWithOrNull(
            compareBy<Int> { analyses[it].energy ?: Double.POSITIVE_INFINITY }
                .thenBy { if (analyses[it].bpm != null) 0 else 1 }
                .thenBy { it }
        )
    }

    fun selectNext(
        analyses: List<TrackAnalysis>,
        currentIndex: Int,
        playedIndices: Set<Int>,
        settings: SmartMixSettings = SmartMixSettings(),
    ): Int? {
        if (analyses.size < 2) return null
        val current = analyses.getOrNull(currentIndex)
        var candidates = analyses.indices.filter { it != currentIndex && it !in playedIndices }
        if (candidates.isEmpty()) candidates = analyses.indices.filter { it != currentIndex }
        if (candidates.isEmpty()) return null

        val hasCurrentData = current != null && listOf(current.bpm, current.energy, current.camelot).any { it != null }
        if (!hasCurrentData) {
            return candidates.minByOrNull { (it - currentIndex - 1 + analyses.size).mod(analyses.size) }
        }

        val currentConfidence = (current?.analysisConfidence ?: 0.5).coerceIn(0.0, 1.0)
        val targetEnergy = current?.energy?.let {
            if (settings.progressiveEnergy) (it + 0.06).coerceAtMost(1.0) else it
        }
        val scored = candidates.map { index ->
            val next = analyses[index]
            val confidence = (next.analysisConfidence ?: 0.45).coerceIn(0.0, 1.0)
            var score = confidence * 8.0

            val bpmA = current?.bpm?.takeIf { it in 60.0..200.0 }
            val bpmB = next.bpm?.takeIf { it in 60.0..200.0 }
            if (bpmA != null && bpmB != null && confidence >= 0.25 && currentConfidence >= 0.25) {
                val delta = bpmDistance(bpmA, bpmB)
                // Favor genuinely close tempos; half/double-time relationships receive a modest bonus,
                // but are not treated as exact playback-rate matches.
                val rawDelta = abs(bpmA - bpmB)
                if (settings.adaptiveBpm) {
                    score += (1.0 - (delta / 18.0).coerceAtMost(1.0)) * 34.0
                    if (rawDelta > 18.0 && delta < 2.0) score += 4.0
                    if (delta > 12.0) score -= 12.0
                } else {
                    score += if (delta <= 3.0) 34.0 else -24.0
                }
            } else score -= 5.0

            if (settings.preferHarmonicMixing && current?.camelot != null && next.camelot != null && confidence >= 0.25) {
                score += camelotScore(current.camelot, next.camelot) * (0.65 + confidence * 0.35)
            } else if (settings.preferHarmonicMixing) score -= 3.0

            if (targetEnergy != null && next.energy != null) {
                val difference = next.energy - targetEnergy
                score += 28.0 - abs(difference) * if (settings.progressiveEnergy) 42.0 else 34.0
                if (settings.progressiveEnergy && difference < -0.08) score -= 14.0
                if (settings.progressiveEnergy && difference > 0.22) score -= 8.0
            } else if (settings.progressiveEnergy) score -= 4.0

            // Prefer a candidate with a usable intro for phrase-aware incoming transitions.
            val intro = next.introEndSeconds
            if (intro != null && intro in 4.0..50.0) score += 7.0
            else if (intro != null && intro > 75.0) score -= 5.0

            // Similar phrase lengths make beat/phrase alignment more predictable.
            val phraseA = current?.phraseLengthSeconds?.takeIf { it > 0.0 }
            val phraseB = next.phraseLengthSeconds?.takeIf { it > 0.0 }
            if (phraseA != null && phraseB != null) {
                val ratio = maxOf(phraseA, phraseB) / minOf(phraseA, phraseB)
                score += (1.0 - (ratio - 1.0).coerceAtMost(1.0)) * 6.0
            }
            score to index
        }
        return scored.maxWithOrNull(compareBy<Pair<Double, Int>> { it.first }
            .thenBy { -((it.second - currentIndex - 1 + analyses.size).mod(analyses.size)) })?.second
    }

    private fun bpmDistance(a: Double, b: Double): Double {
        if (a <= 0.0 || b <= 0.0) return 1_000.0
        val ratios = listOf(0.5, 1.0, 2.0)
        return ratios.minOf { ratio -> abs(a - b * ratio) }
    }

    private fun camelotScore(a: String, b: String): Double {
        val first = parseCamelot(a) ?: return 0.0
        val second = parseCamelot(b) ?: return 0.0
        val (numberA, letterA) = first
        val (numberB, letterB) = second
        return when {
            numberA == numberB && letterA == letterB -> 40.0
            numberA == numberB && letterA != letterB -> 32.0
            letterA == letterB && (numberA - numberB).mod(12) in setOf(1, 11) -> 30.0
            else -> -abs(numberA - numberB).coerceAtMost(6) * 2.0
        }
    }

    private fun parseCamelot(value: String): Pair<Int, Char>? {
        val normalized = value.trim().uppercase()
        if (normalized.length !in 2..3) return null
        val letter = normalized.last()
        val number = normalized.dropLast(1).toIntOrNull() ?: return null
        if (number !in 1..12 || letter !in setOf('A', 'B')) return null
        return number to letter
    }
}
