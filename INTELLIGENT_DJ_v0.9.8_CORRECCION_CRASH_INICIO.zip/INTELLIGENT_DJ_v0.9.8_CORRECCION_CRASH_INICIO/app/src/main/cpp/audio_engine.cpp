#include <jni.h>
#include <atomic>
#include <cstdint>

// Initial native audio core scaffold. Production low-latency mixing will use
// one output stream (Oboe) with Deck A + Deck B + sampler buses summed to master.
static std::atomic<float> master_gain{1.0f};

extern "C" JNIEXPORT void JNICALL
Java_com_djlucasquintana_intelligentdj_AudioNative_setMasterGain(JNIEnv*, jclass, jfloat gain) {
    if (gain < 0.0f) gain = 0.0f;
    if (gain > 1.5f) gain = 1.5f;
    master_gain.store(gain, std::memory_order_relaxed);
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_djlucasquintana_intelligentdj_AudioNative_getMasterGain(JNIEnv*, jclass) {
    return master_gain.load(std::memory_order_relaxed);
}
