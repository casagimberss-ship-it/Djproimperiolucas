# INTELLIGENT DJ by Dj Lucas Quintana

Proyecto Android — versión 0.2.0. Mínimo Android 8.1 (API 27).

## Incluido en esta base
- Proyecto Gradle Kotlin DSL con Android Gradle Plugin 8.7.3 y Kotlin 2.0.21.
- Interfaz Jetpack Compose con reproductor inicial, cuatro pads visuales, panel de grabación y biblioteca.
- Selector de carpeta mediante Storage Access Framework y listado de archivos de audio compatibles.
- Reproducción básica de una pista seleccionada mediante AndroidX Media3 ExoPlayer.
- Primer motor SmartMix determinista: selección sin repetición dentro del ciclo, compatibilidad Camelot, distancia BPM adaptativa y progresión de energía cuando esos metadatos estén disponibles.
- Configuración inicial aprobada: Smart automático, BPM adaptativo y energía progresiva.
- Módulo C++ inicial y CMake con puente JNI de ganancia master.
- GitHub Actions para compilar `app-debug.apk` y publicarlo como artifact.

## Compilar localmente
Requisitos: Android Studio reciente, JDK 17, Android SDK Platform 35, Build Tools y CMake 3.22.1.

```bash
gradle :app:assembleDebug
```

El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar en GitHub
El workflow configura Gradle 8.9 mediante `gradle/actions/setup-gradle@v4` y ejecuta `gradle :app:assembleDebug`; por eso **no exige `gradlew` ni `gradle-wrapper.jar`**. Esto evita el error `gradlew is missing` del workflow anterior.

1. Crear un repositorio vacío y subir todo el contenido de esta carpeta.
2. Abrir **Actions** y ejecutar **Android APK Build** (o hacer push a `main`).
3. Descargar el artifact `intelligent-dj-debug-apk` del workflow terminado.

## Arquitectura prevista
- UI: Kotlin + Jetpack Compose.
- Biblioteca: SAF ahora; Room para persistir catálogo y análisis en siguiente iteración.
- Reproducción inicial: Media3/ExoPlayer para validar biblioteca y flujo de reproducción.
- Motor DJ final: salida PCM única con dos decks, samplers y master; migración a Oboe para baja latencia. No abrir un stream por deck.
- Análisis: BPM, beatgrid, key/Camelot, energía, loudness e intro/outro, persistidos localmente.
- Automix Smart: puntaje de compatibilidad armónica, BPM, energía y estructura; seleccionar desde toda la biblioteca evitando repeticiones.
- Grabación: capturar el bus Master PCM interno y codificar MP3 CBR 320 kbps; nunca usar micrófono.

## Estado honesto de esta versión
La app permite elegir una carpeta y enumera/reproduce pistas. El botón de siguiente pista ya utiliza el selector SmartMix y evita repetir pistas hasta agotar el ciclo. La base del algoritmo puntúa BPM, Camelot y energía cuando esos metadatos están disponibles; actualmente la importación no calcula todavía esos valores, por lo que las pistas sin análisis usan un avance secuencial de respaldo. BPM/Key/Camelot automáticos, persistencia Room, mezcla de dos decks, pads editables y grabación MP3 siguen pendientes. El C++ actual es solo un esqueleto JNI, no un mezclador profesional. Probar el APK en dispositivos reales antes de usarlo en sonido profesional.

## Próximas etapas
1. Room + escaneo recursivo + persistencia SAF.
2. Analizador BPM/beatgrid y estimador key/Camelot/energía.
3. Integrar los resultados del análisis al selector SmartMix.
4. Motor PCM/Oboe con Deck A/B, crossfader, EQ y transiciones Smart.
5. Cuatro samplers configurables.
6. Grabador interno MP3 320 kbps y pruebas de estabilidad.

## Licencias
Revisar licencias de cualquier biblioteca/codec incorporado antes de distribuir una versión comercial. Esta base no incorpora Essentia ni LAME.
