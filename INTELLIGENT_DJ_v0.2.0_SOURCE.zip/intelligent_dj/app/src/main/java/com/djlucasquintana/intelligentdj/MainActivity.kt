package com.djlucasquintana.intelligentdj

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

private val Bg = Color(0xFF090D16)
private val Panel = Color(0xFF141C2B)
private val Accent = Color(0xFF19D3C5)
private val Muted = Color(0xFF9AA8BC)

data class Track(val name: String, val uri: Uri, val analysis: TrackAnalysis = TrackAnalysis())

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val tracks = DocumentFile.fromTreeUri(this, uri)?.listFiles()
                ?.filter { it.isFile && (it.name?.substringAfterLast('.', "")?.lowercase() in setOf("mp3", "wav", "m4a", "flac", "ogg", "aac")) }
                ?.map { Track(it.name ?: "Audio", it.uri) }.orEmpty()
            onTracksLoaded(tracks)
        }
    }
    private var trackCallback: ((List<Track>) -> Unit)? = null
    private fun onTracksLoaded(tracks: List<Track>) { trackCallback?.invoke(tracks) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            var tracks by remember { mutableStateOf(emptyList<Track>()) }
            var current by remember { mutableIntStateOf(0) }
            var playing by remember { mutableStateOf(false) }
            var playedIndices by remember { mutableStateOf(setOf<Int>()) }
            var folderLabel by remember { mutableStateOf("Ninguna carpeta seleccionada") }
            trackCallback = { loaded -> tracks = loaded; current = 0; playedIndices = emptySet(); folderLabel = "${loaded.size} pistas encontradas" }
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item {
                            Column {
                                Text("INTELLIGENT DJ", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                Text("by Dj Lucas Quintana", color = Accent, style = MaterialTheme.typography.labelLarge)
                                Text("SMART AUTOMIX • ANDROID", color = Muted, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        item {
                            PanelCard("REPRODUCTOR") {
                                Text(if (tracks.isNotEmpty()) tracks.getOrNull(current)?.name ?: "Sin pista" else "Cargá tu música para comenzar", color = Color.White, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    InfoPill("BPM", tracks.getOrNull(current)?.analysis?.bpm?.toInt()?.toString() ?: "--")
                                    InfoPill("KEY", "--")
                                    InfoPill("CAMELOT", tracks.getOrNull(current)?.analysis?.camelot ?: "--")
                                    InfoPill("MATCH", if (tracks.size > 1) "Smart" else "Pendiente")
                                }
                                Spacer(Modifier.height(12.dp))
                                LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { if (tracks.isNotEmpty()) { if (playing) player?.pause() else { if (player?.mediaItemCount == 0) player?.setMediaItem(MediaItem.fromUri(tracks[current].uri)); player?.prepare(); player?.play() }; playing = !playing } }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Accent) }
                                    IconButton(onClick = {
                                        if (tracks.size > 1) {
                                            val analyses = tracks.map { it.analysis }
                                            val next = SmartMixEngine.selectNext(analyses, current, playedIndices)
                                            if (next != null) {
                                                playedIndices = playedIndices + current
                                                current = next
                                                player?.setMediaItem(MediaItem.fromUri(tracks[current].uri))
                                                player?.prepare()
                                                player?.play()
                                                playing = true
                                            }
                                        }
                                    }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                                }
                                Text("SMART • BPM ADAPTIVE • ENERGÍA PROGRESSIVE", color = Accent, style = MaterialTheme.typography.labelSmall)
                                Text("Selección inteligente inicial activa. El análisis BPM/KEY automático llegará en la siguiente subetapa.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        item {
                            PanelCard("SAMPLERS • 4 PADS") {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("PAD 1", "PAD 2", "PAD 3", "PAD 4").forEach { label ->
                                        Button(onClick = {}, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 16.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF26364B))) { Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall) }
                                    }
                                }
                                Text("Pads editables: próxima etapa", color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        item {
                            PanelCard("GRABACIÓN DEL SET") {
                                Text("MP3 • 320 kbps • captura interna", color = Color.White)
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) { Text("GRABACIÓN — PRÓXIMAMENTE") }
                                Text("La grabación tomará la mezcla interna; no usará el micrófono.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        item {
                            PanelCard("BIBLIOTECA") {
                                Button(onClick = { folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("SELECCIONAR CARPETA DE MÚSICA")
                                }
                                Text(folderLabel, color = Muted, style = MaterialTheme.typography.bodySmall)
                                Text("${tracks.size} pistas", color = Accent, fontWeight = FontWeight.Bold)
                            }
                        }
                        items(tracks) { track ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                                Text(track.name, color = Color.White, modifier = Modifier.fillMaxWidth().padding(12.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}

@Composable private fun PanelCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = {
            Text(title, color = Accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            content()
        })
    }
}

@Composable private fun InfoPill(label: String, value: String) {
    Column(Modifier.background(Color(0xFF202C40), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) {
        Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
    }
}
