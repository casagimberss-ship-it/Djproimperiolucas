package com.djlucasquintana.intelligentdj

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlin.math.*

/** Full-file analyzer. Decodes the complete selected audio stream at 8 kHz mono. */
object AudioAnalyzer {
    private const val ANALYSIS_RATE = 8_000
    private const val ENERGY_BUCKET_SECONDS = 5
    private const val BEAT_WINDOW_SECONDS = 30

    suspend fun analyze(context: Context, uri: Uri): TrackAnalysis = withContext(Dispatchers.IO) {
        try {
            val decoded = decodeEntireTrack(context, uri)
            currentCoroutineContext().ensureActive()
            analyzeSamples(decoded, decoded.size.toDouble() / ANALYSIS_RATE)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            TrackAnalysis()
        }
    }

    /** No 75-second cutoff: reads MediaExtractor until BUFFER_FLAG_END_OF_STREAM. */
    private suspend fun decodeEntireTrack(context: Context, uri: Uri): FloatArray {
        val coroutineContext = currentCoroutineContext()
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        val samples = FloatAccumulator()
        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("No se encontró una pista de audio")
            extractor.selectTrack(trackIndex)
            val inputFormat = extractor.getTrackFormat(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: error("Formato de audio desconocido")
            var sourceRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var outputRate = sourceRate
            var outputChannels = channels
            var sourceFrameIndex = 0L
            var idleLoops = 0
            var decodeIterations = 0
            while (!outputDone) {
                if (decodeIterations++ % 32 == 0) coroutineContext.ensureActive()
                var madeProgress = false
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val input = codec.getInputBuffer(inputIndex) ?: error("Input buffer no disponible")
                        input.clear()
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                        madeProgress = true
                    }
                }
                val outputIndex = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val out = codec.outputFormat
                        outputRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        outputChannels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        madeProgress = true
                    }
                    outputIndex >= 0 -> {
                        val buffer = codec.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val encoding = if (codec.outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) codec.outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
                            if (encoding == 4) {
                                val pcm = buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
                                while (pcm.remaining() >= outputChannels) {
                                    var mono = 0f
                                    repeat(outputChannels) { mono += pcm.get() }
                                    mono /= outputChannels
                                    if (sourceFrameIndex * ANALYSIS_RATE / outputRate <= samples.size.toLong()) {
                                        val targetIndex = sourceFrameIndex * ANALYSIS_RATE / outputRate
                                        if (targetIndex == samples.size.toLong()) samples.add(mono.coerceIn(-1f, 1f))
                                    }
                                    sourceFrameIndex++
                                }
                            } else {
                                buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN)
                                while (buffer.remaining() >= outputChannels * 2) {
                                    var mono = 0f
                                    repeat(outputChannels) { mono += buffer.short / 32768f }
                                    mono /= outputChannels
                                    val targetIndex = sourceFrameIndex * ANALYSIS_RATE / outputRate
                                    if (targetIndex == samples.size.toLong()) samples.add(mono.coerceIn(-1f, 1f))
                                    sourceFrameIndex++
                                }
                            }
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                        madeProgress = true
                    }
                }
                idleLoops = if (madeProgress) 0 else idleLoops + 1
                if (idleLoops > 500) error("El decodificador no avanzó")
            }
            return samples.toArray()
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            extractor.release()
        }
    }

    private class FloatAccumulator {
        private var data = FloatArray(ANALYSIS_RATE * 60)
        var size: Int = 0
            private set
        fun add(value: Float) {
            if (size == data.size) data = data.copyOf(data.size * 2)
            data[size++] = value
        }
        fun toArray(): FloatArray = data.copyOf(size)
    }

    private fun analyzeSamples(samples: FloatArray, duration: Double): TrackAnalysis {
        if (samples.size < ANALYSIS_RATE * 8) return TrackAnalysis(durationSeconds = duration, analyzedDurationSeconds = duration)
        val bucketSize = ANALYSIS_RATE * ENERGY_BUCKET_SECONDS
        val energyTimeline = ArrayList<Double>()
        var start = 0
        while (start < samples.size) {
            val end = min(samples.size, start + bucketSize)
            var sum = 0.0
            for (i in start until end) sum += samples[i] * samples[i]
            energyTimeline.add(sqrt(sum / (end - start)).coerceIn(0.0, 1.0))
            start = end
        }
        val meanEnergy = energyTimeline.average()
        val globalEnergy = (meanEnergy * 12.0).coerceIn(0.0, 1.0)

        // Analyze tempo in successive 30-second windows across the entire file.
        val bpmTimeline = ArrayList<Double>()
        val beatConfidences = ArrayList<Double>()
        var windowStart = 0
        val windowSize = ANALYSIS_RATE * BEAT_WINDOW_SECONDS
        while (windowStart < samples.size) {
            val windowEnd = min(samples.size, windowStart + windowSize)
            if (windowEnd - windowStart >= ANALYSIS_RATE * 8) {
                val local = samples.copyOfRange(windowStart, windowEnd)
                val estimate = estimateBeatGrid(local)
                bpmTimeline.add(estimate?.bpm ?: Double.NaN)
                estimate?.let { beatConfidences.add(it.confidence) }
            }
            windowStart += windowSize
        }
        val validBpms = bpmTimeline.filter { it.isFinite() }
        val bpm = validBpms.takeIf { it.isNotEmpty() }?.median()
        val beat = samples.copyOfRange(0, min(samples.size, windowSize)).let(::estimateBeatGrid)
        val camelot = estimateCamelot(samples)
        val structure = estimateStructure(energyTimeline, duration)
        val confidence = listOfNotNull(
            beatConfidences.takeIf { it.isNotEmpty() }?.average(),
            if (camelot != null) 0.55 else null,
            structure.confidence,
            if (validBpms.size > 1 && bpm != null) (1.0 - (validBpms.maxOrNull()!! - validBpms.minOrNull()!!) / bpm).coerceIn(0.0, 1.0) else null
        ).average().takeIf { it.isFinite() }?.coerceIn(0.0, 1.0)

        return TrackAnalysis(
            bpm = bpm,
            camelot = camelot,
            energy = globalEnergy,
            beatOffsetSeconds = beat?.offsetSeconds,
            beatIntervalSeconds = bpm?.let { 60.0 / it },
            phraseLengthSeconds = bpm?.let { 1920.0 / it },
            introEndSeconds = structure.introEndSeconds,
            outroStartSeconds = structure.outroStartSeconds,
            analysisConfidence = confidence,
            durationSeconds = duration,
            analyzedDurationSeconds = duration,
            energyTimeline = energyTimeline,
            bpmTimeline = bpmTimeline,
        )
    }

    private data class BeatEstimate(val bpm: Double, val offsetSeconds: Double, val confidence: Double)
    private fun estimateBeatGrid(samples: FloatArray): BeatEstimate? {
        val hop = 256
        val frame = 1024
        val rms = ArrayList<Double>()
        var p = 0
        while (p + frame < samples.size) {
            var sum = 0.0
            for (i in p until p + frame) sum += samples[i] * samples[i]
            rms.add(sqrt(sum / frame))
            p += hop
        }
        if (rms.size < 100) return null
        val onset = DoubleArray(rms.size) { i -> if (i == 0) 0.0 else max(0.0, rms[i] - rms[i - 1]) }
        val minLag = (60.0 * ANALYSIS_RATE / hop / 180.0).roundToInt()
        val maxLag = (60.0 * ANALYSIS_RATE / hop / 65.0).roundToInt()
        var bestLag = -1
        var best = 0.0
        for (lag in minLag..maxLag) {
            var score = 0.0
            for (i in lag until onset.size) score += onset[i] * onset[i - lag]
            val candidateBpm = 60.0 * ANALYSIS_RATE / (hop * lag)
            val weighted = score * if (candidateBpm in 85.0..155.0) 1.08 else 1.0
            if (weighted > best) { best = weighted; bestLag = lag }
        }
        if (bestLag < 0 || best <= 1e-9) return null
        val bpm = 60.0 * ANALYSIS_RATE / (hop * bestLag)
        val phaseScores = DoubleArray(bestLag)
        for (phase in 0 until bestLag) {
            var i = phase
            while (i < onset.size) { phaseScores[phase] += onset[i]; i += bestLag }
        }
        val phase = phaseScores.indices.maxByOrNull { phaseScores[it] } ?: 0
        val sorted = phaseScores.sortedDescending()
        val phaseConfidence = if (sorted.first() > 0.0) ((sorted.first() - (sorted.getOrNull(1) ?: 0.0)) / sorted.first()).coerceIn(0.0, 1.0) else 0.0
        return BeatEstimate(bpm, phase.toDouble() * hop / ANALYSIS_RATE, (0.35 + phaseConfidence * 0.55).coerceIn(0.0, 1.0))
    }

    private data class StructureEstimate(val introEndSeconds: Double?, val outroStartSeconds: Double?, val confidence: Double)
    private fun estimateStructure(energy: List<Double>, duration: Double): StructureEstimate {
        if (energy.size < 8 || duration < 20.0) return StructureEstimate(null, null, 0.0)
        val sorted = energy.sorted()
        val low = sorted[(sorted.size * 0.2).toInt().coerceIn(0, sorted.lastIndex)]
        val high = sorted[(sorted.size * 0.75).toInt().coerceIn(0, sorted.lastIndex)]
        val threshold = low + (high - low) * 0.38
        val introIndex = (1 until min(energy.size - 2, 36)).firstOrNull { i -> energy.subList(i, min(energy.size, i + 3)).count { it >= threshold } >= 2 }
        val outroIndex = (energy.size - 1 downTo max(0, energy.size * 55 / 100)).firstOrNull { i -> energy[i] < threshold }
        val intro = introIndex?.times(ENERGY_BUCKET_SECONDS.toDouble())?.coerceAtMost(duration * 0.4)
        val outro = outroIndex?.times(ENERGY_BUCKET_SECONDS.toDouble())?.coerceAtLeast(duration * 0.55)
        val confidence = if (high > 1e-6) ((high - low) / high).coerceIn(0.0, 1.0) * 0.65 else 0.0
        return StructureEstimate(intro, outro, confidence)
    }

    /** Samples chroma windows distributed from beginning to end, not just the intro. */
    private fun estimateCamelot(samples: FloatArray): String? {
        val chroma = DoubleArray(12)
        val frame = 2048
        val maxWindows = 240
        val possible = max(1, (samples.size - frame) / (ANALYSIS_RATE * 2))
        val windows = min(maxWindows, possible)
        var used = 0
        for (w in 0 until windows) {
            val start = if (windows <= 1) 0 else ((samples.size - frame).toLong() * w / (windows - 1)).toInt()
            for (pitch in 0..11) {
                var energy = 0.0
                for (octave in 2..5) {
                    val frequency = 440.0 * 2.0.pow((pitch - 9) / 12.0 + octave - 4)
                    if (frequency >= 45 && frequency < ANALYSIS_RATE / 2.0) energy += goertzel(samples, start, frame, frequency)
                }
                chroma[pitch] += energy
            }
            used++
        }
        if (used == 0 || (chroma.maxOrNull() ?: 0.0) <= 1e-10) return null
        val major = doubleArrayOf(6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88)
        val minor = doubleArrayOf(6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17)
        val majorMap = intArrayOf(8,3,10,5,12,7,2,9,4,11,6,1)
        val minorMap = intArrayOf(5,12,7,2,9,4,11,6,1,8,3,10)
        var best = Double.NEGATIVE_INFINITY
        var result: String? = null
        for (root in 0..11) for (isMajor in listOf(true, false)) {
            val rotated = DoubleArray(12) { chroma[(it + root) % 12] }
            val score = correlation(rotated, if (isMajor) major else minor)
            if (score > best) { best = score; result = "${if (isMajor) majorMap[root] else minorMap[root]}${if (isMajor) "B" else "A"}" }
        }
        return result
    }

    private fun correlation(a: DoubleArray, b: DoubleArray): Double {
        val ma = a.average(); val mb = b.average()
        var n = 0.0; var da = 0.0; var db = 0.0
        for (i in a.indices) { val x = a[i] - ma; val y = b[i] - mb; n += x*y; da += x*x; db += y*y }
        return n / (sqrt(da * db) + 1e-12)
    }
    private fun goertzel(samples: FloatArray, start: Int, size: Int, frequency: Double): Double {
        val omega = 2.0 * Math.PI * frequency / ANALYSIS_RATE
        val coeff = 2.0 * cos(omega)
        var q1 = 0.0; var q2 = 0.0
        for (i in 0 until size) {
            val window = 0.5 - 0.5 * cos(2.0 * Math.PI * i / (size - 1))
            val q0 = coeff * q1 - q2 + samples[start + i] * window
            q2 = q1; q1 = q0
        }
        return q1*q1 + q2*q2 - coeff*q1*q2
    }

    private fun List<Double>.median(): Double = sorted().let { values ->
        if (values.size % 2 == 1) values[values.size / 2] else (values[values.size / 2 - 1] + values[values.size / 2]) / 2.0
    }
}
