# INTELLIGENT DJ v1.4.2 – Smart Transition Engine

Proyecto Android completo. Cambios centrados en la transición manual NEXT MIX: inicio inmediato sin espera de frase, BPM adaptativo y crossfade progresivo de hasta 9 segundos.

Ver `LEEME_v1.4.2_SMART_TRANSITION_ENGINE.txt` para notas y plan de pruebas.
