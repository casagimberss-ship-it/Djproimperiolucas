# INTELLIGENT DJ v1.0.0 — Audio profesional

Base funcional declarada por el usuario: v0.9.9 Smart Mix Precision.

Esta versión refuerza el ciclo de vida de la grabación interna Android (MediaProjection + AudioRecord)
y el cierre del codificador MP3 LAME, manteniendo las funciones previas del motor Smart Mix,
la reproducción persistente, biblioteca Room y sampler independiente.

- `versionCode`: 26
- `versionName`: 1.0.0
- `compileSdk`: 35
- `minSdk`: 27
- `Gradle`: 8.9 (configurado en GitHub Actions)

Ver `LEEME_v1.0.0_AUDIO_PROFESIONAL.txt` para cambios y pruebas.

**Estado:** paquete fuente preparado; compilación CI y pruebas reales de grabación pendientes.


## v1.2.0 – Interfaz profesional
Versión de interfaz con progreso real del deck activo y tiempos transcurrido/total. Ver `LEEME_v1.2.0_INTERFAZ_PROFESIONAL.txt`.
