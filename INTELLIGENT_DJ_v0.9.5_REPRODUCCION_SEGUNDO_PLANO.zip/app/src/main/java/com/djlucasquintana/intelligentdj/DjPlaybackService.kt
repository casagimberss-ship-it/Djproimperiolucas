package com.djlucasquintana.intelligentdj

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Keeps both mix decks and all independent sampler voices alive beyond MainActivity. */
class DjPlaybackService : Service() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
        if (primaryPlayer == null) {
            val attributes = AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build()
            @androidx.media3.common.util.UnstableApi
            fun buildPlayer(): ExoPlayer = ExoPlayer.Builder(applicationContext)
                .setWakeMode(C.WAKE_MODE_LOCAL)
                .setAudioAttributes(attributes, true) // ExoPlayer manages audio focus.
                .setHandleAudioBecomingNoisy(true)
                .build()
            primaryPlayer = buildPlayer()
            secondaryPlayer = buildPlayer()
            repeat(4) { samplerPlayers.add(buildPlayer()) }
            primaryPlayer?.addListener(notificationListener)
            secondaryPlayer?.addListener(notificationListener)
        }
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> {
                val active = activePlayer()
                if (active?.isPlaying == true) active.pause() else active?.play()
                updateNotification()
            }
            ACTION_STOP -> {
                primaryPlayer?.pause()
                secondaryPlayer?.pause()
                // Keep the foreground service and player instances alive; only stop audio.

            }
        }
        updateNotification()
        return START_STICKY
    }

    private fun activePlayer(): ExoPlayer? =
        if (activeDeck == 0) primaryPlayer else secondaryPlayer

    private val notificationListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = updateNotification()
        override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) = updateNotification()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "INTELLIGENT DJ · Reproducción", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Reproducción continua del set DJ" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun actionPendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, DjPlaybackService::class.java).setAction(action)
        return PendingIntent.getService(
            this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildNotification(): Notification {
        val playing = activePlayer()?.isPlaying == true
        val title = activePlayer()?.currentMediaItem?.mediaMetadata?.title
            ?.toString()?.takeIf { it.isNotBlank() } ?: "INTELLIGENT DJ"
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentIntent = openIntent?.let {
            PendingIntent.getActivity(this, 10, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(if (playing) "Reproduciendo en segundo plano" else "INTELLIGENT DJ · En espera")
            .setContentIntent(contentIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (playing) "Pausar" else "Reproducir",
                actionPendingIntent(ACTION_PLAY_PAUSE, 11)
            )
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", actionPendingIntent(ACTION_STOP, 12))
            .build()
    }

    private fun updateNotification() {
        if (isCreated) {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification())
        }
    }

    private val isCreated: Boolean get() = primaryPlayer != null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        // Release only when the user explicitly stops the playback service.
        primaryPlayer?.removeListener(notificationListener)
        secondaryPlayer?.removeListener(notificationListener)
        primaryPlayer?.release(); primaryPlayer = null
        secondaryPlayer?.release(); secondaryPlayer = null
        samplerPlayers.forEach { it.release() }
        samplerPlayers.clear()
        instance = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY_PAUSE = "com.djlucasquintana.intelligentdj.PLAY_PAUSE"
        const val ACTION_STOP = "com.djlucasquintana.intelligentdj.STOP_PLAYBACK"
        private const val CHANNEL_ID = "intelligent_dj_playback"
        private const val NOTIFICATION_ID = 9501
        @Volatile private var instance: DjPlaybackService? = null
        @Volatile private var activeDeck: Int = 0
        @Volatile var primaryPlayer: ExoPlayer? = null
            private set
        @Volatile var secondaryPlayer: ExoPlayer? = null
            private set
        val samplerPlayers: MutableList<ExoPlayer> = mutableListOf()
        val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

        val activeDeckIndex: Int get() = activeDeck
        fun setActiveDeck(index: Int) { activeDeck = if (index == 0) 0 else 1; instance?.updateNotification() }
    }
}
