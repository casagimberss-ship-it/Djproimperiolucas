package com.djlucasquintana.intelligentdj

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.*

/** First on-device PCM analysis pass. Results are estimates and should be validated on real music. */
object AudioAnalyzer {
    suspend fun analyze(context: Context, uri: Uri): TrackAnalysis = withContext(Dispatchers.IO) {
        runCatching { analyzeSamples(decodeMono(context, uri)) }.getOrElse { TrackAnalysis() }
    }

    private fun decodeMono(context: Context, uri: Uri): FloatArray {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: return FloatArray(0)
            extractor.selectTrack(trackIndex)
            val format = extractor.getTrackFormat(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return FloatArray(0)
            val sourceRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()
            val output = ArrayList<Float>(sourceRate * 45)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var outputRate = sourceRate
            var outputChannels = channels
            var frameCounter = 0L
            val maxFrames = sourceRate.toLong() * 75L
            while (!outputDone && output.size < 11025 * 75) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val input = codec.getInputBuffer(inputIndex)!!
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outputIndex = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val outFormat = codec.outputFormat
                        outputRate = outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        outputChannels = outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    outputIndex >= 0 -> {
                        val buffer = codec.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val encoding = if (codec.outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) codec.outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
                            if (encoding == 4) {
                                val pcm = buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
                                while (pcm.remaining() >= outputChannels && output.size < 11025 * 75) {
                                    var mono = 0f
                                    repeat(outputChannels) { mono += pcm.get() }
                                    mono /= outputChannels
                                    frameCounter++
                                    if (frameCounter * 11025L / outputRate > output.size) output.add(mono.coerceIn(-1f, 1f))
                                }
                            } else {
                                buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN)
                                while (buffer.remaining() >= outputChannels * 2 && output.size < 11025 * 75) {
                                    var mono = 0f
                                    repeat(outputChannels) { mono += buffer.short / 32768f }
                                    mono /= outputChannels
                                    frameCounter++
                                    if (frameCounter * 11025L / outputRate > output.size) output.add(mono.coerceIn(-1f, 1f))
                                }
                            }
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
            return output.toFloatArray()
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            extractor.release()
        }
    }

    private fun analyzeSamples(samples: FloatArray): TrackAnalysis {
        if (samples.size < 11025 * 8) return TrackAnalysis()
        val rate = 11025
        val hop = 256
        val rms = ArrayList<Double>()
        var pos = 0
        while (pos + 1024 < samples.size) {
            var sum = 0.0
            for (i in pos until pos + 1024) sum += samples[i] * samples[i]
            rms.add(sqrt(sum / 1024.0))
            pos += hop
        }
        if (rms.size < 100) return TrackAnalysis()
        val mean = rms.average()
        val energy = (mean * 12.0).coerceIn(0.0, 1.0)
        val onset = DoubleArray(rms.size) { i -> if (i == 0) 0.0 else max(0.0, rms[i] - rms[i - 1]) }
        val bpm = estimateBpm(onset, rate, hop)
        val key = estimateCamelot(samples, rate)
        return TrackAnalysis(bpm = bpm, camelot = key, energy = energy)
    }

    private fun estimateBpm(onset: DoubleArray, sampleRate: Int, hop: Int): Double? {
        val minLag = (60.0 * sampleRate / hop / 180.0).roundToInt()
        val maxLag = (60.0 * sampleRate / hop / 65.0).roundToInt()
        var bestLag = -1
        var best = 0.0
        for (lag in minLag..maxLag) {
            var score = 0.0
            for (i in lag until onset.size) score += onset[i] * onset[i - lag]
            // Half/double tempo ambiguity is resolved toward common DJ tempos.
            val bpm = 60.0 * sampleRate / (hop * lag)
            val weighted = score * if (bpm in 85.0..155.0) 1.08 else 1.0
            if (weighted > best) { best = weighted; bestLag = lag }
        }
        if (bestLag < 0 || best <= 1e-9) return null
        return (60.0 * sampleRate / (hop * bestLag)).coerceIn(60.0, 180.0)
    }

    private fun estimateCamelot(samples: FloatArray, sampleRate: Int): String? {
        val chroma = DoubleArray(12)
        val frame = 4096
        val stride = 8192
        var frames = 0
        var start = 0
        while (start + frame < samples.size && frames < 24) {
            for (pitch in 0..11) {
                var energy = 0.0
                for (octave in 2..6) {
                    val frequency = 440.0 * 2.0.pow((pitch - 9) / 12.0 + octave - 4)
                    if (frequency >= 45 && frequency < sampleRate / 2.0) energy += goertzel(samples, start, frame, sampleRate, frequency)
                }
                chroma[pitch] += energy
            }
            frames++
            start += stride
        }
        if (frames == 0 || (chroma.maxOrNull() ?: 0.0) <= 1e-10) return null
        val major = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
        val minor = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)
        val camelotMajor = intArrayOf(8, 3, 10, 5, 12, 7, 2, 9, 4, 11, 6, 1) // C..B
        val camelotMinor = intArrayOf(5, 12, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10) // C..B
        var bestScore = Double.NEGATIVE_INFINITY
        var result: String? = null
        for (root in 0..11) {
            val rotated = DoubleArray(12) { chroma[(it + root) % 12] }
            for (isMajor in listOf(true, false)) {
                val profile = if (isMajor) major else minor
                val score = correlation(rotated, profile)
                if (score > bestScore) {
                    bestScore = score
                    result = "${if (isMajor) camelotMajor[root] else camelotMinor[root]}${if (isMajor) "B" else "A"}"
                }
            }
        }
        return result
    }

    private fun correlation(a: DoubleArray, b: DoubleArray): Double {
        val ma = a.average(); val mb = b.average()
        var numerator = 0.0; var da = 0.0; var db = 0.0
        for (i in a.indices) { val x = a[i] - ma; val y = b[i] - mb; numerator += x * y; da += x * x; db += y * y }
        return numerator / (sqrt(da * db) + 1e-12)
    }

    private fun goertzel(samples: FloatArray, start: Int, size: Int, sampleRate: Int, frequency: Double): Double {
        val omega = 2.0 * Math.PI * frequency / sampleRate
        val coeff = 2.0 * cos(omega)
        var q0: Double; var q1 = 0.0; var q2 = 0.0
        for (i in 0 until size) {
            val window = 0.5 - 0.5 * cos(2.0 * Math.PI * i / (size - 1))
            q0 = coeff * q1 - q2 + samples[start + i] * window
            q2 = q1; q1 = q0
        }
        return q1 * q1 + q2 * q2 - coeff * q1 * q2
    }
}
