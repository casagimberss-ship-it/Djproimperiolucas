package com.djlucasquintana.intelligentdj

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioPlaybackCaptureConfiguration
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import java.io.OutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/** Captura de reproducción interna Android 10+ y codificación MP3 CBR 320 kbps. */
class SetRecordingService : Service() {
    companion object {
        const val ACTION_START = "com.djlucasquintana.intelligentdj.RECORD_START"
        const val ACTION_STOP = "com.djlucasquintana.intelligentdj.RECORD_STOP"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val EXTRA_OUTPUT_URI = "output_uri"
        const val ACTION_STATUS = "com.djlucasquintana.intelligentdj.RECORD_STATUS"
        const val EXTRA_ACTIVE = "recording_active"
        const val EXTRA_STATUS = "recording_status"
        private const val CHANNEL_ID = "set_recording"
        private const val NOTIFICATION_ID = 320
    }

    private val running = AtomicBoolean(false)
    @Volatile private var audioRecord: AudioRecord? = null
    @Volatile private var projection: MediaProjection? = null
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    stopSelf(); return START_NOT_STICKY
                }
                startAsForeground()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
                }
                val output = intent.getParcelableExtra<Uri>(EXTRA_OUTPUT_URI)
                if (resultData == null || output == null || running.get()) {
                    publishStatus(false, "No se pudo iniciar la grabación")
                    stopSelf(); return START_NOT_STICKY
                }
                startCapture(resultCode, resultData, output)
            }
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Grabación del set", NotificationManager.IMPORTANCE_LOW))
        }
        val stopIntent = Intent(this, SetRecordingService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 321, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("INTELLIGENT DJ")
            .setContentText("Grabando mezcla interna · MP3 320 kbps")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Detener", stopPending)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun publishStatus(active: Boolean, message: String) {
        getSharedPreferences("recording_status", MODE_PRIVATE).edit().putBoolean("active", active).putString("message", message).apply()
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_ACTIVE, active).putExtra(EXTRA_STATUS, message))
    }

    private fun startCapture(resultCode: Int, resultData: Intent, outputUri: Uri) {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = manager.getMediaProjection(resultCode, resultData)
            projection = mp
            val config = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUid(applicationInfo.uid)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build()
            val sampleRate = 44100
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBytes = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBytes <= 0) error("No se pudo reservar el buffer de captura")
            val recorder = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(minBytes * 4)
                .setAudioPlaybackCaptureConfig(config)
                .build()
            if (recorder.state != AudioRecord.STATE_INITIALIZED) error("AudioRecord no pudo inicializar la captura interna")
            audioRecord = recorder
            running.set(true)
            publishStatus(true, "Grabando mezcla interna · MP3 CBR 320 kbps")
            worker = thread(name = "IDJ-MP3-Recorder") { encodeLoop(recorder, outputUri, sampleRate) }
        } catch (t: Throwable) {
            publishStatus(false, "Error al iniciar la captura: ${t.message ?: "fallo de audio"}")
            running.set(false)
            projection?.stop(); projection = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun encodeLoop(recorder: AudioRecord, outputUri: Uri, sampleRate: Int) {
        var output: OutputStream? = null
        var lame: AndroidLame? = null
        var successful = false
        try {
            output = contentResolver.openOutputStream(outputUri, "w") ?: error("No se pudo abrir el archivo de salida")
            lame = LameBuilder()
                .setInSampleRate(sampleRate)
                .setOutSampleRate(sampleRate)
                .setOutChannels(2)
                .setOutBitrate(320)
                .setQuality(2)
                .build()
            val pcm = ShortArray(4096 * 2)
            val mp3 = ByteArray(7200 + pcm.size * 2)
            recorder.startRecording()
            while (running.get()) {
                val read = recorder.read(pcm, 0, pcm.size, AudioRecord.READ_BLOCKING)
                if (read < 0) {
                    if (running.get()) error("AudioRecord read error: $read") else break
                }
                if (read > 0) {
                    val evenSamples = read - (read % 2)
                    val framesPerChannel = evenSamples / 2
                    val encoded = lame.encodeBufferInterleaved(pcm, framesPerChannel, mp3)
                    if (encoded > 0) output.write(mp3, 0, encoded)
                }
            }
            val flushed = lame.lameFlush(mp3)
            if (flushed > 0) output.write(mp3, 0, flushed)
            output.flush()
            successful = true
        } catch (t: Throwable) {
            publishStatus(false, "Error al codificar MP3: ${t.message ?: "fallo de escritura"}")
            // El archivo parcial se conserva para diagnóstico/recuperación.
        } finally {
            running.set(false)
            runCatching { recorder.stop() }
            recorder.release()
            runCatching { lame?.close() }
            runCatching { output?.close() }
            audioRecord = null
            projection?.stop(); projection = null
            if (successful) publishStatus(false, "MP3 320 kbps guardado correctamente")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun stopCapture() {
        running.set(false)
        runCatching { audioRecord?.stop() }
        if (worker == null) {
            projection?.stop(); projection = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        running.set(false)
        runCatching { audioRecord?.stop() }
        projection?.stop(); projection = null
        super.onDestroy()
    }
}
