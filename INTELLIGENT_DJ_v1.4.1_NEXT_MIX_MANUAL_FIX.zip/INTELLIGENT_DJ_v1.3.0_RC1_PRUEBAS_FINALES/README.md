# INTELLIGENT DJ v1.4.1

- versionCode: 31
- versionName: 1.4.1

Corrección de NEXT MIX: botón funcional, selector de pista siguiente y transición manual Echo Out + Crossfade.

Compilar desde GitHub Actions con el workflow incluido.
