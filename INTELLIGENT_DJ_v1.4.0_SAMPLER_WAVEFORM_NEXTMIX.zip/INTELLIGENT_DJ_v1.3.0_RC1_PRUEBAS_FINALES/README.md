# INTELLIGENT DJ v1.4.0

- versionCode: 30
- versionName: 1.4.0
- Base: v1.3.0 RC1

Build Android desde GitHub Actions usando el workflow incluido. Consultar `LEEME_v1.4.0_SAMPLER_WAVEFORM_NEXTMIX.txt` para cambios y pruebas.
