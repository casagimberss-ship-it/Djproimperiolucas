package com.djlucasquintana.intelligentdj

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioPlaybackCaptureConfiguration
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import java.io.OutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/** Captura la salida multimedia interna de la app y la codifica a MP3 estéreo CBR 320 kbps. */
class SetRecordingService : Service() {
    companion object {
        const val ACTION_START = "com.djlucasquintana.intelligentdj.RECORD_START"
        const val ACTION_STOP = "com.djlucasquintana.intelligentdj.RECORD_STOP"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val EXTRA_OUTPUT_URI = "output_uri"
        const val ACTION_STATUS = "com.djlucasquintana.intelligentdj.RECORD_STATUS"
        const val EXTRA_ACTIVE = "recording_active"
        const val EXTRA_STATUS = "recording_status"
        private const val CHANNEL_ID = "set_recording"
        private const val NOTIFICATION_ID = 320
        private const val SAMPLE_RATE = 44100
        private const val CHANNEL_COUNT = 2
    }

    private val running = AtomicBoolean(false)
    @Volatile private var audioRecord: AudioRecord? = null
    @Volatile private var projection: MediaProjection? = null
    @Volatile private var worker: Thread? = null
    @Volatile private var projectionCallback: MediaProjection.Callback? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> {
                if (running.get() || worker?.isAlive == true) {
                    publishStatus(true, "La grabación ya está activa")
                    return START_NOT_STICKY
                }
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    publishStatus(false, "La captura interna requiere Android 10 o superior")
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                startAsForeground()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
                }
                val output = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_OUTPUT_URI, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_OUTPUT_URI) as? Uri
                }
                if (resultData == null || output == null) {
                    publishStatus(false, "Faltan permisos o destino para guardar el MP3")
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                startCapture(resultCode, resultData, output)
            }
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Grabación del set", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopIntent = Intent(this, SetRecordingService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 321, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("INTELLIGENT DJ")
            .setContentText("Preparando grabación MP3 · 320 kbps")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Detener", stopPending)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun publishStatus(active: Boolean, message: String) {
        getSharedPreferences("recording_status", MODE_PRIVATE).edit()
            .putBoolean("active", active).putString("message", message).apply()
        sendBroadcast(
            Intent(ACTION_STATUS).setPackage(packageName)
                .putExtra(EXTRA_ACTIVE, active).putExtra(EXTRA_STATUS, message)
        )
        if (active) {
            getSystemService(NotificationManager::class.java).notify(
                NOTIFICATION_ID,
                NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .setContentTitle("INTELLIGENT DJ")
                    .setContentText(message)
                    .setOngoing(true)
                    .addAction(
                        android.R.drawable.ic_media_pause, "Detener",
                        PendingIntent.getService(
                            this, 321, Intent(this, SetRecordingService::class.java).setAction(ACTION_STOP),
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                    ).build()
            )
        }
    }

    private fun startCapture(resultCode: Int, resultData: Intent, outputUri: Uri) {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mediaProjection = manager.getMediaProjection(resultCode, resultData)
                ?: error("Android no concedió la captura de reproducción")
            projection = mediaProjection

            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    // Android puede revocar la proyección desde el sistema en cualquier momento.
                    running.set(false)
                    runCatching { audioRecord?.stop() }
                    publishStatus(false, "Captura detenida por Android; finalizando archivo…")
                }
            }
            projectionCallback = callback
            mediaProjection.registerCallback(callback, Handler(Looper.getMainLooper()))

            val config = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                .addMatchingUid(applicationInfo.uid)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBytes = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBytes <= 0) error("Android no pudo reservar el buffer de captura ($minBytes)")
            val recorder = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes((minBytes * 4).coerceAtLeast(SAMPLE_RATE * CHANNEL_COUNT))
                .setAudioPlaybackCaptureConfig(config)
                .build()
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                error("AudioRecord no pudo inicializar la captura interna")
            }

            audioRecord = recorder
            running.set(true)
            // Asignar la referencia antes de arrancar el hilo evita una carrera al pulsar STOP.
            val recordingThread = thread(name = "IDJ-MP3-Recorder", start = false) {
                encodeLoop(recorder, outputUri)
            }
            worker = recordingThread
            recordingThread.start()
        } catch (t: Throwable) {
            running.set(false)
            runCatching { audioRecord?.release() }
            audioRecord = null
            releaseProjection()
            publishStatus(false, "Error al iniciar la grabación: ${t.message ?: "fallo de audio"}")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun encodeLoop(recorder: AudioRecord, outputUri: Uri) {
        var output: OutputStream? = null
        var lame: AndroidLame? = null
        var successful = false
        var totalPcmSamples = 0L
        var totalMp3Bytes = 0L
        try {
            output = contentResolver.openOutputStream(outputUri, "w")
                ?: error("No se pudo abrir el archivo de destino")
            lame = LameBuilder()
                .setInSampleRate(SAMPLE_RATE)
                .setOutSampleRate(SAMPLE_RATE)
                .setOutChannels(CHANNEL_COUNT)
                .setOutBitrate(320)
                .setQuality(2)
                .build()

            val pcm = ShortArray(4096 * CHANNEL_COUNT)
            val mp3 = ByteArray(16384)
            recorder.startRecording()
            if (recorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                error("La captura interna no entró en estado de grabación")
            }
            publishStatus(true, "Grabando mezcla interna · MP3 CBR 320 kbps")

            while (running.get()) {
                val read = recorder.read(pcm, 0, pcm.size, AudioRecord.READ_BLOCKING)
                if (read < 0) {
                    if (running.get()) error("Error de lectura de audio: $read") else break
                }
                if (read == 0) continue
                val evenSamples = read - (read % CHANNEL_COUNT)
                if (evenSamples == 0) continue
                totalPcmSamples += evenSamples.toLong()
                val framesPerChannel = evenSamples / CHANNEL_COUNT
                val encoded = lame.encodeBufferInterLeaved(pcm, framesPerChannel, mp3)
                if (encoded < 0) error("El codificador MP3 devolvió un error: $encoded")
                if (encoded > 0) {
                    output.write(mp3, 0, encoded)
                    totalMp3Bytes += encoded.toLong()
                }
            }

            val flushed = lame.flush(mp3)
            if (flushed < 0) error("No se pudo finalizar el flujo MP3: $flushed")
            if (flushed > 0) {
                output.write(mp3, 0, flushed)
                totalMp3Bytes += flushed.toLong()
            }
            output.flush()
            if (totalPcmSamples == 0L || totalMp3Bytes == 0L) {
                error("No se capturó audio. Verificá que haya música reproduciéndose durante la grabación")
            }
            successful = true
        } catch (t: Throwable) {
            publishStatus(false, "Error al guardar MP3: ${t.message ?: "fallo de escritura"}. El archivo puede estar incompleto")
        } finally {
            running.set(false)
            runCatching { if (recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) recorder.stop() }
            runCatching { recorder.release() }
            runCatching { lame?.close() }
            runCatching { output?.flush() }
            runCatching { output?.close() }
            audioRecord = null
            releaseProjection()
            worker = null
            if (successful) {
                val seconds = totalPcmSamples / (SAMPLE_RATE.toLong() * CHANNEL_COUNT)
                publishStatus(false, "MP3 guardado · 320 kbps CBR estéreo · ${seconds}s · ${totalMp3Bytes / 1024} KB")
            }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun stopCapture() {
        running.set(false)
        val recorder = audioRecord
        if (recorder != null) {
            // stop() desbloquea AudioRecord.read(); el hilo finaliza LAME y cierra el archivo.
            runCatching { recorder.stop() }
        } else if (worker == null) {
            releaseProjection()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun releaseProjection() {
        val current = projection
        val callback = projectionCallback
        if (current != null && callback != null) runCatching { current.unregisterCallback(callback) }
        projectionCallback = null
        projection = null
        if (current != null) runCatching { current.stop() }
    }

    override fun onDestroy() {
        running.set(false)
        runCatching { audioRecord?.stop() }
        releaseProjection()
        super.onDestroy()
    }
}
