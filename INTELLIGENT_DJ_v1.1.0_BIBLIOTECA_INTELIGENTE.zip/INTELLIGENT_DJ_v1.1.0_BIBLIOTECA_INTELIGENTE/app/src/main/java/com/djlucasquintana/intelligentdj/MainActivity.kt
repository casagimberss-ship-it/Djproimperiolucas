package com.djlucasquintana.intelligentdj

import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.Manifest
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ensureActive
import androidx.media3.common.PlaybackParameters
import kotlin.math.abs

private val Bg = Color(0xFF090D16)
private val Panel = Color(0xFF141C2B)
private val Accent = Color(0xFF19D3C5)
private val Muted = Color(0xFF9AA8BC)

data class SamplerPad(
    val uri: Uri? = null,
    val name: String = "Sin sample",
    val loop: Boolean = false,
    val volume: Float = 1f
)

data class Track(
    val name: String,
    val uri: Uri,
    val analysis: TrackAnalysis = TrackAnalysis(),
    val sizeBytes: Long = 0L,
    val modifiedAt: Long = 0L
)

class MainActivity : ComponentActivity() {
    // Dos reproductores internos, una sola interfaz/deck visible.
    private var player: ExoPlayer? = null
    private var hiddenPlayer: ExoPlayer? = null
    private var primaryIsActive = true
    private var transitionJob: Job? = null
    private var analysisJob: Job? = null
    private lateinit var database: DjDatabase
    private val samplerPlayers = mutableListOf<ExoPlayer>()
    private var selectedPadForImport = -1
    private var pendingRecordingUri: Uri? = null

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val samplerPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && selectedPadForImport in 0..3) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val prefs = getSharedPreferences("sampler_pads", MODE_PRIVATE)
            prefs.edit().putString("uri_$selectedPadForImport", uri.toString())
                .putString("name_$selectedPadForImport", DocumentFile.fromSingleUri(this, uri)?.name ?: "Sample ${selectedPadForImport + 1}").apply()
            samplerSlots[selectedPadForImport] = samplerSlots[selectedPadForImport].copy(
                uri = uri,
                name = DocumentFile.fromSingleUri(this, uri)?.name ?: "Sample"
            )
            samplerSlotsCallback?.invoke(samplerSlots.toList())
        }
    }
    private val samplerSlots = MutableList(4) { SamplerPad() }
    private var samplerSlotsCallback: ((List<SamplerPad>) -> Unit)? = null

    private val recordingFilePicker = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")) { uri ->
        if (uri != null) {
            pendingRecordingUri = uri
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                launchProjectionConsent()
            } else recordPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
    private val recordPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchProjectionConsent() else { pendingRecordingUri = null; recordingStateCallback?.invoke(false, "Permiso de audio denegado") }
    }
    private val projectionConsentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = pendingRecordingUri
        if (result.resultCode == RESULT_OK && result.data != null && uri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val serviceIntent = Intent(this, SetRecordingService::class.java).apply {
                action = SetRecordingService.ACTION_START
                putExtra(SetRecordingService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(SetRecordingService.EXTRA_RESULT_DATA, result.data)
                putExtra(SetRecordingService.EXTRA_OUTPUT_URI, uri)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            recordingStateCallback?.invoke(true, "Iniciando captura interna · MP3 CBR 320 kbps…")
        } else recordingStateCallback?.invoke(false, "Grabación cancelada")
        pendingRecordingUri = null
    }
    private var recordingStateCallback: ((Boolean, String) -> Unit)? = null
    private val recordingStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == SetRecordingService.ACTION_STATUS) {
                recordingStateCallback?.invoke(
                    intent.getBooleanExtra(SetRecordingService.EXTRA_ACTIVE, false),
                    intent.getStringExtra(SetRecordingService.EXTRA_STATUS) ?: "Estado de grabación actualizado"
                )
            }
        }
    }

    private fun launchProjectionConsent() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionConsentLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun activePlayer(): ExoPlayer? = if (DjPlaybackService.activeDeckIndex == 0) player else hiddenPlayer
    private fun standbyPlayer(): ExoPlayer? = if (DjPlaybackService.activeDeckIndex == 0) hiddenPlayer else player

    private fun matchedPlaybackSpeed(currentBpm: Double?, nextBpm: Double?): Float =
        SmartMixPlanner.tempoRatio(currentBpm, nextBpm)

    private fun phraseWaitMs(analysis: TrackAnalysis?, positionMs: Long): Long =
        SmartMixPlanner.nextPhraseDelay(analysis, positionMs)

    private fun crossfadeTo(
        track: Track,
        currentBpm: Double?,
        outgoingAnalysis: TrackAnalysis? = null,
        onComplete: () -> Unit
    ) {
        if (transitionJob?.isActive == true) return
        val outgoing = activePlayer() ?: return
        val incoming = standbyPlayer() ?: return
        transitionJob = DjPlaybackService.serviceScope.launch {
            try {
                incoming.stop()
                incoming.clearMediaItems()
                incoming.setMediaItem(MediaItem.fromUri(track.uri))
                incoming.volume = 0f
                incoming.playbackParameters = PlaybackParameters(matchedPlaybackSpeed(currentBpm, track.analysis.bpm))
                incoming.prepare()
                // Esperar a que el decoder esté listo sin bloquear el hilo de UI.
                var waited = 0
                while (incoming.playbackState != androidx.media3.common.Player.STATE_READY && waited < 4000) {
                    delay(100); waited += 100
                }
                if (incoming.playbackState != androidx.media3.common.Player.STATE_READY) {
                    incoming.stop(); incoming.clearMediaItems(); incoming.volume = 1f
                    return@launch
                }
                // Build a transition plan from both complete analyses and live deck positions.
                val plan = SmartMixPlanner.plan(
                    outgoingAnalysis, track.analysis, outgoing.currentPosition,
                    outgoing.duration.takeIf { it > 0L && it != androidx.media3.common.C.TIME_UNSET } ?: 0L,
                    incoming.duration.takeIf { it > 0L && it != androidx.media3.common.C.TIME_UNSET } ?: 0L
                )
                incoming.playbackParameters = PlaybackParameters(plan.playbackSpeed)
                if (plan.incomingStartMs > 0L) incoming.seekTo(plan.incomingStartMs)
                val fadeDurationMs = plan.fadeDurationMs
                if (plan.phraseWaitMs > 0L) delay(plan.phraseWaitMs)
                // Keep the outgoing deck running while the incoming deck starts.
                if (!DjPlaybackService.requestAudioFocus()) {
                    incoming.stop(); incoming.clearMediaItems(); incoming.volume = 1f
                    return@launch
                }
                // The optional Android Equalizer is applied per deck; if a device does
                // not expose it, the normal crossfade remains fully functional.
                MixAudioEffects.applyTransitionProfile(outgoing, incoming = false, progress = 0f, energyDelta = plan.energyDelta)
                MixAudioEffects.applyTransitionProfile(incoming, incoming = true, progress = 0f, energyDelta = plan.energyDelta)
                incoming.play()
                val steps = 30
                val stepDelayMs = (fadeDurationMs / steps).coerceAtLeast(10L)
                val curve = CrossfadeCurve.fromStorage(
                    getSharedPreferences("mix_settings", MODE_PRIVATE).getString("crossfade_curve", CrossfadeCurve.EQUAL_POWER.storageKey)
                )
                repeat(steps) { step ->
                    val gains = CrossfadeCurves.gains(curve, (step + 1).toFloat() / steps)
                    outgoing.volume = gains.outgoing
                    incoming.volume = gains.incoming
                    val progress = (step + 1).toFloat() / steps
                    MixAudioEffects.applyTransitionProfile(outgoing, incoming = false, progress = progress, energyDelta = plan.energyDelta)
                    MixAudioEffects.applyTransitionProfile(incoming, incoming = true, progress = progress, energyDelta = plan.energyDelta)
                    delay(stepDelayMs)
                }
                MixAudioEffects.reset(outgoing)
                MixAudioEffects.reset(incoming)
                outgoing.pause()
                outgoing.stop()
                outgoing.clearMediaItems()
                outgoing.volume = 1f
                incoming.volume = 1f
                val nextDeck = if (DjPlaybackService.activeDeckIndex == 0) 1 else 0
                primaryIsActive = nextDeck == 0
                DjPlaybackService.setActiveDeck(nextDeck)
                onComplete()
            } catch (_: Exception) {
                MixAudioEffects.reset(incoming)
                MixAudioEffects.reset(outgoing)
                incoming.pause(); incoming.stop(); incoming.clearMediaItems(); incoming.volume = 1f
                outgoing.volume = 1f
            }
        }
    }
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            // SAF providers can be slow. Walk folders iteratively on IO so a large
            // library never freezes Compose or risks deep-recursion stack overflow.
            lifecycleScope.launch {
                val tracks = runCatching { scanAudioFolder(uri) }.getOrElse { error ->
                    if (error is CancellationException) throw error
                    emptyList()
                }
                onTracksLoaded(tracks, uri)
            }
        }
    }

    private suspend fun scanAudioFolder(treeUri: Uri): List<Track> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(this@MainActivity, treeUri) ?: return@withContext emptyList()
        val pending = java.util.ArrayDeque<DocumentFile>()
        val audioFiles = ArrayList<DocumentFile>()
        val supportedExtensions = setOf("mp3", "wav", "m4a", "flac", "ogg", "aac")
        pending.addLast(root)
        while (pending.isNotEmpty()) {
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            val directory = pending.removeFirst()
            val children = runCatching { directory.listFiles().toList() }.getOrDefault(emptyList())
            for (child in children) {
                when {
                    child.isDirectory -> pending.addLast(child)
                    child.isFile && child.name?.substringAfterLast('.', "")?.lowercase() in supportedExtensions -> audioFiles.add(child)
                }
            }
        }
        audioFiles.sortedBy { it.name?.lowercase().orEmpty() }.map {
            Track(it.name ?: "Audio", it.uri, sizeBytes = it.length(), modifiedAt = it.lastModified())
        }
    }
    private var trackCallback: ((List<Track>, Uri?) -> Unit)? = null
    private fun onTracksLoaded(tracks: List<Track>, folderUri: Uri?) { trackCallback?.invoke(tracks, folderUri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        database = DjDatabase.get(this)
        // Initialize both decks and all four pads synchronously. The foreground
        // service is still started immediately afterward to own audio focus/lifecycle.
        DjPlaybackService.ensurePlayers(applicationContext)
        // La reproducción pertenece al servicio, no al ciclo de vida de la Activity.
        ContextCompat.startForegroundService(this, Intent(this, DjPlaybackService::class.java))
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        player = DjPlaybackService.primaryPlayer
        hiddenPlayer = DjPlaybackService.secondaryPlayer
        samplerPlayers.addAll(DjPlaybackService.samplerPlayers)
        val padPrefs = getSharedPreferences("sampler_pads", MODE_PRIVATE)
        repeat(4) { index ->
            val uri = padPrefs.getString("uri_$index", null)?.let(Uri::parse)
            samplerSlots[index] = SamplerPad(
                uri = uri,
                name = padPrefs.getString("name_$index", "Sin sample") ?: "Sin sample",
                loop = padPrefs.getBoolean("loop_$index", false),
                volume = padPrefs.getFloat("volume_$index", 1f).coerceIn(0f, 1f)
            )
            samplerPlayers.getOrNull(index)?.volume = samplerSlots[index].volume
        }
        setContent {
            var tracks by remember { mutableStateOf(emptyList<Track>()) }
            var current by remember { mutableIntStateOf(0) }
            var initialTrackIndex by remember { mutableIntStateOf(-1) }
            var playing by remember { mutableStateOf(false) }
            var playedIndices by remember { mutableStateOf(setOf<Int>()) }
            var folderLabel by remember { mutableStateOf("Ninguna carpeta seleccionada") }
            var folderCount by remember { mutableIntStateOf(0) }
            var analysisStatus by remember { mutableStateOf("Análisis de audio pendiente") }
            val analysisStates = remember { mutableStateMapOf<String, String>() }
            var autoMixEnabled by remember { mutableStateOf(true) }
            var crossfadeCurve by remember {
                mutableStateOf(CrossfadeCurve.fromStorage(getSharedPreferences("mix_settings", MODE_PRIVATE).getString("crossfade_curve", CrossfadeCurve.EQUAL_POWER.storageKey)))
            }
            var autoAttemptedForIndex by remember { mutableIntStateOf(-1) }
            var pads by remember { mutableStateOf(samplerSlots.toList()) }
            val samplerPlaying = remember { mutableStateListOf(false, false, false, false) }
            var isRecording by remember { mutableStateOf(false) }
            var recordingStatus by remember { mutableStateOf("Listo para grabar") }
            samplerSlotsCallback = { pads = it }
            recordingStateCallback = { active, message -> isRecording = active; recordingStatus = message }
            LaunchedEffect(Unit) {
                while (true) {
                    samplerPlayers.forEachIndexed { index, samplePlayer ->
                        samplerPlaying[index] = samplePlayer.isPlaying
                    }
                    delay(120)
                }
            }
            LaunchedEffect(Unit) {
                runCatching { database.trackDao().getAll() }.getOrDefault(emptyList()).let { rows ->
                    val restoredPairs = rows.mapNotNull { row ->
                        runCatching { row to Track(row.name, Uri.parse(row.uri), row.toAnalysis(), row.sizeBytes, row.modifiedAt) }.getOrNull()
                    }
                    val restored = restoredPairs.map { it.second }
                    if (restored.isNotEmpty()) {
                        tracks = restored
                        restoredPairs.forEach { (row, track) ->
                            analysisStates[track.uri.toString()] = row.analysisStatus
                        }
                        val folders = runCatching { database.trackDao().getLibraryFolders() }.getOrDefault(emptyList())
                        folderCount = folders.size
                        folderLabel = "${restored.size} pistas · ${folders.size} carpetas recuperadas"
                        analysisStatus = "Biblioteca, estados y análisis recuperados desde Room"
                    }
                }
            }
            LaunchedEffect(playing, current, tracks.size, autoMixEnabled) {
                if (playing && autoMixEnabled && tracks.size > 1) {
                    while (true) {
                        val active = activePlayer()
                        val durationMs = active?.duration ?: androidx.media3.common.C.TIME_UNSET
                        val positionMs = active?.currentPosition ?: 0L
                        if (durationMs > 0L && durationMs != androidx.media3.common.C.TIME_UNSET && current != autoAttemptedForIndex) {
                            val analysis = tracks.getOrNull(current)?.analysis
                            val outroCueMs = analysis?.outroStartSeconds?.times(1000.0)?.toLong()
                            val reliableStructure = SmartMixPlanner.isAnalysisReliable(analysis, 0.40)
                            // Trust the detected outro only after a sufficiently complete analysis.
                            // Otherwise retain the conservative 20-second safety cue.
                            val cueMs = if (outroCueMs != null && reliableStructure) {
                                outroCueMs.coerceIn(0L, (durationMs - 3_000L).coerceAtLeast(0L))
                            } else (durationMs - 20_000L).coerceAtLeast(0L)
                            if (positionMs >= cueMs) {
                                val next = SmartMixEngine.selectNext(tracks.map { it.analysis }, current, playedIndices)
                                if (next != null) {
                                    autoAttemptedForIndex = current
                                    val outgoingBpm = analysis?.bpm
                                    crossfadeTo(tracks[next], outgoingBpm, analysis) {
                                        playedIndices = playedIndices + current
                                        current = next
                                        playing = true
                                    }
                                }
                                break
                            }
                        }
                        delay(400)
                    }
                }
            }
            trackCallback = { loaded, folderUri ->
                val hadLibrary = tracks.isNotEmpty()
                val merged = (tracks + loaded).distinctBy { it.uri.toString() }
                tracks = merged
                if (!hadLibrary) { current = 0; playedIndices = emptySet(); autoAttemptedForIndex = -1 }
                loaded.forEach { track -> if (analysisStates[track.uri.toString()] == null) analysisStates[track.uri.toString()] = "PENDIENTE" }
                val folderName = folderUri?.let { DocumentFile.fromTreeUri(this@MainActivity, it)?.name } ?: "Biblioteca"
                folderLabel = "${merged.size} pistas · ${loaded.size} nuevas desde $folderName"
                analysisStatus = "Guardando biblioteca y preparando análisis…"
                analysisJob?.cancel()
                val libraryTracks = merged
                val newlyLoadedUris = loaded.map { it.uri.toString() }.toSet()
                analysisJob = lifecycleScope.launch(Dispatchers.IO) {
                    val folderKey = folderUri?.toString().orEmpty()
                    val previousRows = database.trackDao().getAll().associateBy { it.uri }
                    // Hash the actual file content: SAF size/date metadata is often zero or unstable.
                    val fingerprints = libraryTracks.mapIndexed { fingerprintIndex, track ->
                        withContext(Dispatchers.Main) {
                            analysisStatus = "Verificando archivos para reutilizar análisis • ${fingerprintIndex + 1}/${libraryTracks.size}"
                        }
                        val previous = previousRows[track.uri.toString()]
                        val metadataStable = previous != null && track.sizeBytes > 0L && track.modifiedAt > 0L &&
                            previous.sizeBytes == track.sizeBytes && previous.modifiedAt == track.modifiedAt
                        val fingerprint = if (metadataStable && !previous!!.contentFingerprint.isBlank()) {
                            previous.contentFingerprint
                        } else {
                            runCatching { calculateAudioFingerprint(this@MainActivity, track.uri) }
                                .getOrElse { error ->
                                    if (error is CancellationException) throw error
                                    null
                                }
                        }
                        track.uri.toString() to fingerprint
                    }.toMap()
                    val initialRows = libraryTracks.map { track ->
                        val previous = previousRows[track.uri.toString()]
                        val fingerprint = fingerprints[track.uri.toString()]
                        val sameContent = previous != null && (
                            (!fingerprint.isNullOrBlank() && previous.contentFingerprint.isNotBlank() && fingerprint.equals(previous.contentFingerprint, true)) ||
                            (!fingerprint.isNullOrBlank() && previous.contentFingerprint.isBlank() && (track.sizeBytes > 0L || track.modifiedAt > 0L) &&
                                (track.sizeBytes <= 0L || previous.sizeBytes == track.sizeBytes) &&
                                (track.modifiedAt <= 0L || previous.modifiedAt == track.modifiedAt)) ||
                            (fingerprint.isNullOrBlank() && (track.sizeBytes > 0L || track.modifiedAt > 0L) &&
                                (track.sizeBytes <= 0L || previous!!.sizeBytes == track.sizeBytes) &&
                                (track.modifiedAt <= 0L || previous!!.modifiedAt == track.modifiedAt)) ||
                            (previous.contentFingerprint.isBlank() && track.sizeBytes == 0L && track.modifiedAt == 0L &&
                                previous.sizeBytes == 0L && previous.modifiedAt == 0L && previous.analysisStatus == "OK" &&
                                previous.durationSeconds != null && previous.analyzedDurationSeconds != null &&
                                previous.analyzedDurationSeconds + 1.0 >= previous.durationSeconds)
                        )
                        if (sameContent) previous!!.copy(
                            name = track.name,
                            sourceFolderUri = if (track.uri.toString() in newlyLoadedUris) folderKey else previous.sourceFolderUri,
                            contentFingerprint = fingerprint ?: previous.contentFingerprint
                        ) else track.toEntity(
                            if (track.uri.toString() in newlyLoadedUris) folderKey else previous?.sourceFolderUri.orEmpty(),
                            "PENDIENTE"
                        ).copy(contentFingerprint = fingerprint.orEmpty())
                    }
                    database.trackDao().appendLibrary(
                        LibraryFolderEntity(treeUri = folderKey, displayName = folderName, scannedAt = System.currentTimeMillis()),
                        initialRows
                    )
                    val savedFolderCount = database.trackDao().getLibraryFolders().size
                    withContext(Dispatchers.Main) {
                        folderCount = savedFolderCount
                        analysisStatus = "Biblioteca guardada · iniciando análisis…"
                    }
                    // Cola secuencial en IO: no bloquea la interfaz ni compite creando varios decodificadores.
                    var reused = 0
                    var analyzed = 0
                    libraryTracks.forEachIndexed { index, track ->
                        kotlinx.coroutines.currentCoroutineContext().ensureActive()
                        val trackKey = track.uri.toString()
                        val fingerprint = fingerprints[trackKey]
                        val cached = runCatching { database.trackDao().getCachedAnalysis(track, fingerprint) }
                            .getOrElse { error ->
                                if (error is CancellationException) throw error
                                null
                            }
                        withContext(Dispatchers.Main) {
                            analysisStates[trackKey] = if (cached != null) "OK" else "ANALIZANDO"
                            analysisStatus = "Cola de análisis • ${index + 1}/${libraryTracks.size}"
                        }
                        val sourceFolder = if (trackKey in newlyLoadedUris) folderKey else previousRows[trackKey]?.sourceFolderUri.orEmpty()
                        if (cached == null) {
                            runCatching { database.trackDao().upsert(track.toEntity(sourceFolder, "ANALIZANDO").copy(contentFingerprint = fingerprint.orEmpty())) }
                        }
                        val result = cached ?: runCatching {
                            AudioAnalyzer.analyze(this@MainActivity, track.uri)
                        }.getOrElse { error ->
                            if (error is CancellationException) throw error
                            TrackAnalysis()
                        }
                        if (cached != null) reused++ else analyzed++
                        // A full decode is a completed analysis even when a particular metric (BPM/key)
                        // cannot be estimated reliably; do not force the same file to be decoded forever.
                        val complete = result.durationSeconds != null && result.durationSeconds > 0.0 &&
                            result.analyzedDurationSeconds != null &&
                            result.analyzedDurationSeconds + 1.0 >= result.durationSeconds
                        val finalStatus = if (complete) "OK" else "ERROR"
                        runCatching {
                            database.trackDao().upsert(track.copy(analysis = result).toEntity(sourceFolder, finalStatus).copy(contentFingerprint = fingerprint.orEmpty()))
                        }.onFailure { error -> if (error is CancellationException) throw error }
                        withContext(Dispatchers.Main) {
                            analysisStates[trackKey] = finalStatus
                            val currentIndex = tracks.indexOfFirst { it.uri == track.uri }
                            if (currentIndex >= 0) {
                                tracks = tracks.toMutableList().also { it[currentIndex] = track.copy(analysis = result) }
                            }
                            analysisStatus = "${index + 1}/${libraryTracks.size} • $reused reutilizadas • $analyzed nuevas"
                        }
                    }
                    withContext(Dispatchers.Main) {
                        val successful = analysisStates.values.count { it == "OK" }
                        val failed = analysisStates.values.count { it == "ERROR" }
                        analysisStatus = "Análisis terminado • $successful OK • $failed con errores"
                    }
                }
            }
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item {
                            Column {
                                Text("INTELLIGENT DJ", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                Text("by Dj Lucas Quintana", color = Accent, style = MaterialTheme.typography.labelLarge)
                                Text("SMART AUTOMIX • ANDROID", color = Muted, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        item {
                            PanelCard("REPRODUCTOR") {
                                Text(if (tracks.isNotEmpty()) tracks.getOrNull(current)?.name ?: "Sin pista" else "Cargá tu música para comenzar", color = Color.White, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    InfoPill("BPM", tracks.getOrNull(current)?.analysis?.bpm?.toInt()?.toString() ?: "--")
                                    InfoPill("KEY", tracks.getOrNull(current)?.analysis?.camelot?.let { camelotToKey(it) } ?: "--")
                                    InfoPill("CAMELOT", tracks.getOrNull(current)?.analysis?.camelot ?: "--")
                                    InfoPill("MATCH", if (tracks.size > 1) "Smart" else "Pendiente")
                                }
                                Spacer(Modifier.height(12.dp))
                                LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        if (tracks.isNotEmpty()) {
                                            if (playing) {
                                                activePlayer()?.pause()
                                                playing = false
                                            } else {
                                                val active = activePlayer()
                                                if (active?.mediaItemCount == 0) {
                                                    val startIndex = initialTrackIndex.takeIf { it in tracks.indices }
                                                        ?: SmartMixEngine.selectInitial(tracks.map { it.analysis })
                                                        ?: 0
                                                    current = startIndex
                                                    playedIndices = emptySet()
                                                    autoAttemptedForIndex = -1
                                                    active.setMediaItem(MediaItem.fromUri(tracks[startIndex].uri))
                                                    active.prepare()
                                                    initialTrackIndex = -1
                                                }
                                                if (DjPlaybackService.requestAudioFocus()) {
                                                    active?.play()
                                                    if (active != null) playedIndices = playedIndices + current
                                                    playing = true
                                                }
                                            }
                                        }
                                    }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Accent) }
                                    IconButton(onClick = {
                                        if (tracks.size > 1) {
                                            val analyses = tracks.map { it.analysis }
                                            val next = SmartMixEngine.selectNext(analyses, current, playedIndices)
                                            if (next != null) {
                                                val outgoingBpm = tracks.getOrNull(current)?.analysis?.bpm
                                                val nextTrack = tracks[next]
                                                if (playing && activePlayer()?.isPlaying == true) {
                                                    crossfadeTo(nextTrack, outgoingBpm, tracks.getOrNull(current)?.analysis) {
                                                        playedIndices = playedIndices + current
                                                        current = next
                                                        playing = true
                                                    }
                                                } else {
                                                    if ((activePlayer()?.mediaItemCount ?: 0) > 0) playedIndices = playedIndices + current
                                                    val incoming = standbyPlayer()
                                                    incoming?.stop()
                                                    incoming?.setMediaItem(MediaItem.fromUri(nextTrack.uri))
                                                    incoming?.playbackParameters = PlaybackParameters(matchedPlaybackSpeed(outgoingBpm, nextTrack.analysis.bpm))
                                                    incoming?.prepare()
                                                    incoming?.let { deck ->
                                                        val beat = nextTrack.analysis.beatOffsetSeconds
                                                        if (beat != null && beat >= 0.0) deck.seekTo((beat * 1000.0).toLong())
                                                        if (DjPlaybackService.requestAudioFocus()) deck.play()
                                                    }
                                                    activePlayer()?.stop()
                                                    val nextDeck = if (DjPlaybackService.activeDeckIndex == 0) 1 else 0
                                                    primaryIsActive = nextDeck == 0
                                                    DjPlaybackService.setActiveDeck(nextDeck)
                                                    current = next
                                                    playing = true
                                                }
                                            }
                                        }
                                    }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                                }
                                Text("SMART • BPM ADAPTIVE • ENERGÍA PROGRESSIVE", color = Accent, style = MaterialTheme.typography.labelSmall)
                                Text("1 DECK VISIBLE • 2 DECKS INTERNOS • CROSSFADE ADAPTATIVO 3–12 s", color = Muted, style = MaterialTheme.typography.labelSmall)
                                Text("CURVA DE TRANSICIÓN", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    CrossfadeCurve.entries.forEach { curve ->
                                        val selected = crossfadeCurve == curve
                                        TextButton(
                                            onClick = {
                                                crossfadeCurve = curve
                                                getSharedPreferences("mix_settings", MODE_PRIVATE).edit().putString("crossfade_curve", curve.storageKey).apply()
                                            },
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                                            colors = ButtonDefaults.textButtonColors(contentColor = if (selected) Accent else Muted)
                                        ) { Text(if (selected) "✓ ${curve.label}" else curve.label, style = MaterialTheme.typography.labelSmall, maxLines = 1) }
                                    }
                                }
                                Text(
                                    when (crossfadeCurve) {
                                        CrossfadeCurve.LINEAR -> "Bajada y subida de volumen uniformes"
                                        CrossfadeCurve.EQUAL_POWER -> "Volumen percibido más constante durante el cruce"
                                        CrossfadeCurve.SMOOTH -> "Entrada y salida progresivas, sin cambios bruscos"
                                    }, color = Muted, style = MaterialTheme.typography.bodySmall
                                )
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.weight(1f)) {
                                        Text("AUTOMIX AUTOMÁTICO", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                        Text("Transición al detectar el outro o en los últimos 20 s", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Switch(checked = autoMixEnabled, onCheckedChange = { autoMixEnabled = it })
                                }
                                val confidence = tracks.getOrNull(current)?.analysis?.analysisConfidence
                                InfoPill("ANÁLISIS", confidence?.let { "${(it * 100).toInt()}%" } ?: "--")
                                Text("$analysisStatus • BPM, tonalidad, beatgrid y estructura son estimaciones experimentales", color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        item {
                            PanelCard("SAMPLER • 4 PADS") {
                                Text("Pads compactos · disparo independiente · audio simultáneo", color = Muted, style = MaterialTheme.typography.bodySmall)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    pads.forEachIndexed { index, pad ->
                                        val padColor = listOf(
                                            Color(0xFFE34DB5), Color(0xFF35C8DA),
                                            Color(0xFFA7DE50), Color(0xFFF2B34F)
                                        )[index]
                                        Card(
                                            modifier = Modifier.weight(1f),
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFF101827)),
                                            shape = RoundedCornerShape(8.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, padColor.copy(alpha = 0.8f))
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 5.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(3.dp)
                                            ) {
                                                Text("PAD ${index + 1}", color = padColor, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                                                OutlinedButton(
                                                    onClick = { selectedPadForImport = index; samplerPicker.launch(arrayOf("audio/*")) },
                                                    modifier = Modifier.fillMaxWidth().height(27.dp),
                                                    contentPadding = PaddingValues(horizontal = 1.dp, vertical = 0.dp),
                                                    shape = RoundedCornerShape(5.dp)
                                                ) {
                                                    Icon(Icons.Default.FolderOpen, contentDescription = "Cargar sample", modifier = Modifier.size(11.dp))
                                                    Text(if (pad.uri == null) "CARGAR" else pad.name.take(7), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                                }
                                                IconButton(
                                                    onClick = {
                                                        val samplePlayer = samplerPlayers.getOrNull(index) ?: return@IconButton
                                                        if (samplerPlaying[index]) {
                                                            samplePlayer.stop(); samplePlayer.clearMediaItems(); samplerPlaying[index] = false
                                                        } else if (pad.uri != null) {
                                                            samplePlayer.stop(); samplePlayer.clearMediaItems()
                                                            samplePlayer.setMediaItem(MediaItem.fromUri(pad.uri))
                                                            samplePlayer.repeatMode = if (pad.loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                                                            samplePlayer.volume = pad.volume
                                                            samplePlayer.prepare()
                                                            if (DjPlaybackService.requestAudioFocus()) { samplePlayer.play(); samplerPlaying[index] = true }
                                                        }
                                                    },
                                                    enabled = pad.uri != null,
                                                    modifier = Modifier.size(34.dp)
                                                ) {
                                                    Icon(
                                                        if (samplerPlaying[index]) Icons.Default.Stop else Icons.Default.PlayArrow,
                                                        contentDescription = if (samplerPlaying[index]) "Detener pad ${index + 1}" else "Reproducir pad ${index + 1}",
                                                        tint = padColor,
                                                        modifier = Modifier.size(25.dp)
                                                    )
                                                }
                                                Slider(
                                                    value = pad.volume,
                                                    onValueChange = { value ->
                                                        val updated = pad.copy(volume = value)
                                                        samplerSlots[index] = updated
                                                        samplerPlayers.getOrNull(index)?.volume = value
                                                        getSharedPreferences("sampler_pads", MODE_PRIVATE).edit().putFloat("volume_$index", value).apply()
                                                        pads = samplerSlots.toList()
                                                    },
                                                    valueRange = 0f..1f,
                                                    modifier = Modifier.fillMaxWidth().height(19.dp),
                                                    colors = SliderDefaults.colors(thumbColor = padColor, activeTrackColor = padColor, inactiveTrackColor = Color(0xFF39445C))
                                                )
                                                TextButton(
                                                    onClick = {
                                                        val updated = pad.copy(loop = !pad.loop)
                                                        samplerSlots[index] = updated
                                                        getSharedPreferences("sampler_pads", MODE_PRIVATE).edit().putBoolean("loop_$index", updated.loop).apply()
                                                        samplerPlayers.getOrNull(index)?.repeatMode = if (updated.loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                                                        pads = samplerSlots.toList()
                                                    },
                                                    modifier = Modifier.fillMaxWidth().height(21.dp),
                                                    contentPadding = PaddingValues(0.dp)
                                                ) {
                                                    Text(if (pad.loop) "LOOP" else "1 SHOT", color = padColor, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            PanelCard("GRABACIÓN DEL SET") {
                                Text("MP3 estéreo · CBR 320 kbps · LAME", color = Color.White)
                                Button(onClick = {
                                    if (isRecording) {
                                        startService(Intent(this@MainActivity, SetRecordingService::class.java).setAction(SetRecordingService.ACTION_STOP))
                                        isRecording = false; recordingStatus = "Finalizando MP3…"
                                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        recordingFilePicker.launch("INTELLIGENT_DJ_SET.mp3")
                                    } else recordingStatus = "La captura interna requiere Android 10 o superior"
                                }, enabled = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q || isRecording, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) Color(0xFFB83245) else Accent)) {
                                    Text(if (isRecording) "DETENER Y GUARDAR MP3" else "● INICIAR GRABACIÓN", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                                Text(recordingStatus, color = if (isRecording) Accent else Muted, style = MaterialTheme.typography.bodySmall)
                                Text("Usa captura de reproducción Android (MediaProjection), no el micrófono. Requiere Android 10+, permiso de grabación y autorización del sistema.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        item {
                            PanelCard("BIBLIOTECA") {
                                Button(onClick = { folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("AGREGAR CARPETA DE MÚSICA")
                                }
                                Text(folderLabel, color = Muted, style = MaterialTheme.typography.bodySmall)
                                Text("${tracks.size} pistas • $folderCount carpetas • escaneo recursivo", color = Accent, fontWeight = FontWeight.Bold)
                                Text(
                                    if (initialTrackIndex in tracks.indices) "Inicio manual: ${tracks[initialTrackIndex].name}"
                                    else "Inicio automático: Smart Mix elegirá la apertura",
                                    color = Muted,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (initialTrackIndex in tracks.indices) {
                                    TextButton(onClick = { initialTrackIndex = -1 }) {
                                        Text("QUITAR SELECCIÓN DE INICIO", color = Accent)
                                    }
                                }
                            }
                        }
                        items(tracks.withIndex().filter { (index, _) -> index !in playedIndices && !(playing && index == current) }, key = { it.value.uri.toString() }) { indexedTrack ->
                            val trackIndex = indexedTrack.index
                            val track = indexedTrack.value
                            val isInitial = initialTrackIndex == trackIndex
                            Card(
                                colors = CardDefaults.cardColors(containerColor = if (isInitial) Color(0xFF183B43) else Panel),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(track.name, color = Color.White, fontWeight = if (isInitial) FontWeight.Bold else FontWeight.Normal)
                                        if (isInitial) {
                                            Text("PISTA DE INICIO", color = Accent, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                        }
                                        val analysisState = analysisStates[track.uri.toString()] ?:
                                            if (track.analysis.bpm != null && track.analysis.camelot != null) "OK" else "PENDIENTE"
                                        val analysisLine = when (analysisState) {
                                            "OK" -> {
                                                val bpmLabel = track.analysis.bpm?.let { "${it.toInt()} BPM" } ?: "BPM no detectado"
                                                val keyLabel = track.analysis.camelot?.let { "$it (${camelotToKey(it)})" } ?: "tonalidad no detectada"
                                                "OK · análisis completo · $bpmLabel · $keyLabel"
                                            }
                                            "ANALIZANDO" -> "ANALIZANDO · leyendo pista completa…"
                                            "ERROR" -> "ERROR · no se pudo obtener BPM y tonalidad"
                                            else -> "PENDIENTE · esperando análisis"
                                        }
                                        Text(
                                            analysisLine,
                                            color = when (analysisState) {
                                                "OK" -> Color(0xFF63D995)
                                                "ERROR" -> Color(0xFFFF7B86)
                                                "ANALIZANDO" -> Accent
                                                else -> Muted
                                            },
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                    TextButton(onClick = { initialTrackIndex = if (isInitial) -1 else trackIndex }) {
                                        Text(if (isInitial) "INICIO ✓" else "ELEGIR INICIO", color = if (isInitial) Accent else Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, recordingStatusReceiver, IntentFilter(SetRecordingService.ACTION_STATUS), ContextCompat.RECEIVER_NOT_EXPORTED)
        val prefs = getSharedPreferences("recording_status", MODE_PRIVATE)
        recordingStateCallback?.invoke(prefs.getBoolean("active", false), prefs.getString("message", "Listo para grabar") ?: "Listo para grabar")
    }

    override fun onStop() {
        runCatching { unregisterReceiver(recordingStatusReceiver) }
        super.onStop()
    }

    override fun onDestroy() {
        // No liberar ni detener los decks aquí: DjPlaybackService los conserva
        // al destruirse o recrearse la interfaz.
        analysisJob?.cancel()
        samplerSlotsCallback = null
        recordingStateCallback = null
        super.onDestroy()
    }
}

@Composable private fun PanelCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = {
            Text(title, color = Accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            content()
        })
    }
}

@Composable private fun InfoPill(label: String, value: String) {
    Column(Modifier.background(Color(0xFF202C40), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) {
        Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
    }
}


private fun camelotToKey(value: String): String {
    val number = value.dropLast(1).toIntOrNull() ?: return "--"
    val major = mapOf(1 to "B", 2 to "F#", 3 to "C#", 4 to "G#", 5 to "D#", 6 to "A#", 7 to "F", 8 to "C", 9 to "G", 10 to "D", 11 to "A", 12 to "E")
    val minor = mapOf(1 to "G#m", 2 to "D#m", 3 to "A#m", 4 to "Fm", 5 to "Cm", 6 to "Gm", 7 to "Dm", 8 to "Am", 9 to "Em", 10 to "Bm", 11 to "F#m", 12 to "C#m")
    return (if (value.endsWith("A")) minor[number] else major[number]) ?: "--"
}
